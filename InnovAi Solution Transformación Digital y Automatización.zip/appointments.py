from flask import Blueprint, jsonify, request
from src.models.user import Appointment, db
from datetime import datetime

appointments_bp = Blueprint('appointments', __name__)

@appointments_bp.route('/appointments', methods=['GET'])
def get_appointments():
    user_id = request.args.get('user_id')
    status = request.args.get('status')
    
    query = Appointment.query
    if user_id:
        query = query.filter_by(user_id=user_id)
    if status:
        query = query.filter_by(status=status)
    
    appointments = query.order_by(Appointment.scheduled_at.asc()).all()
    return jsonify([appointment.to_dict() for appointment in appointments])

@appointments_bp.route('/appointments', methods=['POST'])
def create_appointment():
    data = request.json
    
    appointment = Appointment(
        user_id=data['user_id'],
        title=data['title'],
        description=data.get('description'),
        scheduled_at=datetime.fromisoformat(data['scheduled_at']),
        duration_minutes=data.get('duration_minutes', 60),
        status=data.get('status', 'scheduled'),
        meeting_link=data.get('meeting_link')
    )
    db.session.add(appointment)
    db.session.commit()
    return jsonify(appointment.to_dict()), 201

@appointments_bp.route('/appointments/<int:appointment_id>', methods=['GET'])
def get_appointment(appointment_id):
    appointment = Appointment.query.get_or_404(appointment_id)
    return jsonify(appointment.to_dict())

@appointments_bp.route('/appointments/<int:appointment_id>', methods=['PUT'])
def update_appointment(appointment_id):
    appointment = Appointment.query.get_or_404(appointment_id)
    data = request.json
    
    appointment.title = data.get('title', appointment.title)
    appointment.description = data.get('description', appointment.description)
    if data.get('scheduled_at'):
        appointment.scheduled_at = datetime.fromisoformat(data['scheduled_at'])
    appointment.duration_minutes = data.get('duration_minutes', appointment.duration_minutes)
    appointment.status = data.get('status', appointment.status)
    appointment.meeting_link = data.get('meeting_link', appointment.meeting_link)
    
    db.session.commit()
    return jsonify(appointment.to_dict())

@appointments_bp.route('/appointments/<int:appointment_id>', methods=['DELETE'])
def delete_appointment(appointment_id):
    appointment = Appointment.query.get_or_404(appointment_id)
    db.session.delete(appointment)
    db.session.commit()
    return '', 204

@appointments_bp.route('/appointments/available-slots', methods=['GET'])
def get_available_slots():
    """Obtener horarios disponibles para agendar citas"""
    date = request.args.get('date')  # formato: YYYY-MM-DD
    
    # Simular horarios disponibles (en una implementación real, esto vendría de un calendario)
    available_slots = [
        "09:00", "10:00", "11:00", "14:00", "15:00", "16:00"
    ]
    
    if date:
        # Filtrar horarios ya ocupados para esa fecha
        date_obj = datetime.strptime(date, '%Y-%m-%d').date()
        occupied_appointments = Appointment.query.filter(
            db.func.date(Appointment.scheduled_at) == date_obj,
            Appointment.status == 'scheduled'
        ).all()
        
        occupied_times = [apt.scheduled_at.strftime('%H:%M') for apt in occupied_appointments]
        available_slots = [slot for slot in available_slots if slot not in occupied_times]
    
    return jsonify({
        'date': date,
        'available_slots': available_slots
    })

