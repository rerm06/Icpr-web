from flask_sqlalchemy import SQLAlchemy
from datetime import datetime, timedelta
import uuid
from decimal import Decimal

db = SQLAlchemy()

class PaymentMethod(db.Model):
    __tablename__ = 'payment_methods'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    method_key = db.Column(db.String(36), unique=True, nullable=False, default=lambda: str(uuid.uuid4()))
    
    # Detalles del método de pago
    type = db.Column(db.String(20), nullable=False)  # credit_card, debit_card, paypal, stripe
    provider = db.Column(db.String(50))  # visa, mastercard, amex, paypal, stripe
    last_four = db.Column(db.String(4))
    expiry_month = db.Column(db.Integer)
    expiry_year = db.Column(db.Integer)
    cardholder_name = db.Column(db.String(100))
    
    # Tokens de pago (encriptados)
    stripe_payment_method_id = db.Column(db.String(200))
    paypal_payment_method_id = db.Column(db.String(200))
    
    # Estado
    is_default = db.Column(db.Boolean, default=False)
    is_active = db.Column(db.Boolean, default=True)
    verified = db.Column(db.Boolean, default=False)
    
    # Metadatos
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def to_dict(self):
        return {
            'id': self.id,
            'method_key': self.method_key,
            'user_id': self.user_id,
            'type': self.type,
            'provider': self.provider,
            'last_four': self.last_four,
            'expiry_month': self.expiry_month,
            'expiry_year': self.expiry_year,
            'cardholder_name': self.cardholder_name,
            'is_default': self.is_default,
            'is_active': self.is_active,
            'verified': self.verified,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }

class Subscription(db.Model):
    __tablename__ = 'subscriptions'
    
    id = db.Column(db.Integer, primary_key=True)
    subscription_key = db.Column(db.String(36), unique=True, nullable=False, default=lambda: str(uuid.uuid4()))
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    service_id = db.Column(db.Integer, db.ForeignKey('user_services.id'), nullable=False)
    payment_method_id = db.Column(db.Integer, db.ForeignKey('payment_methods.id'))
    
    # Detalles de la suscripción
    plan_name = db.Column(db.String(100), nullable=False)
    plan_type = db.Column(db.String(50))  # basic, premium, enterprise
    billing_cycle = db.Column(db.String(20), default='monthly')  # monthly, quarterly, yearly
    amount = db.Column(db.Numeric(10, 2), nullable=False)
    currency = db.Column(db.String(3), default='USD')
    
    # Fechas importantes
    start_date = db.Column(db.Date, nullable=False)
    end_date = db.Column(db.Date)
    next_billing_date = db.Column(db.Date)
    trial_end_date = db.Column(db.Date)
    
    # Estado
    status = db.Column(db.String(20), default='active')  # active, paused, cancelled, expired, trial
    auto_renew = db.Column(db.Boolean, default=True)
    
    # Metadatos
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    cancelled_at = db.Column(db.DateTime)
    cancellation_reason = db.Column(db.Text)
    
    # Relaciones
    payment_method = db.relationship('PaymentMethod', backref='subscriptions')
    
    def to_dict(self):
        return {
            'id': self.id,
            'subscription_key': self.subscription_key,
            'user_id': self.user_id,
            'service_id': self.service_id,
            'payment_method_id': self.payment_method_id,
            'plan_name': self.plan_name,
            'plan_type': self.plan_type,
            'billing_cycle': self.billing_cycle,
            'amount': float(self.amount) if self.amount else 0.0,
            'currency': self.currency,
            'start_date': self.start_date.isoformat() if self.start_date else None,
            'end_date': self.end_date.isoformat() if self.end_date else None,
            'next_billing_date': self.next_billing_date.isoformat() if self.next_billing_date else None,
            'trial_end_date': self.trial_end_date.isoformat() if self.trial_end_date else None,
            'status': self.status,
            'auto_renew': self.auto_renew,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None,
            'cancelled_at': self.cancelled_at.isoformat() if self.cancelled_at else None,
            'cancellation_reason': self.cancellation_reason
        }

class Invoice(db.Model):
    __tablename__ = 'invoices'
    
    id = db.Column(db.Integer, primary_key=True)
    invoice_number = db.Column(db.String(50), unique=True, nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    subscription_id = db.Column(db.Integer, db.ForeignKey('subscriptions.id'))
    
    # Detalles de la factura
    description = db.Column(db.Text)
    subtotal = db.Column(db.Numeric(10, 2), nullable=False)
    tax_amount = db.Column(db.Numeric(10, 2), default=0.0)
    discount_amount = db.Column(db.Numeric(10, 2), default=0.0)
    total_amount = db.Column(db.Numeric(10, 2), nullable=False)
    currency = db.Column(db.String(3), default='USD')
    
    # Fechas importantes
    issue_date = db.Column(db.Date, nullable=False, default=datetime.utcnow().date)
    due_date = db.Column(db.Date, nullable=False)
    paid_date = db.Column(db.Date)
    
    # Estado
    status = db.Column(db.String(20), default='pending')  # pending, paid, overdue, cancelled, refunded
    payment_status = db.Column(db.String(20), default='unpaid')  # unpaid, paid, partial, refunded
    
    # Archivos
    pdf_path = db.Column(db.String(500))
    pdf_generated = db.Column(db.Boolean, default=False)
    
    # Metadatos
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relaciones
    subscription = db.relationship('Subscription', backref='invoices')
    line_items = db.relationship('InvoiceLineItem', backref='invoice', lazy=True, cascade='all, delete-orphan')
    payments = db.relationship('Payment', backref='invoice', lazy=True)
    
    def to_dict(self):
        return {
            'id': self.id,
            'invoice_number': self.invoice_number,
            'user_id': self.user_id,
            'subscription_id': self.subscription_id,
            'description': self.description,
            'subtotal': float(self.subtotal) if self.subtotal else 0.0,
            'tax_amount': float(self.tax_amount) if self.tax_amount else 0.0,
            'discount_amount': float(self.discount_amount) if self.discount_amount else 0.0,
            'total_amount': float(self.total_amount) if self.total_amount else 0.0,
            'currency': self.currency,
            'issue_date': self.issue_date.isoformat() if self.issue_date else None,
            'due_date': self.due_date.isoformat() if self.due_date else None,
            'paid_date': self.paid_date.isoformat() if self.paid_date else None,
            'status': self.status,
            'payment_status': self.payment_status,
            'pdf_path': self.pdf_path,
            'pdf_generated': self.pdf_generated,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }

class InvoiceLineItem(db.Model):
    __tablename__ = 'invoice_line_items'
    
    id = db.Column(db.Integer, primary_key=True)
    invoice_id = db.Column(db.Integer, db.ForeignKey('invoices.id'), nullable=False)
    
    # Detalles del item
    description = db.Column(db.String(500), nullable=False)
    quantity = db.Column(db.Integer, default=1)
    unit_price = db.Column(db.Numeric(10, 2), nullable=False)
    total_price = db.Column(db.Numeric(10, 2), nullable=False)
    
    # Metadatos
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def to_dict(self):
        return {
            'id': self.id,
            'invoice_id': self.invoice_id,
            'description': self.description,
            'quantity': self.quantity,
            'unit_price': float(self.unit_price) if self.unit_price else 0.0,
            'total_price': float(self.total_price) if self.total_price else 0.0,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }

class Payment(db.Model):
    __tablename__ = 'payments'
    
    id = db.Column(db.Integer, primary_key=True)
    payment_key = db.Column(db.String(36), unique=True, nullable=False, default=lambda: str(uuid.uuid4()))
    invoice_id = db.Column(db.Integer, db.ForeignKey('invoices.id'), nullable=False)
    payment_method_id = db.Column(db.Integer, db.ForeignKey('payment_methods.id'))
    
    # Detalles del pago
    amount = db.Column(db.Numeric(10, 2), nullable=False)
    currency = db.Column(db.String(3), default='USD')
    payment_date = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Información del procesador
    processor = db.Column(db.String(50))  # stripe, paypal, manual
    transaction_id = db.Column(db.String(200))
    processor_fee = db.Column(db.Numeric(10, 2), default=0.0)
    
    # Estado
    status = db.Column(db.String(20), default='pending')  # pending, completed, failed, refunded
    failure_reason = db.Column(db.Text)
    
    # Metadatos
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relaciones
    payment_method = db.relationship('PaymentMethod', backref='payments')
    
    def to_dict(self):
        return {
            'id': self.id,
            'payment_key': self.payment_key,
            'invoice_id': self.invoice_id,
            'payment_method_id': self.payment_method_id,
            'amount': float(self.amount) if self.amount else 0.0,
            'currency': self.currency,
            'payment_date': self.payment_date.isoformat() if self.payment_date else None,
            'processor': self.processor,
            'transaction_id': self.transaction_id,
            'processor_fee': float(self.processor_fee) if self.processor_fee else 0.0,
            'status': self.status,
            'failure_reason': self.failure_reason,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }

