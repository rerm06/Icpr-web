import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { 
  Target, 
  Eye, 
  Heart, 
  Award, 
  Users, 
  TrendingUp,
  CheckCircle,
  Lightbulb,
  Shield,
  Zap
} from 'lucide-react'

const AboutPage = () => {
  const values = [
    {
      icon: <Lightbulb className="h-8 w-8 text-blue-600" />,
      title: "Innovación",
      description: "Buscamos constantemente nuevas formas de resolver problemas empresariales con tecnología de vanguardia."
    },
    {
      icon: <Shield className="h-8 w-8 text-green-600" />,
      title: "Confiabilidad",
      description: "Construimos soluciones robustas y seguras que nuestros clientes pueden confiar para sus operaciones críticas."
    },
    {
      icon: <Users className="h-8 w-8 text-purple-600" />,
      title: "Colaboración",
      description: "Trabajamos estrechamente con nuestros clientes como socios estratégicos en su transformación digital."
    },
    {
      icon: <Zap className="h-8 w-8 text-orange-600" />,
      title: "Eficiencia",
      description: "Optimizamos procesos para maximizar la productividad y minimizar los costos operativos."
    }
  ]

  const achievements = [
    { number: "150%", label: "ROI Promedio para Clientes" },
    { number: "50+", label: "Proyectos Completados" },
    { number: "95%", label: "Satisfacción del Cliente" },
    { number: "24/7", label: "Soporte Disponible" }
  ]

  const certifications = [
    "Certificación en Automatización de Procesos",
    "Especialización en Inteligencia Artificial",
    "Certificación en Seguridad de Datos PCI DSS",
    "Partner Certificado de Google Cloud",
    "Especialista en Transformación Digital"
  ]

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-blue-50 via-white to-purple-50 py-20">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-4xl mx-auto">
            <h1 className="text-4xl lg:text-5xl font-bold text-gray-900 mb-6">
              Sobre{' '}
              <span className="bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                InnovAi Solutions
              </span>
            </h1>
            <p className="text-xl text-gray-600 mb-8">
              Somos pioneros en automatización inteligente y transformación digital, 
              ayudando a empresas a alcanzar su máximo potencial a través de la tecnología.
            </p>
          </div>
        </div>
      </section>

      {/* Mission & Vision */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            <Card className="border-l-4 border-l-blue-600">
              <CardHeader>
                <div className="flex items-center space-x-3">
                  <Target className="h-8 w-8 text-blue-600" />
                  <CardTitle className="text-2xl">Nuestra Misión</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600 text-lg leading-relaxed">
                  Ser el aliado estratégico en la adopción de tecnologías inteligentes para la 
                  transformación digital empresarial, proporcionando soluciones personalizadas 
                  que mejoran la eficiencia, reducen costos y impulsan el crecimiento sostenible.
                </p>
              </CardContent>
            </Card>

            <Card className="border-l-4 border-l-purple-600">
              <CardHeader>
                <div className="flex items-center space-x-3">
                  <Eye className="h-8 w-8 text-purple-600" />
                  <CardTitle className="text-2xl">Nuestra Visión</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600 text-lg leading-relaxed">
                  Convertirnos en líderes reconocidos en la industria de la automatización 
                  inteligente y la inteligencia artificial, siendo la primera opción para 
                  empresas que buscan transformar sus operaciones y alcanzar la excelencia digital.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Values */}
      <section className="py-20 bg-gray-50">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">
              Nuestros Valores
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Los principios que guían cada decisión y acción en nuestra empresa
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {values.map((value, index) => (
              <Card key={index} className="group hover:shadow-lg transition-shadow duration-300">
                <CardHeader>
                  <div className="flex items-center space-x-4">
                    <div className="p-3 bg-gray-100 rounded-lg group-hover:bg-blue-50 transition-colors">
                      {value.icon}
                    </div>
                    <CardTitle className="text-xl">{value.title}</CardTitle>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600">{value.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Leadership */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">
              Liderazgo
            </h2>
            <p className="text-xl text-gray-600">
              Conoce al equipo que lidera la innovación en InnovAi Solutions
            </p>
          </div>

          <div className="max-w-4xl mx-auto">
            <Card className="overflow-hidden">
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 p-8">
                <div className="lg:col-span-1">
                  <img 
                    src="/src/assets/images/equipo_trabajo.jpg" 
                    alt="René E. Rey Meléndez" 
                    className="w-full h-64 object-cover rounded-lg"
                  />
                </div>
                <div className="lg:col-span-2 space-y-4">
                  <div>
                    <h3 className="text-2xl font-bold text-gray-900">René E. Rey Meléndez</h3>
                    <p className="text-lg text-blue-600 font-medium">Fundador y CEO</p>
                    <Badge variant="secondary" className="mt-2">Director Escolar y Tecnología Educativa</Badge>
                  </div>
                  <p className="text-gray-600 leading-relaxed">
                    Experto en tecnología, automatización, innovación y transformación digital 
                    con amplia experiencia en diversas industrias. René lidera la visión estratégica 
                    de InnovAi Solutions, combinando su experiencia en educación y tecnología para 
                    crear soluciones que realmente transforman organizaciones.
                  </p>
                  <div className="space-y-2">
                    <h4 className="font-semibold text-gray-900">Especialidades:</h4>
                    <ul className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-sm">
                      {[
                        "Automatización de Procesos",
                        "Inteligencia Artificial",
                        "Transformación Digital",
                        "Diseño Instruccional",
                        "Gestión de Proyectos",
                        "Liderazgo Tecnológico"
                      ].map((specialty, idx) => (
                        <li key={idx} className="flex items-center space-x-2">
                          <CheckCircle className="h-4 w-4 text-green-500" />
                          <span className="text-gray-700">{specialty}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </div>
            </Card>
          </div>
        </div>
      </section>

      {/* Achievements */}
      <section className="py-20 bg-gray-50">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">
              Nuestros Logros
            </h2>
            <p className="text-xl text-gray-600">
              Resultados que demuestran nuestro compromiso con la excelencia
            </p>
          </div>

          <div className="grid grid-cols-2 lg:grid-cols-4 gap-8 mb-16">
            {achievements.map((achievement, index) => (
              <div key={index} className="text-center">
                <div className="text-3xl lg:text-4xl font-bold text-blue-600 mb-2">
                  {achievement.number}
                </div>
                <div className="text-gray-600 font-medium">
                  {achievement.label}
                </div>
              </div>
            ))}
          </div>

          <div className="max-w-4xl mx-auto">
            <Card>
              <CardHeader>
                <CardTitle className="text-2xl text-center flex items-center justify-center space-x-2">
                  <Award className="h-6 w-6 text-yellow-600" />
                  <span>Certificaciones y Reconocimientos</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {certifications.map((cert, index) => (
                    <div key={index} className="flex items-center space-x-2">
                      <CheckCircle className="h-5 w-5 text-green-500" />
                      <span className="text-gray-700">{cert}</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Company Story */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-4xl mx-auto">
            <div className="text-center mb-12">
              <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">
                Nuestra Historia
              </h2>
              <p className="text-xl text-gray-600">
                El camino hacia la transformación digital empresarial
              </p>
            </div>

            <div className="space-y-8">
              <Card>
                <CardContent className="p-8">
                  <h3 className="text-xl font-semibold text-gray-900 mb-4">El Comienzo</h3>
                  <p className="text-gray-600 leading-relaxed">
                    InnovAi Solutions nació de la visión de democratizar el acceso a tecnologías 
                    avanzadas de automatización e inteligencia artificial. Fundada por René E. Rey Meléndez, 
                    un experto en tecnología educativa y transformación digital, la empresa comenzó 
                    con la misión de ayudar a organizaciones de todos los tamaños a aprovechar el 
                    poder de la automatización inteligente.
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-8">
                  <h3 className="text-xl font-semibold text-gray-900 mb-4">Nuestro Enfoque</h3>
                  <p className="text-gray-600 leading-relaxed">
                    Nos especializamos en soluciones no-code/low-code que permiten implementaciones 
                    rápidas y rentables. Nuestro enfoque personalizado significa que cada cliente 
                    recibe una solución única, diseñada específicamente para sus necesidades y 
                    objetivos empresariales. No creemos en soluciones genéricas; cada proyecto 
                    es una oportunidad para innovar y crear valor real.
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-8">
                  <h3 className="text-xl font-semibold text-gray-900 mb-4">Hacia el Futuro</h3>
                  <p className="text-gray-600 leading-relaxed">
                    Continuamos expandiendo nuestras capacidades y alcance, estableciendo alianzas 
                    estratégicas y desarrollando nuevas soluciones que mantengan a nuestros clientes 
                    a la vanguardia de la innovación tecnológica. Nuestro objetivo es convertirnos 
                    en el socio de confianza para la transformación digital de empresas en toda 
                    América Latina y más allá.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}

export default AboutPage

