import { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card'
import { Button } from '../ui/button'
import { Input } from '../ui/input'
import { Label } from '../ui/label'
import { Textarea } from '../ui/textarea'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '../ui/dialog'
import { Badge } from '../ui/badge'
import { Calendar, Clock, User, Video, Phone, MapPin, Plus, Search, Filter } from 'lucide-react'

const CalendarModule = () => {
  const [currentDate, setCurrentDate] = useState(new Date())
  const [selectedDate, setSelectedDate] = useState(null)
  const [appointments, setAppointments] = useState([])
  const [consultants, setConsultants] = useState([])
  const [availableSlots, setAvailableSlots] = useState([])
  const [selectedConsultant, setSelectedConsultant] = useState(null)
  const [isBookingModalOpen, setIsBookingModalOpen] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const [viewMode, setViewMode] = useState('month') // month, week, day

  // Datos de ejemplo para consultores
  useEffect(() => {
    setConsultants([
      {
        id: 1,
        name: 'Dr. María González',
        specialization: 'Transformación Digital',
        email: 'maria@innovaisolutions.com',
        hourly_rate: 150,
        timezone: 'UTC-5',
        is_active: true
      },
      {
        id: 2,
        name: 'Ing. Carlos Rodríguez',
        specialization: 'Automatización e IA',
        email: 'carlos@innovaisolutions.com',
        hourly_rate: 175,
        timezone: 'UTC-5',
        is_active: true
      },
      {
        id: 3,
        name: 'Dra. Ana Martínez',
        specialization: 'Diseño Instruccional',
        email: 'ana@innovaisolutions.com',
        hourly_rate: 125,
        timezone: 'UTC-5',
        is_active: true
      }
    ])

    // Datos de ejemplo para citas
    setAppointments([
      {
        id: 1,
        title: 'Consulta Inicial - Automatización',
        consultant_id: 1,
        scheduled_date: '2025-06-30',
        scheduled_time: '10:00',
        duration_minutes: 60,
        status: 'confirmed',
        purpose: 'consultation',
        meeting_type: 'video'
      },
      {
        id: 2,
        title: 'Revisión de Proyecto',
        consultant_id: 2,
        scheduled_date: '2025-07-02',
        scheduled_time: '14:30',
        duration_minutes: 90,
        status: 'scheduled',
        purpose: 'review',
        meeting_type: 'video'
      }
    ])
  }, [])

  const [newAppointment, setNewAppointment] = useState({
    title: '',
    description: '',
    purpose: '',
    notes: '',
    consultant_id: '',
    scheduled_date: '',
    scheduled_time: '',
    duration_minutes: 60,
    meeting_type: 'video'
  })

  // Generar calendario del mes
  const generateCalendarDays = () => {
    const year = currentDate.getFullYear()
    const month = currentDate.getMonth()
    const firstDay = new Date(year, month, 1)
    const lastDay = new Date(year, month + 1, 0)
    const startDate = new Date(firstDay)
    startDate.setDate(startDate.getDate() - firstDay.getDay())

    const days = []
    const current = new Date(startDate)

    for (let i = 0; i < 42; i++) {
      days.push(new Date(current))
      current.setDate(current.getDate() + 1)
    }

    return days
  }

  // Obtener citas para una fecha específica
  const getAppointmentsForDate = (date) => {
    const dateStr = date.toISOString().split('T')[0]
    return appointments.filter(apt => apt.scheduled_date === dateStr)
  }

  // Buscar slots disponibles
  const searchAvailableSlots = async (consultantId, date) => {
    setIsLoading(true)
    try {
      // Simular llamada a API
      const startDate = date.toISOString().split('T')[0]
      const endDate = new Date(date)
      endDate.setDate(endDate.getDate() + 7)
      
      // Generar slots de ejemplo
      const slots = []
      for (let i = 0; i < 7; i++) {
        const slotDate = new Date(date)
        slotDate.setDate(slotDate.getDate() + i)
        
        // Horarios de 9 AM a 5 PM
        for (let hour = 9; hour < 17; hour++) {
          for (let minute = 0; minute < 60; minute += 30) {
            const timeStr = `${hour.toString().padStart(2, '0')}:${minute.toString().padStart(2, '0')}`
            
            // Verificar si hay conflicto con citas existentes
            const hasConflict = appointments.some(apt => 
              apt.consultant_id === consultantId &&
              apt.scheduled_date === slotDate.toISOString().split('T')[0] &&
              apt.scheduled_time === timeStr
            )
            
            if (!hasConflict && Math.random() > 0.3) { // 70% de disponibilidad
              slots.push({
                date: slotDate.toISOString().split('T')[0],
                time: timeStr,
                datetime: `${slotDate.toISOString().split('T')[0]}T${timeStr}`,
                duration_minutes: 60
              })
            }
          }
        }
      }
      
      setAvailableSlots(slots)
    } catch (error) {
      console.error('Error fetching available slots:', error)
    } finally {
      setIsLoading(false)
    }
  }

  // Crear nueva cita
  const createAppointment = async () => {
    setIsLoading(true)
    try {
      const appointmentData = {
        ...newAppointment,
        user_id: 1, // Usuario actual
        id: appointments.length + 1,
        status: 'scheduled',
        client_confirmed: false,
        consultant_confirmed: false
      }

      setAppointments([...appointments, appointmentData])
      setIsBookingModalOpen(false)
      setNewAppointment({
        title: '',
        description: '',
        purpose: '',
        notes: '',
        consultant_id: '',
        scheduled_date: '',
        scheduled_time: '',
        duration_minutes: 60,
        meeting_type: 'video'
      })
      
      // Mostrar confirmación
      alert('Cita agendada exitosamente. Se enviará confirmación por email.')
    } catch (error) {
      console.error('Error creating appointment:', error)
      alert('Error al agendar la cita. Intente nuevamente.')
    } finally {
      setIsLoading(false)
    }
  }

  const calendarDays = generateCalendarDays()
  const monthNames = [
    'Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio',
    'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'
  ]

  const dayNames = ['Dom', 'Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb']

  return (
    <div className="space-y-6">
      {/* Header del Calendario */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="text-3xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
            Calendario de Citas
          </h2>
          <p className="text-gray-600 dark:text-gray-400">
            Agenda y gestiona tus citas con consultores especializados
          </p>
        </div>
        
        <div className="flex gap-2">
          <Dialog open={isBookingModalOpen} onOpenChange={setIsBookingModalOpen}>
            <DialogTrigger asChild>
              <Button className="neo-button bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700">
                <Plus className="w-4 h-4 mr-2" />
                Nueva Cita
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto neo-card">
              <DialogHeader>
                <DialogTitle className="text-2xl font-bold text-center bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                  Agendar Nueva Cita
                </DialogTitle>
              </DialogHeader>
              
              <div className="space-y-6 p-4">
                {/* Selección de Consultor */}
                <div className="space-y-2">
                  <Label htmlFor="consultant">Consultor Asignado</Label>
                  <Select 
                    value={newAppointment.consultant_id} 
                    onValueChange={(value) => {
                      setNewAppointment({...newAppointment, consultant_id: value})
                      setSelectedConsultant(consultants.find(c => c.id === parseInt(value)))
                    }}
                  >
                    <SelectTrigger className="neo-input">
                      <SelectValue placeholder="Selecciona un consultor" />
                    </SelectTrigger>
                    <SelectContent>
                      {consultants.map(consultant => (
                        <SelectItem key={consultant.id} value={consultant.id.toString()}>
                          <div className="flex items-center gap-2">
                            <User className="w-4 h-4" />
                            <div>
                              <div className="font-medium">{consultant.name}</div>
                              <div className="text-sm text-gray-500">{consultant.specialization}</div>
                            </div>
                          </div>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* Información del Consultor Seleccionado */}
                {selectedConsultant && (
                  <Card className="neo-card bg-gradient-to-r from-blue-50 to-purple-50 dark:from-blue-900/20 dark:to-purple-900/20">
                    <CardContent className="p-4">
                      <div className="flex items-center gap-3">
                        <div className="w-12 h-12 rounded-full bg-gradient-to-r from-blue-500 to-purple-600 flex items-center justify-center text-white font-bold">
                          {selectedConsultant.name.split(' ').map(n => n[0]).join('')}
                        </div>
                        <div>
                          <h3 className="font-semibold">{selectedConsultant.name}</h3>
                          <p className="text-sm text-gray-600">{selectedConsultant.specialization}</p>
                          <p className="text-sm text-green-600 font-medium">${selectedConsultant.hourly_rate}/hora</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                )}

                {/* Búsqueda de Disponibilidad */}
                {selectedConsultant && (
                  <div className="space-y-4">
                    <div className="flex gap-2">
                      <Input
                        type="date"
                        value={selectedDate ? selectedDate.toISOString().split('T')[0] : ''}
                        onChange={(e) => {
                          const date = new Date(e.target.value)
                          setSelectedDate(date)
                          searchAvailableSlots(selectedConsultant.id, date)
                        }}
                        className="neo-input"
                        min={new Date().toISOString().split('T')[0]}
                      />
                      <Button 
                        onClick={() => selectedDate && searchAvailableSlots(selectedConsultant.id, selectedDate)}
                        disabled={!selectedDate || isLoading}
                        className="neo-button"
                      >
                        <Search className="w-4 h-4 mr-2" />
                        Buscar
                      </Button>
                    </div>

                    {/* Slots Disponibles */}
                    {availableSlots.length > 0 && (
                      <div className="space-y-2">
                        <Label>Horarios Disponibles</Label>
                        <div className="grid grid-cols-3 gap-2 max-h-40 overflow-y-auto">
                          {availableSlots.slice(0, 12).map((slot, index) => (
                            <Button
                              key={index}
                              variant={newAppointment.scheduled_time === slot.time && 
                                      newAppointment.scheduled_date === slot.date ? "default" : "outline"}
                              className="neo-button text-sm"
                              onClick={() => {
                                setNewAppointment({
                                  ...newAppointment,
                                  scheduled_date: slot.date,
                                  scheduled_time: slot.time
                                })
                              }}
                            >
                              <Clock className="w-3 h-3 mr-1" />
                              {slot.time}
                            </Button>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                )}

                {/* Detalles de la Cita */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="title">Título de la Cita</Label>
                    <Input
                      id="title"
                      value={newAppointment.title}
                      onChange={(e) => setNewAppointment({...newAppointment, title: e.target.value})}
                      placeholder="Ej: Consulta sobre automatización"
                      className="neo-input"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="purpose">Propósito</Label>
                    <Select 
                      value={newAppointment.purpose} 
                      onValueChange={(value) => setNewAppointment({...newAppointment, purpose: value})}
                    >
                      <SelectTrigger className="neo-input">
                        <SelectValue placeholder="Selecciona el propósito" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="consultation">Consulta Inicial</SelectItem>
                        <SelectItem value="review">Revisión de Proyecto</SelectItem>
                        <SelectItem value="support">Soporte Técnico</SelectItem>
                        <SelectItem value="training">Capacitación</SelectItem>
                        <SelectItem value="follow-up">Seguimiento</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="duration">Duración (minutos)</Label>
                    <Select 
                      value={newAppointment.duration_minutes.toString()} 
                      onValueChange={(value) => setNewAppointment({...newAppointment, duration_minutes: parseInt(value)})}
                    >
                      <SelectTrigger className="neo-input">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="30">30 minutos</SelectItem>
                        <SelectItem value="60">1 hora</SelectItem>
                        <SelectItem value="90">1.5 horas</SelectItem>
                        <SelectItem value="120">2 horas</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="meeting_type">Tipo de Reunión</Label>
                    <Select 
                      value={newAppointment.meeting_type} 
                      onValueChange={(value) => setNewAppointment({...newAppointment, meeting_type: value})}
                    >
                      <SelectTrigger className="neo-input">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="video">
                          <div className="flex items-center gap-2">
                            <Video className="w-4 h-4" />
                            Videollamada
                          </div>
                        </SelectItem>
                        <SelectItem value="phone">
                          <div className="flex items-center gap-2">
                            <Phone className="w-4 h-4" />
                            Llamada Telefónica
                          </div>
                        </SelectItem>
                        <SelectItem value="in-person">
                          <div className="flex items-center gap-2">
                            <MapPin className="w-4 h-4" />
                            Presencial
                          </div>
                        </SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="description">Descripción</Label>
                  <Textarea
                    id="description"
                    value={newAppointment.description}
                    onChange={(e) => setNewAppointment({...newAppointment, description: e.target.value})}
                    placeholder="Describe brevemente el tema a tratar..."
                    className="neo-input"
                    rows={3}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="notes">Notas Adicionales</Label>
                  <Textarea
                    id="notes"
                    value={newAppointment.notes}
                    onChange={(e) => setNewAppointment({...newAppointment, notes: e.target.value})}
                    placeholder="Comentarios o información adicional..."
                    className="neo-input"
                    rows={2}
                  />
                </div>

                {/* Botones de Acción */}
                <div className="flex gap-2 pt-4">
                  <Button 
                    onClick={createAppointment}
                    disabled={!newAppointment.title || !newAppointment.consultant_id || 
                             !newAppointment.scheduled_date || !newAppointment.scheduled_time || isLoading}
                    className="flex-1 neo-button bg-gradient-to-r from-green-500 to-blue-600 hover:from-green-600 hover:to-blue-700"
                  >
                    {isLoading ? 'Agendando...' : 'Agendar Cita'}
                  </Button>
                  <Button 
                    variant="outline" 
                    onClick={() => setIsBookingModalOpen(false)}
                    className="neo-button"
                  >
                    Cancelar
                  </Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* Navegación del Calendario */}
      <Card className="neo-card">
        <CardHeader>
          <div className="flex justify-between items-center">
            <div className="flex items-center gap-4">
              <Button
                variant="outline"
                onClick={() => {
                  const newDate = new Date(currentDate)
                  newDate.setMonth(newDate.getMonth() - 1)
                  setCurrentDate(newDate)
                }}
                className="neo-button"
              >
                ←
              </Button>
              <h3 className="text-xl font-semibold">
                {monthNames[currentDate.getMonth()]} {currentDate.getFullYear()}
              </h3>
              <Button
                variant="outline"
                onClick={() => {
                  const newDate = new Date(currentDate)
                  newDate.setMonth(newDate.getMonth() + 1)
                  setCurrentDate(newDate)
                }}
                className="neo-button"
              >
                →
              </Button>
            </div>
            
            <Button
              variant="outline"
              onClick={() => setCurrentDate(new Date())}
              className="neo-button"
            >
              Hoy
            </Button>
          </div>
        </CardHeader>
        
        <CardContent>
          {/* Días de la semana */}
          <div className="grid grid-cols-7 gap-1 mb-2">
            {dayNames.map(day => (
              <div key={day} className="p-2 text-center font-medium text-gray-600 dark:text-gray-400">
                {day}
              </div>
            ))}
          </div>
          
          {/* Días del calendario */}
          <div className="grid grid-cols-7 gap-1">
            {calendarDays.map((day, index) => {
              const isCurrentMonth = day.getMonth() === currentDate.getMonth()
              const isToday = day.toDateString() === new Date().toDateString()
              const dayAppointments = getAppointmentsForDate(day)
              
              return (
                <div
                  key={index}
                  className={`
                    min-h-[80px] p-2 border rounded-lg cursor-pointer transition-all duration-200
                    ${isCurrentMonth ? 'bg-white dark:bg-gray-800' : 'bg-gray-50 dark:bg-gray-900'}
                    ${isToday ? 'ring-2 ring-blue-500 bg-blue-50 dark:bg-blue-900/20' : ''}
                    hover:bg-blue-50 dark:hover:bg-blue-900/20 hover:scale-105
                    neo-card
                  `}
                  onClick={() => setSelectedDate(day)}
                >
                  <div className={`text-sm font-medium ${isCurrentMonth ? '' : 'text-gray-400'}`}>
                    {day.getDate()}
                  </div>
                  
                  {/* Citas del día */}
                  <div className="mt-1 space-y-1">
                    {dayAppointments.slice(0, 2).map(appointment => (
                      <div
                        key={appointment.id}
                        className={`
                          text-xs p-1 rounded truncate
                          ${appointment.status === 'confirmed' 
                            ? 'bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-300' 
                            : 'bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-300'
                          }
                        `}
                      >
                        {appointment.scheduled_time} - {appointment.title}
                      </div>
                    ))}
                    {dayAppointments.length > 2 && (
                      <div className="text-xs text-gray-500">
                        +{dayAppointments.length - 2} más
                      </div>
                    )}
                  </div>
                </div>
              )
            })}
          </div>
        </CardContent>
      </Card>

      {/* Lista de Próximas Citas */}
      <Card className="neo-card">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Calendar className="w-5 h-5" />
            Próximas Citas
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {appointments
              .filter(apt => new Date(apt.scheduled_date) >= new Date())
              .sort((a, b) => new Date(a.scheduled_date + 'T' + a.scheduled_time) - new Date(b.scheduled_date + 'T' + b.scheduled_time))
              .slice(0, 5)
              .map(appointment => {
                const consultant = consultants.find(c => c.id === appointment.consultant_id)
                return (
                  <div key={appointment.id} className="flex items-center justify-between p-4 border rounded-lg neo-card hover:shadow-lg transition-all duration-200">
                    <div className="flex items-center gap-4">
                      <div className="w-12 h-12 rounded-full bg-gradient-to-r from-blue-500 to-purple-600 flex items-center justify-center text-white font-bold">
                        {consultant?.name.split(' ').map(n => n[0]).join('') || 'C'}
                      </div>
                      <div>
                        <h4 className="font-semibold">{appointment.title}</h4>
                        <p className="text-sm text-gray-600">
                          {consultant?.name} • {appointment.scheduled_date} a las {appointment.scheduled_time}
                        </p>
                        <div className="flex items-center gap-2 mt-1">
                          <Badge variant={appointment.status === 'confirmed' ? 'default' : 'secondary'}>
                            {appointment.status === 'confirmed' ? 'Confirmada' : 'Programada'}
                          </Badge>
                          <Badge variant="outline">
                            {appointment.meeting_type === 'video' ? 'Video' : 
                             appointment.meeting_type === 'phone' ? 'Teléfono' : 'Presencial'}
                          </Badge>
                        </div>
                      </div>
                    </div>
                    <div className="flex gap-2">
                      <Button variant="outline" size="sm" className="neo-button">
                        Editar
                      </Button>
                      <Button variant="outline" size="sm" className="neo-button">
                        Cancelar
                      </Button>
                    </div>
                  </div>
                )
              })}
            
            {appointments.filter(apt => new Date(apt.scheduled_date) >= new Date()).length === 0 && (
              <div className="text-center py-8 text-gray-500">
                <Calendar className="w-12 h-12 mx-auto mb-4 opacity-50" />
                <p>No tienes citas programadas</p>
                <p className="text-sm">Agenda una nueva cita con tu consultor</p>
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

export default CalendarModule

