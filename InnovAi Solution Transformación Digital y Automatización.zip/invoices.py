from flask import Blueprint, jsonify, request
from src.models.user import Invoice, db
from datetime import datetime

invoices_bp = Blueprint('invoices', __name__)

@invoices_bp.route('/invoices', methods=['GET'])
def get_invoices():
    user_id = request.args.get('user_id')
    status = request.args.get('status')
    
    query = Invoice.query
    if user_id:
        query = query.filter_by(user_id=user_id)
    if status:
        query = query.filter_by(status=status)
    
    invoices = query.order_by(Invoice.created_at.desc()).all()
    return jsonify([invoice.to_dict() for invoice in invoices])

@invoices_bp.route('/invoices', methods=['POST'])
def create_invoice():
    data = request.json
    
    # Generar número de factura automático
    last_invoice = Invoice.query.order_by(Invoice.id.desc()).first()
    invoice_number = f"INV-2024-{(last_invoice.id + 1):03d}" if last_invoice else "INV-2024-001"
    
    invoice = Invoice(
        user_id=data['user_id'],
        invoice_number=invoice_number,
        amount=data['amount'],
        status=data.get('status', 'pending'),
        due_date=datetime.fromisoformat(data['due_date']) if data.get('due_date') else None
    )
    db.session.add(invoice)
    db.session.commit()
    return jsonify(invoice.to_dict()), 201

@invoices_bp.route('/invoices/<int:invoice_id>', methods=['GET'])
def get_invoice(invoice_id):
    invoice = Invoice.query.get_or_404(invoice_id)
    return jsonify(invoice.to_dict())

@invoices_bp.route('/invoices/<int:invoice_id>', methods=['PUT'])
def update_invoice(invoice_id):
    invoice = Invoice.query.get_or_404(invoice_id)
    data = request.json
    
    invoice.amount = data.get('amount', invoice.amount)
    invoice.status = data.get('status', invoice.status)
    if data.get('due_date'):
        invoice.due_date = datetime.fromisoformat(data['due_date'])
    
    # Si se marca como pagada, registrar fecha de pago
    if data.get('status') == 'paid' and not invoice.paid_at:
        invoice.paid_at = datetime.utcnow()
        invoice.payment_method = data.get('payment_method')
    
    db.session.commit()
    return jsonify(invoice.to_dict())

@invoices_bp.route('/invoices/<int:invoice_id>/pay', methods=['POST'])
def pay_invoice(invoice_id):
    invoice = Invoice.query.get_or_404(invoice_id)
    data = request.json
    
    # Simular procesamiento de pago
    payment_method = data.get('payment_method', 'stripe')
    
    invoice.status = 'paid'
    invoice.paid_at = datetime.utcnow()
    invoice.payment_method = payment_method
    
    db.session.commit()
    
    return jsonify({
        'success': True,
        'message': 'Pago procesado exitosamente',
        'invoice': invoice.to_dict()
    })

@invoices_bp.route('/invoices/<int:invoice_id>', methods=['DELETE'])
def delete_invoice(invoice_id):
    invoice = Invoice.query.get_or_404(invoice_id)
    db.session.delete(invoice)
    db.session.commit()
    return '', 204

