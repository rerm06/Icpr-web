import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Label } from '@/components/ui/label'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Checkbox } from '@/components/ui/checkbox'
import { 
  Phone, 
  Mail, 
  MapPin, 
  Clock, 
  MessageSquare, 
  Calendar,
  Send,
  CheckCircle
} from 'lucide-react'

const ContactPage = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    company: '',
    phone: '',
    service: '',
    message: '',
    contactPreference: '',
    budget: '',
    timeline: ''
  })

  const [isSubmitted, setIsSubmitted] = useState(false)

  const handleInputChange = (field, value) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }))
  }

  const handleSubmit = (e) => {
    e.preventDefault()
    // Aquí iría la lógica de envío del formulario
    console.log('Form submitted:', formData)
    setIsSubmitted(true)
  }

  const services = [
    "Automatización Inteligente",
    "Chatbots Personalizados",
    "Consultoría en Transformación Digital",
    "Diseño Instruccional con IA",
    "Integración de Sistemas",
    "Análisis de Datos e IA",
    "Otro"
  ]

  const budgetRanges = [
    "Menos de $5,000",
    "$5,000 - $15,000",
    "$15,000 - $50,000",
    "$50,000 - $100,000",
    "Más de $100,000"
  ]

  const timelines = [
    "Inmediato (1-2 semanas)",
    "Corto plazo (1-3 meses)",
    "Mediano plazo (3-6 meses)",
    "Largo plazo (6+ meses)"
  ]

  const contactMethods = [
    { id: 'email', label: 'Email', icon: <Mail className="h-4 w-4" /> },
    { id: 'phone', label: 'Teléfono', icon: <Phone className="h-4 w-4" /> },
    { id: 'whatsapp', label: 'WhatsApp', icon: <MessageSquare className="h-4 w-4" /> }
  ]

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-blue-50 via-white to-purple-50 py-20">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-4xl mx-auto">
            <h1 className="text-4xl lg:text-5xl font-bold text-gray-900 mb-6">
              Hablemos de su{' '}
              <span className="bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                Transformación Digital
              </span>
            </h1>
            <p className="text-xl text-gray-600 mb-8">
              Estamos aquí para ayudarle a descubrir cómo la automatización inteligente 
              puede transformar su negocio. Comience con una consulta gratuita.
            </p>
          </div>
        </div>
      </section>

      <section className="py-20 bg-white">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
            {/* Contact Form */}
            <div className="lg:col-span-2">
              <Card>
                <CardHeader>
                  <CardTitle className="text-2xl">Solicitar Consulta Gratuita</CardTitle>
                  <p className="text-gray-600">
                    Complete el formulario y nos pondremos en contacto en menos de 24 horas.
                  </p>
                </CardHeader>
                <CardContent>
                  {!isSubmitted ? (
                    <form onSubmit={handleSubmit} className="space-y-6">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label htmlFor="name">Nombre completo *</Label>
                          <Input
                            id="name"
                            value={formData.name}
                            onChange={(e) => handleInputChange('name', e.target.value)}
                            required
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="email">Email empresarial *</Label>
                          <Input
                            id="email"
                            type="email"
                            value={formData.email}
                            onChange={(e) => handleInputChange('email', e.target.value)}
                            required
                          />
                        </div>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label htmlFor="company">Empresa *</Label>
                          <Input
                            id="company"
                            value={formData.company}
                            onChange={(e) => handleInputChange('company', e.target.value)}
                            required
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="phone">Teléfono</Label>
                          <Input
                            id="phone"
                            value={formData.phone}
                            onChange={(e) => handleInputChange('phone', e.target.value)}
                          />
                        </div>
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="service">Servicio de interés *</Label>
                        <Select onValueChange={(value) => handleInputChange('service', value)}>
                          <SelectTrigger>
                            <SelectValue placeholder="Seleccione un servicio" />
                          </SelectTrigger>
                          <SelectContent>
                            {services.map((service) => (
                              <SelectItem key={service} value={service}>
                                {service}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label htmlFor="budget">Presupuesto estimado</Label>
                          <Select onValueChange={(value) => handleInputChange('budget', value)}>
                            <SelectTrigger>
                              <SelectValue placeholder="Seleccione rango" />
                            </SelectTrigger>
                            <SelectContent>
                              {budgetRanges.map((range) => (
                                <SelectItem key={range} value={range}>
                                  {range}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="timeline">Cronograma deseado</Label>
                          <Select onValueChange={(value) => handleInputChange('timeline', value)}>
                            <SelectTrigger>
                              <SelectValue placeholder="Seleccione cronograma" />
                            </SelectTrigger>
                            <SelectContent>
                              {timelines.map((timeline) => (
                                <SelectItem key={timeline} value={timeline}>
                                  {timeline}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="message">Describa su proyecto o necesidad *</Label>
                        <Textarea
                          id="message"
                          rows={4}
                          value={formData.message}
                          onChange={(e) => handleInputChange('message', e.target.value)}
                          placeholder="Cuéntenos sobre los desafíos que enfrenta y cómo podemos ayudarle..."
                          required
                        />
                      </div>

                      <div className="space-y-3">
                        <Label>Preferencia de contacto *</Label>
                        <div className="flex flex-wrap gap-4">
                          {contactMethods.map((method) => (
                            <div key={method.id} className="flex items-center space-x-2">
                              <Checkbox
                                id={method.id}
                                checked={formData.contactPreference === method.id}
                                onCheckedChange={(checked) => {
                                  if (checked) {
                                    handleInputChange('contactPreference', method.id)
                                  }
                                }}
                              />
                              <Label htmlFor={method.id} className="flex items-center space-x-2 cursor-pointer">
                                {method.icon}
                                <span>{method.label}</span>
                              </Label>
                            </div>
                          ))}
                        </div>
                      </div>

                      <Button type="submit" size="lg" className="w-full bg-gradient-to-r from-blue-600 to-purple-600">
                        <Send className="mr-2 h-4 w-4" />
                        Enviar Solicitud
                      </Button>

                      <p className="text-sm text-gray-500 text-center">
                        Al enviar este formulario, acepta que nos pongamos en contacto con usted 
                        para discutir su proyecto. Respetamos su privacidad.
                      </p>
                    </form>
                  ) : (
                    <div className="text-center py-12">
                      <CheckCircle className="h-16 w-16 text-green-500 mx-auto mb-4" />
                      <h3 className="text-2xl font-semibold text-gray-900 mb-2">
                        ¡Solicitud Enviada!
                      </h3>
                      <p className="text-gray-600 mb-6">
                        Gracias por su interés. Nos pondremos en contacto con usted 
                        en las próximas 24 horas para programar su consulta gratuita.
                      </p>
                      <Button 
                        onClick={() => setIsSubmitted(false)}
                        variant="outline"
                      >
                        Enviar Otra Solicitud
                      </Button>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>

            {/* Contact Information */}
            <div className="space-y-8">
              <Card>
                <CardHeader>
                  <CardTitle>Información de Contacto</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center space-x-3">
                    <Phone className="h-5 w-5 text-blue-600" />
                    <div>
                      <p className="font-medium">Teléfono</p>
                      <p className="text-gray-600">939-321-7109</p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-3">
                    <Mail className="h-5 w-5 text-blue-600" />
                    <div>
                      <p className="font-medium">Email</p>
                      <p className="text-gray-600">info@innovaisolution.io</p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-3">
                    <MapPin className="h-5 w-5 text-blue-600" />
                    <div>
                      <p className="font-medium">Ubicación</p>
                      <p className="text-gray-600">Puerto Rico</p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-3">
                    <Clock className="h-5 w-5 text-blue-600" />
                    <div>
                      <p className="font-medium">Horario</p>
                      <p className="text-gray-600">Lun - Vie: 8:00 AM - 6:00 PM</p>
                      <p className="text-gray-600">Soporte 24/7 disponible</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Calendar className="h-5 w-5" />
                    <span>Agendar Cita Directa</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600 mb-4">
                    ¿Prefiere agendar una cita directamente? Use nuestro calendario en línea.
                  </p>
                  <Button className="w-full" variant="outline">
                    Abrir Calendario
                  </Button>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Respuesta Rápida</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600 mb-4">
                    Para consultas urgentes o soporte técnico inmediato:
                  </p>
                  <div className="space-y-2">
                    <Button className="w-full bg-green-600 hover:bg-green-700">
                      <MessageSquare className="mr-2 h-4 w-4" />
                      WhatsApp Business
                    </Button>
                    <Button className="w-full" variant="outline">
                      Chat en Vivo
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-20 bg-gray-50">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">
              Preguntas Frecuentes
            </h2>
            <p className="text-xl text-gray-600">
              Respuestas a las consultas más comunes sobre nuestros servicios
            </p>
          </div>

          <div className="max-w-4xl mx-auto grid grid-cols-1 md:grid-cols-2 gap-8">
            {[
              {
                question: "¿Cuánto tiempo toma implementar una solución?",
                answer: "Dependiendo de la complejidad, entre 2-8 semanas. Proyectos simples pueden estar listos en 2 semanas."
              },
              {
                question: "¿Ofrecen soporte post-implementación?",
                answer: "Sí, incluimos soporte 24/7 y mantenimiento continuo en todos nuestros planes."
              },
              {
                question: "¿Trabajan con empresas pequeñas?",
                answer: "Absolutamente. Tenemos soluciones escalables para empresas de todos los tamaños."
              },
              {
                question: "¿Qué garantías ofrecen?",
                answer: "Garantizamos ROI positivo en el primer año o trabajamos sin costo adicional hasta lograrlo."
              }
            ].map((faq, index) => (
              <Card key={index}>
                <CardContent className="p-6">
                  <h3 className="font-semibold text-gray-900 mb-2">{faq.question}</h3>
                  <p className="text-gray-600">{faq.answer}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>
    </div>
  )
}

export default ContactPage

