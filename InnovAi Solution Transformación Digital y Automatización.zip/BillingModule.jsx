import { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card'
import { Button } from '../ui/button'
import { Input } from '../ui/input'
import { Label } from '../ui/label'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '../ui/dialog'
import { Badge } from '../ui/badge'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs'
import { 
  CreditCard, 
  Download, 
  Share, 
  Plus, 
  Trash2, 
  Calendar,
  DollarSign,
  FileText,
  AlertCircle,
  CheckCircle,
  Clock,
  Settings,
  Eye,
  X
} from 'lucide-react'

const BillingModule = () => {
  const [invoices, setInvoices] = useState([])
  const [paymentMethods, setPaymentMethods] = useState([])
  const [subscriptions, setSubscriptions] = useState([])
  const [billingStats, setBillingStats] = useState({})
  const [isAddingPaymentMethod, setIsAddingPaymentMethod] = useState(false)
  const [isPayingInvoice, setIsPayingInvoice] = useState(false)
  const [selectedInvoice, setSelectedInvoice] = useState(null)
  const [isLoading, setIsLoading] = useState(false)

  // Datos de ejemplo
  useEffect(() => {
    // Métodos de pago
    setPaymentMethods([
      {
        id: 1,
        type: 'credit_card',
        provider: 'visa',
        last_four: '4242',
        expiry_month: 12,
        expiry_year: 2026,
        cardholder_name: 'Juan Pérez',
        is_default: true,
        is_active: true,
        verified: true
      },
      {
        id: 2,
        type: 'credit_card',
        provider: 'mastercard',
        last_four: '5555',
        expiry_month: 8,
        expiry_year: 2025,
        cardholder_name: 'Juan Pérez',
        is_default: false,
        is_active: true,
        verified: true
      }
    ])

    // Suscripciones
    setSubscriptions([
      {
        id: 1,
        plan_name: 'Plan Premium',
        plan_type: 'premium',
        billing_cycle: 'monthly',
        amount: 299.99,
        currency: 'USD',
        status: 'active',
        next_billing_date: '2025-07-28',
        auto_renew: true
      },
      {
        id: 2,
        plan_name: 'Consultoría Especializada',
        plan_type: 'enterprise',
        billing_cycle: 'quarterly',
        amount: 2499.99,
        currency: 'USD',
        status: 'active',
        next_billing_date: '2025-09-15',
        auto_renew: true
      }
    ])

    // Facturas
    setInvoices([
      {
        id: 1,
        invoice_number: 'INV-2025-A1B2C3D4',
        description: 'Suscripción Plan Premium - monthly',
        total_amount: 299.99,
        currency: 'USD',
        issue_date: '2025-06-28',
        due_date: '2025-07-05',
        status: 'pending',
        payment_status: 'unpaid'
      },
      {
        id: 2,
        invoice_number: 'INV-2025-E5F6G7H8',
        description: 'Consultoría Especializada - quarterly',
        total_amount: 2499.99,
        currency: 'USD',
        issue_date: '2025-06-15',
        due_date: '2025-06-22',
        status: 'overdue',
        payment_status: 'unpaid'
      },
      {
        id: 3,
        invoice_number: 'INV-2025-I9J0K1L2',
        description: 'Suscripción Plan Premium - monthly',
        total_amount: 299.99,
        currency: 'USD',
        issue_date: '2025-05-28',
        due_date: '2025-06-05',
        paid_date: '2025-06-03',
        status: 'paid',
        payment_status: 'paid'
      }
    ])

    // Estadísticas
    setBillingStats({
      total_amount: 3099.97,
      paid_amount: 299.99,
      pending_amount: 2799.98,
      overdue_amount: 2499.99,
      active_subscriptions: 2
    })
  }, [])

  const [newPaymentMethod, setNewPaymentMethod] = useState({
    type: 'credit_card',
    provider: '',
    card_number: '',
    expiry_month: '',
    expiry_year: '',
    cvv: '',
    cardholder_name: '',
    is_default: false
  })

  // Procesar pago de factura
  const processPayment = async (invoiceId, paymentMethodId) => {
    setIsLoading(true)
    try {
      // Simular procesamiento de pago
      await new Promise(resolve => setTimeout(resolve, 2000))
      
      // Actualizar estado de la factura
      setInvoices(invoices.map(invoice => 
        invoice.id === invoiceId 
          ? { ...invoice, status: 'paid', payment_status: 'paid', paid_date: new Date().toISOString().split('T')[0] }
          : invoice
      ))
      
      setIsPayingInvoice(false)
      setSelectedInvoice(null)
      alert('Pago procesado exitosamente')
    } catch (error) {
      console.error('Error processing payment:', error)
      alert('Error al procesar el pago')
    } finally {
      setIsLoading(false)
    }
  }

  // Agregar método de pago
  const addPaymentMethod = async () => {
    setIsLoading(true)
    try {
      const newMethod = {
        id: paymentMethods.length + 1,
        ...newPaymentMethod,
        last_four: newPaymentMethod.card_number.slice(-4),
        verified: true,
        is_active: true
      }
      
      // Si es el primer método o se marca como default, actualizar otros
      if (newMethod.is_default || paymentMethods.length === 0) {
        setPaymentMethods(paymentMethods.map(method => ({ ...method, is_default: false })))
        newMethod.is_default = true
      }
      
      setPaymentMethods([...paymentMethods, newMethod])
      setIsAddingPaymentMethod(false)
      setNewPaymentMethod({
        type: 'credit_card',
        provider: '',
        card_number: '',
        expiry_month: '',
        expiry_year: '',
        cvv: '',
        cardholder_name: '',
        is_default: false
      })
      
      alert('Método de pago agregado exitosamente')
    } catch (error) {
      console.error('Error adding payment method:', error)
      alert('Error al agregar método de pago')
    } finally {
      setIsLoading(false)
    }
  }

  // Cancelar suscripción
  const cancelSubscription = async (subscriptionId) => {
    if (confirm('¿Estás seguro de que deseas cancelar esta suscripción?')) {
      setSubscriptions(subscriptions.map(sub => 
        sub.id === subscriptionId 
          ? { ...sub, status: 'cancelled', auto_renew: false }
          : sub
      ))
      alert('Suscripción cancelada exitosamente')
    }
  }

  // Descargar factura
  const downloadInvoice = async (invoiceId) => {
    try {
      // Simular descarga
      alert(`Descargando factura ${invoices.find(inv => inv.id === invoiceId)?.invoice_number}...`)
    } catch (error) {
      console.error('Error downloading invoice:', error)
      alert('Error al descargar la factura')
    }
  }

  // Compartir factura
  const shareInvoice = async (invoiceId) => {
    const email = prompt('Ingresa el email para compartir la factura:')
    if (email) {
      try {
        // Simular envío
        alert(`Factura enviada a ${email}`)
      } catch (error) {
        console.error('Error sharing invoice:', error)
        alert('Error al compartir la factura')
      }
    }
  }

  const getStatusBadge = (status) => {
    const statusConfig = {
      paid: { variant: 'default', color: 'bg-green-500', text: 'Pagada' },
      pending: { variant: 'secondary', color: 'bg-yellow-500', text: 'Pendiente' },
      overdue: { variant: 'destructive', color: 'bg-red-500', text: 'Vencida' },
      cancelled: { variant: 'outline', color: 'bg-gray-500', text: 'Cancelada' }
    }
    
    const config = statusConfig[status] || statusConfig.pending
    return <Badge variant={config.variant}>{config.text}</Badge>
  }

  const getSubscriptionStatusBadge = (status) => {
    const statusConfig = {
      active: { variant: 'default', text: 'Activa' },
      cancelled: { variant: 'destructive', text: 'Cancelada' },
      paused: { variant: 'secondary', text: 'Pausada' },
      expired: { variant: 'outline', text: 'Expirada' }
    }
    
    const config = statusConfig[status] || statusConfig.active
    return <Badge variant={config.variant}>{config.text}</Badge>
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="text-3xl font-bold bg-gradient-to-r from-green-600 to-blue-600 bg-clip-text text-transparent">
            Facturación y Pagos
          </h2>
          <p className="text-gray-600 dark:text-gray-400">
            Gestiona tus facturas, métodos de pago y suscripciones
          </p>
        </div>
      </div>

      {/* Estadísticas de Facturación */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="neo-card">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600 dark:text-gray-400">Total Facturado</p>
                <p className="text-2xl font-bold">${billingStats.total_amount?.toFixed(2)}</p>
              </div>
              <DollarSign className="w-8 h-8 text-blue-500" />
            </div>
          </CardContent>
        </Card>

        <Card className="neo-card">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600 dark:text-gray-400">Pagado</p>
                <p className="text-2xl font-bold text-green-600">${billingStats.paid_amount?.toFixed(2)}</p>
              </div>
              <CheckCircle className="w-8 h-8 text-green-500" />
            </div>
          </CardContent>
        </Card>

        <Card className="neo-card">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600 dark:text-gray-400">Pendiente</p>
                <p className="text-2xl font-bold text-yellow-600">${billingStats.pending_amount?.toFixed(2)}</p>
              </div>
              <Clock className="w-8 h-8 text-yellow-500" />
            </div>
          </CardContent>
        </Card>

        <Card className="neo-card">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600 dark:text-gray-400">Vencido</p>
                <p className="text-2xl font-bold text-red-600">${billingStats.overdue_amount?.toFixed(2)}</p>
              </div>
              <AlertCircle className="w-8 h-8 text-red-500" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Tabs principales */}
      <Tabs defaultValue="invoices" className="space-y-6">
        <TabsList className="grid w-full grid-cols-3 neo-card">
          <TabsTrigger value="invoices" className="neo-button">Facturas</TabsTrigger>
          <TabsTrigger value="payments" className="neo-button">Métodos de Pago</TabsTrigger>
          <TabsTrigger value="subscriptions" className="neo-button">Suscripciones</TabsTrigger>
        </TabsList>

        {/* Tab de Facturas */}
        <TabsContent value="invoices" className="space-y-4">
          <Card className="neo-card">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="w-5 h-5" />
                Facturas Recientes
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {invoices.map(invoice => (
                  <div key={invoice.id} className="flex items-center justify-between p-4 border rounded-lg neo-card hover:shadow-lg transition-all duration-200">
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        <h4 className="font-semibold">{invoice.invoice_number}</h4>
                        {getStatusBadge(invoice.status)}
                      </div>
                      <p className="text-sm text-gray-600 mb-1">{invoice.description}</p>
                      <div className="flex items-center gap-4 text-sm text-gray-500">
                        <span>Emitida: {invoice.issue_date}</span>
                        <span>Vence: {invoice.due_date}</span>
                        {invoice.paid_date && <span>Pagada: {invoice.paid_date}</span>}
                      </div>
                    </div>
                    
                    <div className="flex items-center gap-4">
                      <div className="text-right">
                        <p className="text-lg font-bold">${invoice.total_amount}</p>
                        <p className="text-sm text-gray-500">{invoice.currency}</p>
                      </div>
                      
                      <div className="flex gap-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => downloadInvoice(invoice.id)}
                          className="neo-button"
                        >
                          <Download className="w-4 h-4" />
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => shareInvoice(invoice.id)}
                          className="neo-button"
                        >
                          <Share className="w-4 h-4" />
                        </Button>
                        {invoice.status !== 'paid' && (
                          <Button
                            size="sm"
                            onClick={() => {
                              setSelectedInvoice(invoice)
                              setIsPayingInvoice(true)
                            }}
                            className="neo-button bg-gradient-to-r from-green-500 to-blue-600 hover:from-green-600 hover:to-blue-700"
                          >
                            Pagar
                          </Button>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Tab de Métodos de Pago */}
        <TabsContent value="payments" className="space-y-4">
          <Card className="neo-card">
            <CardHeader>
              <div className="flex justify-between items-center">
                <CardTitle className="flex items-center gap-2">
                  <CreditCard className="w-5 h-5" />
                  Métodos de Pago
                </CardTitle>
                <Dialog open={isAddingPaymentMethod} onOpenChange={setIsAddingPaymentMethod}>
                  <DialogTrigger asChild>
                    <Button className="neo-button bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700">
                      <Plus className="w-4 h-4 mr-2" />
                      Agregar Método
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="max-w-md neo-card">
                    <DialogHeader>
                      <DialogTitle>Agregar Método de Pago</DialogTitle>
                    </DialogHeader>
                    <div className="space-y-4 p-4">
                      <div className="space-y-2">
                        <Label>Número de Tarjeta</Label>
                        <Input
                          value={newPaymentMethod.card_number}
                          onChange={(e) => setNewPaymentMethod({...newPaymentMethod, card_number: e.target.value})}
                          placeholder="1234 5678 9012 3456"
                          className="neo-input"
                        />
                      </div>
                      
                      <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label>Mes</Label>
                          <Select 
                            value={newPaymentMethod.expiry_month} 
                            onValueChange={(value) => setNewPaymentMethod({...newPaymentMethod, expiry_month: value})}
                          >
                            <SelectTrigger className="neo-input">
                              <SelectValue placeholder="MM" />
                            </SelectTrigger>
                            <SelectContent>
                              {Array.from({length: 12}, (_, i) => (
                                <SelectItem key={i+1} value={(i+1).toString().padStart(2, '0')}>
                                  {(i+1).toString().padStart(2, '0')}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>
                        
                        <div className="space-y-2">
                          <Label>Año</Label>
                          <Select 
                            value={newPaymentMethod.expiry_year} 
                            onValueChange={(value) => setNewPaymentMethod({...newPaymentMethod, expiry_year: value})}
                          >
                            <SelectTrigger className="neo-input">
                              <SelectValue placeholder="YYYY" />
                            </SelectTrigger>
                            <SelectContent>
                              {Array.from({length: 10}, (_, i) => (
                                <SelectItem key={2025+i} value={(2025+i).toString()}>
                                  {2025+i}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>
                      </div>
                      
                      <div className="space-y-2">
                        <Label>CVV</Label>
                        <Input
                          value={newPaymentMethod.cvv}
                          onChange={(e) => setNewPaymentMethod({...newPaymentMethod, cvv: e.target.value})}
                          placeholder="123"
                          className="neo-input"
                        />
                      </div>
                      
                      <div className="space-y-2">
                        <Label>Nombre del Titular</Label>
                        <Input
                          value={newPaymentMethod.cardholder_name}
                          onChange={(e) => setNewPaymentMethod({...newPaymentMethod, cardholder_name: e.target.value})}
                          placeholder="Juan Pérez"
                          className="neo-input"
                        />
                      </div>
                      
                      <div className="flex items-center space-x-2">
                        <input
                          type="checkbox"
                          id="is_default"
                          checked={newPaymentMethod.is_default}
                          onChange={(e) => setNewPaymentMethod({...newPaymentMethod, is_default: e.target.checked})}
                          className="rounded"
                        />
                        <Label htmlFor="is_default">Establecer como método predeterminado</Label>
                      </div>
                      
                      <div className="flex gap-2 pt-4">
                        <Button 
                          onClick={addPaymentMethod}
                          disabled={!newPaymentMethod.card_number || !newPaymentMethod.cardholder_name || isLoading}
                          className="flex-1 neo-button bg-gradient-to-r from-green-500 to-blue-600 hover:from-green-600 hover:to-blue-700"
                        >
                          {isLoading ? 'Agregando...' : 'Agregar Método'}
                        </Button>
                        <Button 
                          variant="outline" 
                          onClick={() => setIsAddingPaymentMethod(false)}
                          className="neo-button"
                        >
                          Cancelar
                        </Button>
                      </div>
                    </div>
                  </DialogContent>
                </Dialog>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {paymentMethods.map(method => (
                  <div key={method.id} className="flex items-center justify-between p-4 border rounded-lg neo-card">
                    <div className="flex items-center gap-4">
                      <div className="w-12 h-12 rounded-lg bg-gradient-to-r from-blue-500 to-purple-600 flex items-center justify-center">
                        <CreditCard className="w-6 h-6 text-white" />
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <h4 className="font-semibold">
                            {method.provider.toUpperCase()} •••• {method.last_four}
                          </h4>
                          {method.is_default && <Badge>Predeterminado</Badge>}
                          {method.verified && <Badge variant="outline">Verificado</Badge>}
                        </div>
                        <p className="text-sm text-gray-600">
                          {method.cardholder_name} • Expira {method.expiry_month}/{method.expiry_year}
                        </p>
                      </div>
                    </div>
                    
                    <div className="flex gap-2">
                      <Button variant="outline" size="sm" className="neo-button">
                        <Settings className="w-4 h-4" />
                      </Button>
                      <Button variant="outline" size="sm" className="neo-button text-red-600 hover:text-red-700">
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Tab de Suscripciones */}
        <TabsContent value="subscriptions" className="space-y-4">
          <Card className="neo-card">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Calendar className="w-5 h-5" />
                Suscripciones Activas
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {subscriptions.map(subscription => (
                  <div key={subscription.id} className="flex items-center justify-between p-4 border rounded-lg neo-card">
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        <h4 className="font-semibold">{subscription.plan_name}</h4>
                        {getSubscriptionStatusBadge(subscription.status)}
                      </div>
                      <div className="flex items-center gap-4 text-sm text-gray-600">
                        <span>Ciclo: {subscription.billing_cycle === 'monthly' ? 'Mensual' : 
                                     subscription.billing_cycle === 'quarterly' ? 'Trimestral' : 'Anual'}</span>
                        <span>Próximo pago: {subscription.next_billing_date}</span>
                        <span>Auto-renovación: {subscription.auto_renew ? 'Activa' : 'Inactiva'}</span>
                      </div>
                    </div>
                    
                    <div className="flex items-center gap-4">
                      <div className="text-right">
                        <p className="text-lg font-bold">${subscription.amount}</p>
                        <p className="text-sm text-gray-500">{subscription.currency}</p>
                      </div>
                      
                      <div className="flex gap-2">
                        <Button variant="outline" size="sm" className="neo-button">
                          <Settings className="w-4 h-4" />
                        </Button>
                        {subscription.status === 'active' && (
                          <Button 
                            variant="outline" 
                            size="sm" 
                            onClick={() => cancelSubscription(subscription.id)}
                            className="neo-button text-red-600 hover:text-red-700"
                          >
                            Cancelar
                          </Button>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Modal de Pago */}
      <Dialog open={isPayingInvoice} onOpenChange={setIsPayingInvoice}>
        <DialogContent className="max-w-md neo-card">
          <DialogHeader>
            <DialogTitle>Procesar Pago</DialogTitle>
          </DialogHeader>
          {selectedInvoice && (
            <div className="space-y-4 p-4">
              <div className="p-4 bg-gray-50 dark:bg-gray-800 rounded-lg">
                <h4 className="font-semibold">{selectedInvoice.invoice_number}</h4>
                <p className="text-sm text-gray-600">{selectedInvoice.description}</p>
                <p className="text-lg font-bold mt-2">${selectedInvoice.total_amount} {selectedInvoice.currency}</p>
              </div>
              
              <div className="space-y-2">
                <Label>Método de Pago</Label>
                <Select>
                  <SelectTrigger className="neo-input">
                    <SelectValue placeholder="Selecciona método de pago" />
                  </SelectTrigger>
                  <SelectContent>
                    {paymentMethods.filter(method => method.is_active).map(method => (
                      <SelectItem key={method.id} value={method.id.toString()}>
                        {method.provider.toUpperCase()} •••• {method.last_four}
                        {method.is_default && ' (Predeterminado)'}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              
              <div className="flex gap-2 pt-4">
                <Button 
                  onClick={() => processPayment(selectedInvoice.id, paymentMethods.find(m => m.is_default)?.id)}
                  disabled={isLoading}
                  className="flex-1 neo-button bg-gradient-to-r from-green-500 to-blue-600 hover:from-green-600 hover:to-blue-700"
                >
                  {isLoading ? 'Procesando...' : `Pagar $${selectedInvoice.total_amount}`}
                </Button>
                <Button 
                  variant="outline" 
                  onClick={() => setIsPayingInvoice(false)}
                  className="neo-button"
                >
                  Cancelar
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  )
}

export default BillingModule

