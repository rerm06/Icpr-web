from flask import Blueprint, jsonify, request
from src.models.user import Service, db

services_bp = Blueprint('services', __name__)

@services_bp.route('/services', methods=['GET'])
def get_services():
    user_id = request.args.get('user_id')
    if user_id:
        services = Service.query.filter_by(user_id=user_id).all()
    else:
        services = Service.query.all()
    return jsonify([service.to_dict() for service in services])

@services_bp.route('/services', methods=['POST'])
def create_service():
    data = request.json
    service = Service(
        user_id=data['user_id'],
        name=data['name'],
        service_type=data['service_type'],
        status=data.get('status', 'active'),
        monthly_cost=data.get('monthly_cost'),
        description=data.get('description')
    )
    db.session.add(service)
    db.session.commit()
    return jsonify(service.to_dict()), 201

@services_bp.route('/services/<int:service_id>', methods=['GET'])
def get_service(service_id):
    service = Service.query.get_or_404(service_id)
    return jsonify(service.to_dict())

@services_bp.route('/services/<int:service_id>', methods=['PUT'])
def update_service(service_id):
    service = Service.query.get_or_404(service_id)
    data = request.json
    
    service.name = data.get('name', service.name)
    service.service_type = data.get('service_type', service.service_type)
    service.status = data.get('status', service.status)
    service.monthly_cost = data.get('monthly_cost', service.monthly_cost)
    service.description = data.get('description', service.description)
    
    db.session.commit()
    return jsonify(service.to_dict())

@services_bp.route('/services/<int:service_id>', methods=['DELETE'])
def delete_service(service_id):
    service = Service.query.get_or_404(service_id)
    db.session.delete(service)
    db.session.commit()
    return '', 204

