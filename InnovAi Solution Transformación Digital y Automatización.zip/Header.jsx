import { useState } from 'react'
import { Link, useLocation } from 'react-router-dom'
import { Button } from '@/components/ui/button'
import { Menu, X, User, LogOut } from 'lucide-react'
import { useAuth } from '../App'
import ThemeToggle from './ThemeToggle'

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const location = useLocation()
  const { isAuthenticated, user, logout } = useAuth()

  const navigation = [
    { name: 'Inicio', href: '/' },
    { name: 'Servicios', href: '/servicios' },
    { name: 'Nosotros', href: '/nosotros' },
    { name: 'Casos de Éxito', href: '/casos-exito' },
    { name: 'Contacto', href: '/contacto' },
  ]

  const isActive = (path) => location.pathname === path

  return (
    <header className="sticky top-0 z-50 w-full glass-card border-b border-white/10">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex h-16 items-center justify-between">
          {/* Logo */}
          <div className="flex items-center">
            <Link to="/" className="flex items-center space-x-2 interactive-hover">
              <div className="crystal-element p-2 rounded-xl">
                <img 
                  src="/src/assets/images/innovai_logo.jpeg" 
                  alt="InnovAi Solutions" 
                  className="h-8 w-auto"
                />
              </div>
              <span className="text-xl font-bold holographic">
                InnovAi Solutions
              </span>
            </Link>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-1">
            {navigation.map((item) => (
              <Link
                key={item.name}
                to={item.href}
                className={`px-4 py-2 rounded-lg text-sm font-medium transition-all duration-300 interactive-hover ${
                  isActive(item.href)
                    ? 'neomorphism-inset text-blue-600 glow-blue'
                    : 'neomorphism-flat hover:neomorphism text-gray-700 hover:text-blue-600'
                }`}
              >
                {item.name}
              </Link>
            ))}
          </nav>

          {/* Right side actions */}
          <div className="flex items-center space-x-3">
            <ThemeToggle />
            
            {isAuthenticated ? (
              <div className="flex items-center space-x-2">
                <Link to="/dashboard">
                  <Button 
                    variant="outline" 
                    size="sm" 
                    className="neomorphism-button flex items-center space-x-2 interactive-hover"
                  >
                    <User className="h-4 w-4" />
                    <span className="hidden sm:inline">Dashboard</span>
                  </Button>
                </Link>
                <Button 
                  onClick={logout} 
                  variant="outline" 
                  size="sm"
                  className="neomorphism-button flex items-center space-x-2 interactive-hover"
                >
                  <LogOut className="h-4 w-4" />
                  <span className="hidden sm:inline">Salir</span>
                </Button>
              </div>
            ) : (
              <div className="flex items-center space-x-2">
                <Link to="/login">
                  <Button 
                    variant="outline" 
                    size="sm"
                    className="neomorphism-button interactive-hover"
                  >
                    Iniciar Sesión
                  </Button>
                </Link>
                <Link to="/contacto">
                  <Button 
                    size="sm"
                    className="gradient-bg-primary text-white border-0 rounded-lg px-4 py-2 interactive-hover glow-blue"
                  >
                    Consulta Gratis
                  </Button>
                </Link>
              </div>
            )}

            {/* Mobile menu button */}
            <button
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="md:hidden neomorphism-button p-2 rounded-lg interactive-hover"
            >
              {isMenuOpen ? (
                <X className="h-5 w-5" />
              ) : (
                <Menu className="h-5 w-5" />
              )}
            </button>
          </div>
        </div>

        {/* Mobile Navigation */}
        {isMenuOpen && (
          <div className="md:hidden mt-4 pb-4">
            <div className="neomorphism p-4 rounded-2xl space-y-2">
              {navigation.map((item) => (
                <Link
                  key={item.name}
                  to={item.href}
                  onClick={() => setIsMenuOpen(false)}
                  className={`block px-4 py-3 rounded-lg text-sm font-medium transition-all duration-300 interactive-hover ${
                    isActive(item.href)
                      ? 'neomorphism-inset text-blue-600 glow-blue'
                      : 'neomorphism-flat hover:neomorphism text-gray-700 hover:text-blue-600'
                  }`}
                >
                  {item.name}
                </Link>
              ))}
              
              <div className="pt-4 border-t border-gray-200 space-y-2">
                {isAuthenticated ? (
                  <>
                    <Link to="/dashboard" onClick={() => setIsMenuOpen(false)}>
                      <Button 
                        variant="outline" 
                        className="w-full neomorphism-button interactive-hover"
                      >
                        <User className="h-4 w-4 mr-2" />
                        Dashboard
                      </Button>
                    </Link>
                    <Button 
                      onClick={() => {
                        logout()
                        setIsMenuOpen(false)
                      }} 
                      variant="outline" 
                      className="w-full neomorphism-button interactive-hover"
                    >
                      <LogOut className="h-4 w-4 mr-2" />
                      Salir
                    </Button>
                  </>
                ) : (
                  <>
                    <Link to="/login" onClick={() => setIsMenuOpen(false)}>
                      <Button 
                        variant="outline" 
                        className="w-full neomorphism-button interactive-hover"
                      >
                        Iniciar Sesión
                      </Button>
                    </Link>
                    <Link to="/contacto" onClick={() => setIsMenuOpen(false)}>
                      <Button 
                        className="w-full gradient-bg-primary text-white border-0 rounded-lg interactive-hover glow-blue"
                      >
                        Consulta Gratis
                      </Button>
                    </Link>
                  </>
                )}
              </div>
            </div>
          </div>
        )}
      </div>
    </header>
  )
}

export default Header

