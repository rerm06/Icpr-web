from flask import Blueprint, request, jsonify
from src.models.webhook import WebhookInstance, WebhookEvent, N8NWorkflow, WebhookLog, db
from src.models.user import User
import json
import requests
from datetime import datetime
import hashlib
import hmac

webhooks_bp = Blueprint('webhooks', __name__)

@webhooks_bp.route('/webhook-instances', methods=['GET'])
def get_webhook_instances():
    """Obtener todas las instancias de webhook del usuario"""
    user_id = request.args.get('user_id', 1)  # Por defecto usuario 1 para demo
    
    instances = WebhookInstance.query.filter_by(user_id=user_id).all()
    return jsonify([instance.to_dict() for instance in instances])

@webhooks_bp.route('/webhook-instances', methods=['POST'])
def create_webhook_instance():
    """Crear nueva instancia de webhook"""
    data = request.get_json()
    
    # Validar datos requeridos
    required_fields = ['user_id', 'instance_name', 'evolution_api_url', 'evolution_api_token']
    for field in required_fields:
        if field not in data:
            return jsonify({'error': f'Campo requerido: {field}'}), 400
    
    # Generar clave única para la instancia
    instance_key = hashlib.md5(f"{data['instance_name']}{datetime.utcnow()}".encode()).hexdigest()
    
    instance = WebhookInstance(
        user_id=data['user_id'],
        instance_name=data['instance_name'],
        instance_key=instance_key,
        evolution_api_url=data['evolution_api_url'],
        evolution_api_token=data['evolution_api_token'],
        n8n_webhook_url=data.get('n8n_webhook_url'),
        status='active'
    )
    
    db.session.add(instance)
    db.session.commit()
    
    return jsonify(instance.to_dict()), 201

@webhooks_bp.route('/webhook-instances/<int:instance_id>', methods=['PUT'])
def update_webhook_instance(instance_id):
    """Actualizar instancia de webhook"""
    instance = WebhookInstance.query.get_or_404(instance_id)
    data = request.get_json()
    
    # Actualizar campos permitidos
    allowed_fields = ['instance_name', 'evolution_api_url', 'evolution_api_token', 'n8n_webhook_url', 'status']
    for field in allowed_fields:
        if field in data:
            setattr(instance, field, data[field])
    
    instance.updated_at = datetime.utcnow()
    db.session.commit()
    
    return jsonify(instance.to_dict())

@webhooks_bp.route('/webhook-instances/<int:instance_id>', methods=['DELETE'])
def delete_webhook_instance(instance_id):
    """Eliminar instancia de webhook"""
    instance = WebhookInstance.query.get_or_404(instance_id)
    db.session.delete(instance)
    db.session.commit()
    
    return jsonify({'message': 'Instancia eliminada exitosamente'})

@webhooks_bp.route('/webhook/evolution/<instance_key>', methods=['POST'])
def receive_evolution_webhook(instance_key):
    """Recibir webhook de Evolution API"""
    instance = WebhookInstance.query.filter_by(instance_key=instance_key).first()
    if not instance:
        return jsonify({'error': 'Instancia no encontrada'}), 404
    
    # Obtener datos del webhook
    webhook_data = request.get_json()
    headers = dict(request.headers)
    
    # Registrar el evento
    log_webhook_request(instance.id, 'incoming', request.url, 'POST', headers, webhook_data)
    
    # Procesar el evento según el tipo
    event_type = webhook_data.get('event', 'unknown')
    
    # Crear evento en la base de datos
    event = WebhookEvent(
        instance_id=instance.id,
        event_type=event_type,
        event_data=json.dumps(webhook_data)
    )
    db.session.add(event)
    
    # Si hay un workflow de N8N configurado, enviarlo
    if instance.n8n_webhook_url:
        send_to_n8n(instance, webhook_data)
    
    # Procesar workflows específicos
    process_n8n_workflows(instance.id, event_type, webhook_data)
    
    db.session.commit()
    
    return jsonify({'status': 'received', 'event_id': event.id})

@webhooks_bp.route('/webhook/n8n/<instance_key>', methods=['POST'])
def receive_n8n_webhook(instance_key):
    """Recibir webhook de N8N"""
    instance = WebhookInstance.query.filter_by(instance_key=instance_key).first()
    if not instance:
        return jsonify({'error': 'Instancia no encontrada'}), 404
    
    webhook_data = request.get_json()
    headers = dict(request.headers)
    
    # Registrar el evento
    log_webhook_request(instance.id, 'incoming', request.url, 'POST', headers, webhook_data)
    
    # Procesar comando de N8N hacia Evolution API
    if 'action' in webhook_data:
        result = execute_evolution_action(instance, webhook_data)
        return jsonify(result)
    
    return jsonify({'status': 'received'})

@webhooks_bp.route('/n8n-workflows', methods=['GET'])
def get_n8n_workflows():
    """Obtener workflows de N8N del usuario"""
    user_id = request.args.get('user_id', 1)
    instance_id = request.args.get('instance_id')
    
    query = N8NWorkflow.query.filter_by(user_id=user_id)
    if instance_id:
        query = query.filter_by(instance_id=instance_id)
    
    workflows = query.all()
    return jsonify([workflow.to_dict() for workflow in workflows])

@webhooks_bp.route('/n8n-workflows', methods=['POST'])
def create_n8n_workflow():
    """Crear nuevo workflow de N8N"""
    data = request.get_json()
    
    required_fields = ['user_id', 'instance_id', 'workflow_name', 'workflow_id', 'webhook_url', 'trigger_events']
    for field in required_fields:
        if field not in data:
            return jsonify({'error': f'Campo requerido: {field}'}), 400
    
    workflow = N8NWorkflow(
        user_id=data['user_id'],
        instance_id=data['instance_id'],
        workflow_name=data['workflow_name'],
        workflow_id=data['workflow_id'],
        webhook_url=data['webhook_url'],
        trigger_events=json.dumps(data['trigger_events']),
        active=data.get('active', True)
    )
    
    db.session.add(workflow)
    db.session.commit()
    
    return jsonify(workflow.to_dict()), 201

@webhooks_bp.route('/webhook-events', methods=['GET'])
def get_webhook_events():
    """Obtener eventos de webhook"""
    instance_id = request.args.get('instance_id')
    limit = int(request.args.get('limit', 50))
    
    query = WebhookEvent.query
    if instance_id:
        query = query.filter_by(instance_id=instance_id)
    
    events = query.order_by(WebhookEvent.created_at.desc()).limit(limit).all()
    return jsonify([event.to_dict() for event in events])

@webhooks_bp.route('/webhook-logs', methods=['GET'])
def get_webhook_logs():
    """Obtener logs de webhook"""
    instance_id = request.args.get('instance_id')
    limit = int(request.args.get('limit', 100))
    
    query = WebhookLog.query
    if instance_id:
        query = query.filter_by(instance_id=instance_id)
    
    logs = query.order_by(WebhookLog.created_at.desc()).limit(limit).all()
    return jsonify([log.to_dict() for log in logs])

def send_to_n8n(instance, data):
    """Enviar datos a N8N"""
    try:
        response = requests.post(
            instance.n8n_webhook_url,
            json=data,
            headers={'Content-Type': 'application/json'},
            timeout=30
        )
        
        # Registrar la respuesta
        log_webhook_response(instance.id, 'outgoing', instance.n8n_webhook_url, 'POST', 
                           {'Content-Type': 'application/json'}, data, 
                           response.status_code, response.text)
        
        return response.status_code == 200
    except Exception as e:
        print(f"Error enviando a N8N: {e}")
        return False

def process_n8n_workflows(instance_id, event_type, data):
    """Procesar workflows de N8N específicos"""
    workflows = N8NWorkflow.query.filter_by(instance_id=instance_id, active=True).all()
    
    for workflow in workflows:
        trigger_events = json.loads(workflow.trigger_events)
        if event_type in trigger_events:
            try:
                response = requests.post(
                    workflow.webhook_url,
                    json={
                        'event_type': event_type,
                        'data': data,
                        'workflow_id': workflow.workflow_id
                    },
                    headers={'Content-Type': 'application/json'},
                    timeout=30
                )
                
                log_webhook_response(instance_id, 'outgoing', workflow.webhook_url, 'POST',
                                   {'Content-Type': 'application/json'}, data,
                                   response.status_code, response.text)
            except Exception as e:
                print(f"Error procesando workflow {workflow.workflow_id}: {e}")

def execute_evolution_action(instance, data):
    """Ejecutar acción en Evolution API"""
    action = data.get('action')
    params = data.get('params', {})
    
    try:
        if action == 'send_message':
            return send_evolution_message(instance, params)
        elif action == 'get_instance_status':
            return get_evolution_instance_status(instance)
        elif action == 'create_instance':
            return create_evolution_instance(instance, params)
        else:
            return {'error': f'Acción no soportada: {action}'}
    except Exception as e:
        return {'error': f'Error ejecutando acción: {str(e)}'}

def send_evolution_message(instance, params):
    """Enviar mensaje a través de Evolution API"""
    url = f"{instance.evolution_api_url}/message/sendText/{instance.instance_key}"
    headers = {
        'Content-Type': 'application/json',
        'apikey': instance.evolution_api_token
    }
    
    response = requests.post(url, json=params, headers=headers, timeout=30)
    
    log_webhook_response(instance.id, 'outgoing', url, 'POST', headers, params,
                        response.status_code, response.text)
    
    return {
        'status': 'sent' if response.status_code == 200 else 'error',
        'response': response.json() if response.status_code == 200 else response.text
    }

def get_evolution_instance_status(instance):
    """Obtener estado de la instancia de Evolution API"""
    url = f"{instance.evolution_api_url}/instance/connectionState/{instance.instance_key}"
    headers = {'apikey': instance.evolution_api_token}
    
    response = requests.get(url, headers=headers, timeout=30)
    
    return {
        'status': 'success' if response.status_code == 200 else 'error',
        'data': response.json() if response.status_code == 200 else response.text
    }

def create_evolution_instance(instance, params):
    """Crear nueva instancia en Evolution API"""
    url = f"{instance.evolution_api_url}/instance/create"
    headers = {
        'Content-Type': 'application/json',
        'apikey': instance.evolution_api_token
    }
    
    response = requests.post(url, json=params, headers=headers, timeout=30)
    
    return {
        'status': 'created' if response.status_code == 201 else 'error',
        'data': response.json() if response.status_code in [200, 201] else response.text
    }

def log_webhook_request(instance_id, direction, endpoint, method, headers, payload):
    """Registrar solicitud de webhook"""
    log = WebhookLog(
        instance_id=instance_id,
        direction=direction,
        endpoint=endpoint,
        method=method,
        headers=json.dumps(headers),
        payload=json.dumps(payload) if payload else None
    )
    db.session.add(log)

def log_webhook_response(instance_id, direction, endpoint, method, headers, payload, status, response):
    """Registrar respuesta de webhook"""
    log = WebhookLog(
        instance_id=instance_id,
        direction=direction,
        endpoint=endpoint,
        method=method,
        headers=json.dumps(headers),
        payload=json.dumps(payload) if payload else None,
        response_status=status,
        response_data=response
    )
    db.session.add(log)

