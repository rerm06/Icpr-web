import { useEffect, useState } from 'react';

const FloatingElements = () => {
  const [elements, setElements] = useState([]);

  useEffect(() => {
    // Generar elementos flotantes aleatorios
    const generateElements = () => {
      const newElements = [];
      for (let i = 0; i < 8; i++) {
        newElements.push({
          id: i,
          x: Math.random() * 100,
          y: Math.random() * 100,
          size: Math.random() * 60 + 20,
          delay: Math.random() * 5,
          duration: Math.random() * 10 + 10,
          shape: ['circle', 'square', 'triangle', 'hexagon'][Math.floor(Math.random() * 4)],
          opacity: Math.random() * 0.3 + 0.1
        });
      }
      setElements(newElements);
    };

    generateElements();
  }, []);

  const getShapeClass = (shape) => {
    switch (shape) {
      case 'circle':
        return 'rounded-full';
      case 'square':
        return 'rounded-lg';
      case 'triangle':
        return 'rounded-lg transform rotate-45';
      case 'hexagon':
        return 'rounded-xl transform rotate-12';
      default:
        return 'rounded-full';
    }
  };

  return (
    <div className="fixed inset-0 pointer-events-none overflow-hidden z-0">
      {elements.map((element) => (
        <div
          key={element.id}
          className={`absolute crystal-element ${getShapeClass(element.shape)} floating-element`}
          style={{
            left: `${element.x}%`,
            top: `${element.y}%`,
            width: `${element.size}px`,
            height: `${element.size}px`,
            opacity: element.opacity,
            animationDelay: `${element.delay}s`,
            animationDuration: `${element.duration}s`,
            background: `linear-gradient(135deg, 
              rgba(59, 130, 246, ${element.opacity}) 0%, 
              rgba(139, 92, 246, ${element.opacity * 0.8}) 50%,
              rgba(236, 72, 153, ${element.opacity * 0.6}) 100%)`,
            backdropFilter: 'blur(10px)',
            border: '1px solid rgba(255, 255, 255, 0.1)',
            boxShadow: `0 8px 32px rgba(59, 130, 246, ${element.opacity * 0.3})`
          }}
        >
          <div 
            className="absolute inset-0 rounded-inherit"
            style={{
              background: `linear-gradient(45deg, 
                transparent 30%, 
                rgba(255, 255, 255, 0.1) 50%, 
                transparent 70%)`,
              animation: `shimmer ${element.duration * 0.5}s ease-in-out infinite alternate`
            }}
          />
        </div>
      ))}
      
      {/* Elementos específicos con imágenes */}
      <div 
        className="absolute floating-element-reverse"
        style={{
          top: '10%',
          right: '10%',
          width: '80px',
          height: '80px',
          animationDelay: '2s'
        }}
      >
        <div className="crystal-element w-full h-full rounded-2xl p-4 flex items-center justify-center">
          <div className="w-8 h-8 bg-gradient-to-br from-blue-400 to-purple-500 rounded-lg opacity-80" />
        </div>
      </div>

      <div 
        className="absolute floating-element"
        style={{
          bottom: '20%',
          left: '5%',
          width: '60px',
          height: '60px',
          animationDelay: '4s'
        }}
      >
        <div className="crystal-element w-full h-full rounded-full p-3 flex items-center justify-center">
          <div className="w-6 h-6 bg-gradient-to-br from-cyan-400 to-blue-500 rounded-full opacity-70" />
        </div>
      </div>

      <div 
        className="absolute floating-element-reverse"
        style={{
          top: '60%',
          right: '20%',
          width: '100px',
          height: '40px',
          animationDelay: '1s'
        }}
      >
        <div className="crystal-element w-full h-full rounded-xl p-2 flex items-center justify-center">
          <div className="w-full h-2 bg-gradient-to-r from-purple-400 to-pink-500 rounded-full opacity-60" />
        </div>
      </div>

      <style jsx>{`
        @keyframes shimmer {
          0% { transform: translateX(-100%); }
          100% { transform: translateX(100%); }
        }
      `}</style>
    </div>
  );
};

export default FloatingElements;

