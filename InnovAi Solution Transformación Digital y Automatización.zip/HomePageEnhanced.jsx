import { useState } from 'react'
import { Link } from 'react-router-dom'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { 
  ArrowRight, 
  Bot, 
  Zap, 
  Users, 
  TrendingUp, 
  CheckCircle, 
  Star,
  Play,
  ChevronRight,
  Sparkles,
  Brain,
  Cpu,
  Network
} from 'lucide-react'

const HomePage = () => {
  const [email, setEmail] = useState('')
  const [message, setMessage] = useState('')

  const services = [
    {
      icon: <Zap className="h-8 w-8 text-blue-600" />,
      title: "Automatización Inteligente",
      description: "Optimizamos procesos empresariales con RPA y flujos de trabajo automatizados que aumentan la eficiencia hasta un 47%.",
      features: ["RPA Avanzado", "Flujos de Trabajo", "Integración de Sistemas"],
      image: "/src/assets/images/innovai_automation_3d.png"
    },
    {
      icon: <Bot className="h-8 w-8 text-purple-600" />,
      title: "Chatbots Personalizados",
      description: "Asistentes virtuales 24/7 que mejoran la atención al cliente y generan leads de manera automatizada.",
      features: ["Servicio 24/7", "Generación de Leads", "Marketing Automatizado"],
      image: "/src/assets/images/innovai_chatbot_crystal.png"
    },
    {
      icon: <Users className="h-8 w-8 text-orange-600" />,
      title: "Consultoría Digital",
      description: "Transformación digital completa con análisis detallado y soluciones personalizadas para su negocio.",
      features: ["Análisis de Procesos", "Estrategia Digital", "Implementación"],
      image: "/src/assets/images/innovai_data_visualization.png"
    },
    {
      icon: <Brain className="h-8 w-8 text-green-600" />,
      title: "Diseño Instruccional",
      description: "Programas educativos empresariales que integran IA para maximizar el aprendizaje y desarrollo.",
      features: ["Programas Personalizados", "Integración IA", "Desarrollo Profesional"],
      image: "/src/assets/images/innovai_ai_brain.png"
    }
  ]

  const stats = [
    { number: "500+", label: "Proyectos Completados", icon: <CheckCircle className="h-6 w-6" /> },
    { number: "98%", label: "Satisfacción del Cliente", icon: <Star className="h-6 w-6" /> },
    { number: "47%", label: "Aumento de Eficiencia", icon: <TrendingUp className="h-6 w-6" /> },
    { number: "24/7", label: "Soporte Disponible", icon: <Bot className="h-6 w-6" /> }
  ]

  const testimonials = [
    {
      name: "María González",
      company: "TechCorp Solutions",
      text: "InnovAi Solutions transformó completamente nuestros procesos. La automatización implementada nos ahorró 40 horas semanales.",
      rating: 5
    },
    {
      name: "Carlos Rodríguez",
      company: "Retail Plus",
      text: "El chatbot personalizado aumentó nuestras ventas en un 35%. Excelente trabajo del equipo de InnovAi.",
      rating: 5
    },
    {
      name: "Ana Martínez",
      company: "EduTech Institute",
      text: "Los programas de capacitación con IA han revolucionado nuestro enfoque educativo. Resultados excepcionales.",
      rating: 5
    }
  ]

  const handleSubmit = (e) => {
    e.preventDefault()
    console.log('Form submitted:', { email, message })
    setEmail('')
    setMessage('')
  }

  return (
    <div className="relative">
      {/* Hero Section */}
      <section className="relative py-20 lg:py-32 overflow-hidden">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="space-y-8">
              <div className="space-y-4">
                <div className="neomorphism-flat inline-block px-4 py-2 rounded-full">
                  <span className="text-sm font-medium text-blue-600 flex items-center">
                    <Sparkles className="h-4 w-4 mr-2" />
                    Transformación Digital Avanzada
                  </span>
                </div>
                <h1 className="text-4xl lg:text-6xl font-bold leading-tight">
                  <span className="holographic">Automatiza</span> tu negocio con{' '}
                  <span className="holographic">Inteligencia Artificial</span>
                </h1>
                <p className="text-xl text-gray-600 leading-relaxed">
                  Revoluciona tus procesos empresariales con soluciones de IA personalizadas, 
                  automatización inteligente y consultoría especializada que impulsan el crecimiento.
                </p>
              </div>
              
              <div className="flex flex-col sm:flex-row gap-4">
                <Link to="/contacto">
                  <Button 
                    size="lg" 
                    className="gradient-bg-primary text-white border-0 rounded-xl px-8 py-4 text-lg interactive-hover glow-blue"
                  >
                    Consulta Gratuita
                    <ArrowRight className="ml-2 h-5 w-5" />
                  </Button>
                </Link>
                <Button 
                  variant="outline" 
                  size="lg"
                  className="neomorphism-button rounded-xl px-8 py-4 text-lg interactive-hover"
                >
                  <Play className="mr-2 h-5 w-5" />
                  Ver Demo
                </Button>
              </div>

              <div className="flex items-center space-x-8 pt-4">
                {stats.slice(0, 2).map((stat, index) => (
                  <div key={index} className="text-center">
                    <div className="text-2xl font-bold text-blue-600">{stat.number}</div>
                    <div className="text-sm text-gray-600">{stat.label}</div>
                  </div>
                ))}
              </div>
            </div>

            <div className="relative">
              <div className="card-3d">
                <div className="card-3d-inner neomorphism p-8 rounded-3xl">
                  <img 
                    src="/src/assets/images/innovai_hero_3d.png" 
                    alt="AI Automation" 
                    className="w-full h-auto rounded-2xl"
                  />
                  <div className="absolute inset-0 crystal-element rounded-3xl opacity-20"></div>
                </div>
              </div>
              
              {/* Floating elements */}
              <div className="absolute -top-4 -right-4 floating-element">
                <div className="crystal-element p-4 rounded-2xl glow-blue">
                  <Cpu className="h-8 w-8 text-blue-500" />
                </div>
              </div>
              <div className="absolute -bottom-4 -left-4 floating-element-reverse">
                <div className="crystal-element p-4 rounded-2xl glow-purple">
                  <Network className="h-8 w-8 text-purple-500" />
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-16 bg-gradient-to-r from-blue-50 to-purple-50">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-8">
            {stats.map((stat, index) => (
              <div key={index} className="text-center">
                <div className="neomorphism p-6 rounded-2xl interactive-hover">
                  <div className="flex justify-center mb-4 text-blue-600">
                    {stat.icon}
                  </div>
                  <div className="text-3xl font-bold text-gray-900 mb-2">{stat.number}</div>
                  <div className="text-sm text-gray-600">{stat.label}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section className="py-20">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-5xl font-bold mb-6">
              Nuestros <span className="holographic">Servicios</span>
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Soluciones integrales de automatización e inteligencia artificial 
              diseñadas para transformar tu negocio
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-2 gap-8">
            {services.map((service, index) => (
              <div key={index} className="group">
                <div className="neomorphism p-8 rounded-3xl h-full interactive-hover">
                  <div className="flex items-start space-x-4 mb-6">
                    <div className="crystal-element p-3 rounded-xl">
                      {service.icon}
                    </div>
                    <div className="flex-1">
                      <h3 className="text-xl font-bold mb-2">{service.title}</h3>
                      <p className="text-gray-600">{service.description}</p>
                    </div>
                  </div>
                  
                  <div className="mb-6">
                    <img 
                      src={service.image} 
                      alt={service.title}
                      className="w-full h-48 object-cover rounded-2xl"
                    />
                  </div>

                  <div className="space-y-2 mb-6">
                    {service.features.map((feature, idx) => (
                      <div key={idx} className="flex items-center">
                        <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                        <span className="text-sm text-gray-600">{feature}</span>
                      </div>
                    ))}
                  </div>

                  <Button 
                    variant="outline" 
                    className="w-full neomorphism-button interactive-hover group-hover:gradient-bg-primary group-hover:text-white"
                  >
                    Más Información
                    <ChevronRight className="ml-2 h-4 w-4" />
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="py-20 gradient-bg-glass">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-5xl font-bold mb-6">
              Lo que dicen nuestros <span className="holographic">clientes</span>
            </h2>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {testimonials.map((testimonial, index) => (
              <div key={index} className="glass-card p-8 rounded-3xl interactive-hover">
                <div className="flex mb-4">
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <Star key={i} className="h-5 w-5 text-yellow-400 fill-current" />
                  ))}
                </div>
                <p className="text-gray-700 mb-6 italic">"{testimonial.text}"</p>
                <div>
                  <div className="font-semibold">{testimonial.name}</div>
                  <div className="text-sm text-gray-600">{testimonial.company}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="neomorphism p-12 rounded-3xl text-center">
            <h2 className="text-3xl lg:text-4xl font-bold mb-6">
              ¿Listo para <span className="holographic">transformar</span> tu negocio?
            </h2>
            <p className="text-xl text-gray-600 mb-8 max-w-2xl mx-auto">
              Agenda una consulta gratuita y descubre cómo la inteligencia artificial 
              puede revolucionar tus procesos empresariales
            </p>
            
            <form onSubmit={handleSubmit} className="max-w-md mx-auto space-y-4">
              <Input
                type="email"
                placeholder="Tu email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="neomorphism-inset"
                required
              />
              <Textarea
                placeholder="Cuéntanos sobre tu proyecto"
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                className="neomorphism-inset"
                rows={3}
              />
              <Button 
                type="submit" 
                size="lg" 
                className="w-full gradient-bg-primary text-white border-0 rounded-xl interactive-hover glow-blue"
              >
                Solicitar Consulta Gratuita
                <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
            </form>
          </div>
        </div>
      </section>
    </div>
  )
}

export default HomePage

