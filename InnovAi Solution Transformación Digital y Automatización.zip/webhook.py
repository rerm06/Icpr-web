from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
import json

db = SQLAlchemy()

class WebhookInstance(db.Model):
    __tablename__ = 'webhook_instances'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    instance_name = db.Column(db.String(100), nullable=False)
    instance_key = db.Column(db.String(255), nullable=False, unique=True)
    evolution_api_url = db.Column(db.String(500), nullable=False)
    evolution_api_token = db.Column(db.String(255), nullable=False)
    n8n_webhook_url = db.Column(db.String(500), nullable=True)
    status = db.Column(db.String(20), default='active')  # active, inactive, error
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relación con eventos de webhook
    webhook_events = db.relationship('WebhookEvent', backref='instance', lazy=True, cascade='all, delete-orphan')
    
    def to_dict(self):
        return {
            'id': self.id,
            'user_id': self.user_id,
            'instance_name': self.instance_name,
            'instance_key': self.instance_key,
            'evolution_api_url': self.evolution_api_url,
            'n8n_webhook_url': self.n8n_webhook_url,
            'status': self.status,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }

class WebhookEvent(db.Model):
    __tablename__ = 'webhook_events'
    
    id = db.Column(db.Integer, primary_key=True)
    instance_id = db.Column(db.Integer, db.ForeignKey('webhook_instances.id'), nullable=False)
    event_type = db.Column(db.String(50), nullable=False)  # message_received, message_sent, connection_update, etc.
    event_data = db.Column(db.Text, nullable=False)  # JSON data del evento
    processed = db.Column(db.Boolean, default=False)
    processed_at = db.Column(db.DateTime, nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def to_dict(self):
        return {
            'id': self.id,
            'instance_id': self.instance_id,
            'event_type': self.event_type,
            'event_data': json.loads(self.event_data) if self.event_data else {},
            'processed': self.processed,
            'processed_at': self.processed_at.isoformat() if self.processed_at else None,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }

class N8NWorkflow(db.Model):
    __tablename__ = 'n8n_workflows'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    instance_id = db.Column(db.Integer, db.ForeignKey('webhook_instances.id'), nullable=False)
    workflow_name = db.Column(db.String(100), nullable=False)
    workflow_id = db.Column(db.String(100), nullable=False)
    webhook_url = db.Column(db.String(500), nullable=False)
    trigger_events = db.Column(db.Text, nullable=False)  # JSON array de eventos que disparan el workflow
    active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def to_dict(self):
        return {
            'id': self.id,
            'user_id': self.user_id,
            'instance_id': self.instance_id,
            'workflow_name': self.workflow_name,
            'workflow_id': self.workflow_id,
            'webhook_url': self.webhook_url,
            'trigger_events': json.loads(self.trigger_events) if self.trigger_events else [],
            'active': self.active,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }

class WebhookLog(db.Model):
    __tablename__ = 'webhook_logs'
    
    id = db.Column(db.Integer, primary_key=True)
    instance_id = db.Column(db.Integer, db.ForeignKey('webhook_instances.id'), nullable=False)
    direction = db.Column(db.String(10), nullable=False)  # incoming, outgoing
    endpoint = db.Column(db.String(200), nullable=False)
    method = db.Column(db.String(10), nullable=False)
    headers = db.Column(db.Text, nullable=True)
    payload = db.Column(db.Text, nullable=True)
    response_status = db.Column(db.Integer, nullable=True)
    response_data = db.Column(db.Text, nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def to_dict(self):
        return {
            'id': self.id,
            'instance_id': self.instance_id,
            'direction': self.direction,
            'endpoint': self.endpoint,
            'method': self.method,
            'headers': json.loads(self.headers) if self.headers else {},
            'payload': json.loads(self.payload) if self.payload else {},
            'response_status': self.response_status,
            'response_data': json.loads(self.response_data) if self.response_data else {},
            'created_at': self.created_at.isoformat() if self.created_at else None
        }

