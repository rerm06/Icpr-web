import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Badge } from '@/components/ui/badge'
import { 
  Plus, 
  Settings, 
  Trash2, 
  Activity, 
  Webhook, 
  ExternalLink,
  Copy,
  CheckCircle,
  AlertCircle,
  Zap,
  Bot
} from 'lucide-react'

const WebhookManager = () => {
  const [instances, setInstances] = useState([])
  const [workflows, setWorkflows] = useState([])
  const [events, setEvents] = useState([])
  const [showCreateForm, setShowCreateForm] = useState(false)
  const [newInstance, setNewInstance] = useState({
    instance_name: '',
    evolution_api_url: '',
    evolution_api_token: '',
    n8n_webhook_url: ''
  })

  useEffect(() => {
    fetchInstances()
    fetchWorkflows()
    fetchEvents()
  }, [])

  const fetchInstances = async () => {
    try {
      const response = await fetch('http://localhost:5001/api/webhook-instances?user_id=1')
      const data = await response.json()
      setInstances(data)
    } catch (error) {
      console.error('Error fetching instances:', error)
    }
  }

  const fetchWorkflows = async () => {
    try {
      const response = await fetch('http://localhost:5001/api/n8n-workflows?user_id=1')
      const data = await response.json()
      setWorkflows(data)
    } catch (error) {
      console.error('Error fetching workflows:', error)
    }
  }

  const fetchEvents = async () => {
    try {
      const response = await fetch('http://localhost:5001/api/webhook-events?limit=10')
      const data = await response.json()
      setEvents(data)
    } catch (error) {
      console.error('Error fetching events:', error)
    }
  }

  const createInstance = async (e) => {
    e.preventDefault()
    try {
      const response = await fetch('http://localhost:5001/api/webhook-instances', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          ...newInstance,
          user_id: 1
        })
      })
      
      if (response.ok) {
        setShowCreateForm(false)
        setNewInstance({
          instance_name: '',
          evolution_api_url: '',
          evolution_api_token: '',
          n8n_webhook_url: ''
        })
        fetchInstances()
      }
    } catch (error) {
      console.error('Error creating instance:', error)
    }
  }

  const deleteInstance = async (instanceId) => {
    try {
      const response = await fetch(`http://localhost:5001/api/webhook-instances/${instanceId}`, {
        method: 'DELETE'
      })
      
      if (response.ok) {
        fetchInstances()
      }
    } catch (error) {
      console.error('Error deleting instance:', error)
    }
  }

  const copyWebhookUrl = (instanceKey) => {
    const webhookUrl = `${window.location.origin}/api/webhook/evolution/${instanceKey}`
    navigator.clipboard.writeText(webhookUrl)
    // Aquí podrías mostrar una notificación de éxito
  }

  const getStatusColor = (status) => {
    switch (status) {
      case 'active': return 'bg-green-100 text-green-800'
      case 'inactive': return 'bg-gray-100 text-gray-800'
      case 'error': return 'bg-red-100 text-red-800'
      default: return 'bg-gray-100 text-gray-800'
    }
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold">Gestión de Webhooks</h2>
          <p className="text-gray-600">Administra tus integraciones con Evolution API y N8N</p>
        </div>
        <Button 
          onClick={() => setShowCreateForm(true)}
          className="gradient-bg-primary text-white border-0 rounded-xl interactive-hover glow-blue"
        >
          <Plus className="h-4 w-4 mr-2" />
          Nueva Instancia
        </Button>
      </div>

      {/* Create Form */}
      {showCreateForm && (
        <Card className="neomorphism">
          <CardHeader>
            <CardTitle className="flex items-center">
              <Webhook className="h-5 w-5 mr-2" />
              Crear Nueva Instancia
            </CardTitle>
            <CardDescription>
              Configura una nueva instancia de webhook para Evolution API
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={createInstance} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="instance_name">Nombre de la Instancia</Label>
                  <Input
                    id="instance_name"
                    value={newInstance.instance_name}
                    onChange={(e) => setNewInstance({...newInstance, instance_name: e.target.value})}
                    className="neomorphism-inset"
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="evolution_api_url">URL de Evolution API</Label>
                  <Input
                    id="evolution_api_url"
                    value={newInstance.evolution_api_url}
                    onChange={(e) => setNewInstance({...newInstance, evolution_api_url: e.target.value})}
                    className="neomorphism-inset"
                    placeholder="https://api.evolution.com"
                    required
                  />
                </div>
              </div>
              
              <div>
                <Label htmlFor="evolution_api_token">Token de Evolution API</Label>
                <Input
                  id="evolution_api_token"
                  type="password"
                  value={newInstance.evolution_api_token}
                  onChange={(e) => setNewInstance({...newInstance, evolution_api_token: e.target.value})}
                  className="neomorphism-inset"
                  required
                />
              </div>
              
              <div>
                <Label htmlFor="n8n_webhook_url">URL de Webhook N8N (Opcional)</Label>
                <Input
                  id="n8n_webhook_url"
                  value={newInstance.n8n_webhook_url}
                  onChange={(e) => setNewInstance({...newInstance, n8n_webhook_url: e.target.value})}
                  className="neomorphism-inset"
                  placeholder="https://n8n.example.com/webhook/..."
                />
              </div>
              
              <div className="flex space-x-2">
                <Button 
                  type="submit"
                  className="gradient-bg-primary text-white border-0 rounded-lg interactive-hover"
                >
                  Crear Instancia
                </Button>
                <Button 
                  type="button" 
                  variant="outline"
                  onClick={() => setShowCreateForm(false)}
                  className="neomorphism-button interactive-hover"
                >
                  Cancelar
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      )}

      {/* Instances List */}
      <div className="grid gap-6">
        <Card className="neomorphism">
          <CardHeader>
            <CardTitle className="flex items-center">
              <Bot className="h-5 w-5 mr-2" />
              Instancias de Evolution API
            </CardTitle>
          </CardHeader>
          <CardContent>
            {instances.length === 0 ? (
              <div className="text-center py-8 text-gray-500">
                No hay instancias configuradas
              </div>
            ) : (
              <div className="space-y-4">
                {instances.map((instance) => (
                  <div key={instance.id} className="glass-card p-4 rounded-xl interactive-hover">
                    <div className="flex justify-between items-start">
                      <div className="flex-1">
                        <div className="flex items-center space-x-2 mb-2">
                          <h3 className="font-semibold">{instance.instance_name}</h3>
                          <Badge className={getStatusColor(instance.status)}>
                            {instance.status}
                          </Badge>
                        </div>
                        <p className="text-sm text-gray-600 mb-2">
                          Clave: <code className="bg-gray-100 px-2 py-1 rounded">{instance.instance_key}</code>
                        </p>
                        <p className="text-sm text-gray-600">
                          API URL: {instance.evolution_api_url}
                        </p>
                      </div>
                      
                      <div className="flex space-x-2">
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => copyWebhookUrl(instance.instance_key)}
                          className="neomorphism-button interactive-hover"
                        >
                          <Copy className="h-4 w-4" />
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          className="neomorphism-button interactive-hover"
                        >
                          <Settings className="h-4 w-4" />
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => deleteInstance(instance.id)}
                          className="neomorphism-button interactive-hover text-red-600"
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        {/* N8N Workflows */}
        <Card className="neomorphism">
          <CardHeader>
            <CardTitle className="flex items-center">
              <Zap className="h-5 w-5 mr-2" />
              Workflows de N8N
            </CardTitle>
          </CardHeader>
          <CardContent>
            {workflows.length === 0 ? (
              <div className="text-center py-8 text-gray-500">
                No hay workflows configurados
              </div>
            ) : (
              <div className="space-y-4">
                {workflows.map((workflow) => (
                  <div key={workflow.id} className="glass-card p-4 rounded-xl interactive-hover">
                    <div className="flex justify-between items-start">
                      <div>
                        <h3 className="font-semibold">{workflow.workflow_name}</h3>
                        <p className="text-sm text-gray-600">ID: {workflow.workflow_id}</p>
                        <div className="flex items-center mt-2">
                          <Badge className={workflow.active ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'}>
                            {workflow.active ? 'Activo' : 'Inactivo'}
                          </Badge>
                        </div>
                      </div>
                      <Button
                        size="sm"
                        variant="outline"
                        className="neomorphism-button interactive-hover"
                      >
                        <ExternalLink className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Recent Events */}
        <Card className="neomorphism">
          <CardHeader>
            <CardTitle className="flex items-center">
              <Activity className="h-5 w-5 mr-2" />
              Eventos Recientes
            </CardTitle>
          </CardHeader>
          <CardContent>
            {events.length === 0 ? (
              <div className="text-center py-8 text-gray-500">
                No hay eventos recientes
              </div>
            ) : (
              <div className="space-y-3">
                {events.map((event) => (
                  <div key={event.id} className="glass-card p-3 rounded-lg interactive-hover">
                    <div className="flex justify-between items-center">
                      <div className="flex items-center space-x-3">
                        <div className={`w-2 h-2 rounded-full ${event.processed ? 'bg-green-500' : 'bg-yellow-500'}`} />
                        <div>
                          <span className="font-medium">{event.event_type}</span>
                          <p className="text-sm text-gray-600">
                            {new Date(event.created_at).toLocaleString()}
                          </p>
                        </div>
                      </div>
                      <Badge className={event.processed ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'}>
                        {event.processed ? 'Procesado' : 'Pendiente'}
                      </Badge>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

export default WebhookManager

