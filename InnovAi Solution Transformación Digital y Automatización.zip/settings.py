from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
import json

db = SQLAlchemy()

class UserProfile(db.Model):
    """Modelo para el perfil completo del usuario"""
    __tablename__ = 'user_profiles'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    
    # Información Personal
    first_name = db.Column(db.String(100))
    last_name = db.Column(db.String(100))
    phone = db.Column(db.String(20))
    secondary_email = db.Column(db.String(120))
    timezone = db.Column(db.String(50), default='America/New_York')
    language = db.Column(db.String(10), default='es')
    profile_picture = db.Column(db.String(255))
    
    # Información Empresarial
    company_name = db.Column(db.String(200))
    job_title = db.Column(db.String(100))
    industry = db.Column(db.String(100))
    company_size = db.Column(db.String(50))
    website = db.Column(db.String(255))
    
    # Dirección de Facturación
    billing_address = db.Column(db.Text)
    billing_city = db.Column(db.String(100))
    billing_state = db.Column(db.String(100))
    billing_zip = db.Column(db.String(20))
    billing_country = db.Column(db.String(100))
    tax_id = db.Column(db.String(50))
    
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relación con User
    user = db.relationship('User', backref='profile')

class NotificationSettings(db.Model):
    """Configuraciones de notificaciones del usuario"""
    __tablename__ = 'notification_settings'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    
    # Notificaciones de Email
    email_appointments = db.Column(db.Boolean, default=True)
    email_reminders = db.Column(db.Boolean, default=True)
    email_billing = db.Column(db.Boolean, default=True)
    email_updates = db.Column(db.Boolean, default=True)
    email_marketing = db.Column(db.Boolean, default=False)
    
    # Otros Canales
    sms_enabled = db.Column(db.Boolean, default=False)
    whatsapp_enabled = db.Column(db.Boolean, default=False)
    push_enabled = db.Column(db.Boolean, default=True)
    
    # Configuraciones de Timing
    reminder_24h = db.Column(db.Boolean, default=True)
    reminder_1h = db.Column(db.Boolean, default=True)
    reminder_15m = db.Column(db.Boolean, default=False)
    
    # Frecuencia de Comunicación
    communication_frequency = db.Column(db.String(20), default='normal')  # low, normal, high
    
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relación con User
    user = db.relationship('User', backref='notification_settings')

class CalendarSettings(db.Model):
    """Configuraciones de calendario y citas"""
    __tablename__ = 'calendar_settings'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    
    # Configuraciones de Disponibilidad
    work_days = db.Column(db.String(20), default='1,2,3,4,5')  # Lunes a Viernes
    work_start_time = db.Column(db.String(10), default='09:00')
    work_end_time = db.Column(db.String(10), default='17:00')
    timezone = db.Column(db.String(50), default='America/New_York')
    
    # Configuraciones de Citas
    default_duration = db.Column(db.Integer, default=60)  # minutos
    buffer_time = db.Column(db.Integer, default=15)  # minutos entre citas
    max_advance_booking = db.Column(db.Integer, default=30)  # días
    min_advance_booking = db.Column(db.Integer, default=1)  # horas
    
    # Preferencias
    preferred_consultant_id = db.Column(db.Integer)
    default_meeting_type = db.Column(db.String(20), default='virtual')  # virtual, presencial
    auto_confirm = db.Column(db.Boolean, default=False)
    
    # Tipos de Cita Permitidos (JSON)
    allowed_appointment_types = db.Column(db.Text, default='["consultoria", "revision", "soporte", "capacitacion"]')
    
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relación con User
    user = db.relationship('User', backref='calendar_settings')

class BillingSettings(db.Model):
    """Configuraciones de facturación y pagos"""
    __tablename__ = 'billing_settings'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    
    # Configuraciones de Facturación
    billing_frequency = db.Column(db.String(20), default='monthly')  # monthly, quarterly, yearly
    invoice_format = db.Column(db.String(20), default='pdf')  # pdf, email
    currency = db.Column(db.String(10), default='USD')
    
    # Configuraciones de Pago
    auto_pay_enabled = db.Column(db.Boolean, default=False)
    default_payment_method_id = db.Column(db.Integer)
    spending_limit = db.Column(db.Float)
    
    # Notificaciones de Facturación
    notify_before_charge = db.Column(db.Boolean, default=True)
    notify_days_before = db.Column(db.Integer, default=3)
    notify_failed_payment = db.Column(db.Boolean, default=True)
    
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relación con User
    user = db.relationship('User', backref='billing_settings')

class InterfaceSettings(db.Model):
    """Configuraciones de interfaz y preferencias visuales"""
    __tablename__ = 'interface_settings'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    
    # Tema y Apariencia
    theme = db.Column(db.String(20), default='light')  # light, dark, auto
    color_scheme = db.Column(db.String(20), default='blue')
    font_size = db.Column(db.String(20), default='medium')  # small, medium, large
    density = db.Column(db.String(20), default='comfortable')  # compact, comfortable, spacious
    
    # Dashboard
    dashboard_layout = db.Column(db.Text)  # JSON con configuración de widgets
    default_page = db.Column(db.String(50), default='dashboard')
    show_welcome_message = db.Column(db.Boolean, default=True)
    
    # Configuraciones de Lista/Tabla
    items_per_page = db.Column(db.Integer, default=10)
    date_format = db.Column(db.String(20), default='DD/MM/YYYY')
    time_format = db.Column(db.String(10), default='24h')  # 12h, 24h
    
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relación con User
    user = db.relationship('User', backref='interface_settings')

class SecuritySettings(db.Model):
    """Configuraciones de seguridad y privacidad"""
    __tablename__ = 'security_settings'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    
    # Autenticación
    two_factor_enabled = db.Column(db.Boolean, default=False)
    two_factor_method = db.Column(db.String(20))  # sms, email, app
    session_timeout = db.Column(db.Integer, default=30)  # minutos
    
    # Privacidad
    data_sharing_consent = db.Column(db.Boolean, default=False)
    analytics_consent = db.Column(db.Boolean, default=True)
    marketing_consent = db.Column(db.Boolean, default=False)
    
    # Configuraciones de Sesión
    remember_device = db.Column(db.Boolean, default=True)
    logout_inactive_sessions = db.Column(db.Boolean, default=True)
    
    # Logs de Seguridad
    login_notifications = db.Column(db.Boolean, default=True)
    suspicious_activity_alerts = db.Column(db.Boolean, default=True)
    
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relación con User
    user = db.relationship('User', backref='security_settings')

class IntegrationSettings(db.Model):
    """Configuraciones de integraciones externas"""
    __tablename__ = 'integration_settings'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    
    # Integraciones de Calendario
    google_calendar_enabled = db.Column(db.Boolean, default=False)
    google_calendar_token = db.Column(db.Text)
    outlook_calendar_enabled = db.Column(db.Boolean, default=False)
    outlook_calendar_token = db.Column(db.Text)
    
    # Integraciones de Comunicación
    slack_enabled = db.Column(db.Boolean, default=False)
    slack_webhook = db.Column(db.String(255))
    teams_enabled = db.Column(db.Boolean, default=False)
    teams_webhook = db.Column(db.String(255))
    
    # Integraciones de Video
    zoom_enabled = db.Column(db.Boolean, default=False)
    zoom_api_key = db.Column(db.String(255))
    meet_enabled = db.Column(db.Boolean, default=False)
    
    # Configuraciones de Sincronización
    sync_contacts = db.Column(db.Boolean, default=False)
    sync_frequency = db.Column(db.String(20), default='daily')  # realtime, hourly, daily
    
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relación con User
    user = db.relationship('User', backref='integration_settings')

class SettingsHistory(db.Model):
    """Historial de cambios en configuraciones"""
    __tablename__ = 'settings_history'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    
    setting_type = db.Column(db.String(50), nullable=False)  # profile, notifications, etc.
    setting_key = db.Column(db.String(100), nullable=False)
    old_value = db.Column(db.Text)
    new_value = db.Column(db.Text)
    
    changed_at = db.Column(db.DateTime, default=datetime.utcnow)
    ip_address = db.Column(db.String(45))
    user_agent = db.Column(db.String(255))
    
    # Relación con User
    user = db.relationship('User', backref='settings_history')

# Función helper para inicializar configuraciones por defecto
def initialize_default_settings(user_id):
    """Inicializa configuraciones por defecto para un nuevo usuario"""
    
    # Crear perfil básico
    profile = UserProfile(user_id=user_id)
    db.session.add(profile)
    
    # Crear configuraciones de notificaciones
    notifications = NotificationSettings(user_id=user_id)
    db.session.add(notifications)
    
    # Crear configuraciones de calendario
    calendar = CalendarSettings(user_id=user_id)
    db.session.add(calendar)
    
    # Crear configuraciones de facturación
    billing = BillingSettings(user_id=user_id)
    db.session.add(billing)
    
    # Crear configuraciones de interfaz
    interface = InterfaceSettings(user_id=user_id)
    db.session.add(interface)
    
    # Crear configuraciones de seguridad
    security = SecuritySettings(user_id=user_id)
    db.session.add(security)
    
    # Crear configuraciones de integraciones
    integrations = IntegrationSettings(user_id=user_id)
    db.session.add(integrations)
    
    db.session.commit()
    
    return True

