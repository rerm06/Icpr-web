import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Star, TrendingUp, Clock, Users, ArrowRight } from 'lucide-react'
import { Link } from 'react-router-dom'

const CasesPage = () => {
  const cases = [
    {
      title: "Automatización Legal - TechCorp",
      industry: "Sector Legal",
      challenge: "Procesamiento manual de documentos legales tomaba 8 horas diarias",
      solution: "Implementación de RPA para automatización de documentos y flujos de trabajo",
      results: [
        "40% reducción en tiempo de procesamiento",
        "Eliminación de errores humanos",
        "Ahorro de $50,000 anuales en costos operativos"
      ],
      testimonial: "InnovAi Solutions transformó completamente nuestros procesos. La automatización nos permitió enfocar nuestro tiempo en tareas de mayor valor.",
      client: "María González, Directora de Operaciones",
      duration: "6 semanas",
      roi: "250%"
    },
    {
      title: "Chatbot de Atención Médica - HealthPlus",
      industry: "Salud",
      challenge: "Alto volumen de consultas repetitivas saturaba el personal médico",
      solution: "Chatbot inteligente para triaje inicial y respuestas a preguntas frecuentes",
      results: [
        "30% reducción en costos operativos",
        "25% aumento en satisfacción del cliente",
        "Disponibilidad 24/7 para pacientes"
      ],
      testimonial: "El chatbot ha mejorado significativamente la experiencia de nuestros pacientes y ha liberado tiempo valioso para nuestro personal médico.",
      client: "Dr. Carlos Rodríguez, Director Médico",
      duration: "4 semanas",
      roi: "180%"
    },
    {
      title: "Transformación Digital - EduTech",
      industry: "Educación",
      challenge: "Procesos educativos tradicionales limitaban el aprendizaje personalizado",
      solution: "Plataforma de aprendizaje adaptativo con IA y automatización de evaluaciones",
      results: [
        "50% mejora en retención de conocimiento",
        "Personalización completa del aprendizaje",
        "Reducción de 60% en tiempo de evaluación"
      ],
      testimonial: "La plataforma de IA ha revolucionado nuestra capacitación empresarial. Los resultados de aprendizaje han superado todas nuestras expectativas.",
      client: "Ana Martínez, Directora de Capacitación",
      duration: "8 semanas",
      roi: "320%"
    }
  ]

  const industries = [
    { name: "Sector Legal", projects: 15, savings: "$2.5M" },
    { name: "Salud", projects: 12, savings: "$1.8M" },
    { name: "Educación", projects: 10, savings: "$1.2M" },
    { name: "Manufactura", projects: 8, savings: "$3.1M" },
    { name: "Servicios Financieros", projects: 6, savings: "$2.8M" },
    { name: "Retail", projects: 5, savings: "$900K" }
  ]

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-blue-50 via-white to-purple-50 py-20">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-4xl mx-auto">
            <h1 className="text-4xl lg:text-5xl font-bold text-gray-900 mb-6">
              Casos de{' '}
              <span className="bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                Éxito
              </span>
            </h1>
            <p className="text-xl text-gray-600 mb-8">
              Descubra cómo hemos ayudado a empresas como la suya a transformar 
              sus operaciones y alcanzar resultados extraordinarios.
            </p>
          </div>
        </div>
      </section>

      {/* Success Stories */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="space-y-16">
            {cases.map((caseStudy, index) => (
              <Card key={index} className="overflow-hidden">
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 p-8">
                  <div className="lg:col-span-2 space-y-6">
                    <div>
                      <div className="flex items-center space-x-4 mb-4">
                        <h2 className="text-2xl font-bold text-gray-900">{caseStudy.title}</h2>
                        <Badge variant="secondary">{caseStudy.industry}</Badge>
                      </div>
                      
                      <div className="space-y-4">
                        <div>
                          <h3 className="text-lg font-semibold text-gray-900 mb-2">Desafío:</h3>
                          <p className="text-gray-600">{caseStudy.challenge}</p>
                        </div>
                        
                        <div>
                          <h3 className="text-lg font-semibold text-gray-900 mb-2">Solución:</h3>
                          <p className="text-gray-600">{caseStudy.solution}</p>
                        </div>
                        
                        <div>
                          <h3 className="text-lg font-semibold text-gray-900 mb-2">Resultados:</h3>
                          <ul className="space-y-2">
                            {caseStudy.results.map((result, idx) => (
                              <li key={idx} className="flex items-center space-x-2">
                                <TrendingUp className="h-4 w-4 text-green-500" />
                                <span className="text-gray-700">{result}</span>
                              </li>
                            ))}
                          </ul>
                        </div>
                      </div>
                    </div>

                    <div className="bg-gray-50 p-6 rounded-lg">
                      <div className="flex items-center mb-4">
                        {[...Array(5)].map((_, i) => (
                          <Star key={i} className="h-5 w-5 text-yellow-400 fill-current" />
                        ))}
                      </div>
                      <p className="text-gray-600 italic mb-4">"{caseStudy.testimonial}"</p>
                      <p className="text-sm font-medium text-gray-900">{caseStudy.client}</p>
                    </div>
                  </div>

                  <div className="lg:col-span-1 space-y-6">
                    <div className="bg-gradient-to-br from-blue-50 to-purple-50 p-6 rounded-lg">
                      <h3 className="text-lg font-semibold text-gray-900 mb-4">Métricas del Proyecto</h3>
                      <div className="space-y-4">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center space-x-2">
                            <Clock className="h-4 w-4 text-blue-600" />
                            <span className="text-sm text-gray-600">Duración</span>
                          </div>
                          <span className="font-semibold text-gray-900">{caseStudy.duration}</span>
                        </div>
                        <div className="flex items-center justify-between">
                          <div className="flex items-center space-x-2">
                            <TrendingUp className="h-4 w-4 text-green-600" />
                            <span className="text-sm text-gray-600">ROI</span>
                          </div>
                          <span className="font-semibold text-green-600">{caseStudy.roi}</span>
                        </div>
                      </div>
                    </div>

                    <Link to="/contacto">
                      <Button className="w-full bg-gradient-to-r from-blue-600 to-purple-600">
                        Solicitar Caso Similar
                        <ArrowRight className="ml-2 h-4 w-4" />
                      </Button>
                    </Link>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Industries Overview */}
      <section className="py-20 bg-gray-50">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">
              Impacto por Industria
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Resultados comprobados en múltiples sectores con ahorros significativos 
              y mejoras en eficiencia operativa.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {industries.map((industry, index) => (
              <Card key={index} className="text-center group hover:shadow-lg transition-shadow duration-300">
                <CardContent className="p-6">
                  <h3 className="text-lg font-semibold text-gray-900 mb-4">
                    {industry.name}
                  </h3>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-gray-600">Proyectos:</span>
                      <span className="font-semibold text-blue-600">{industry.projects}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-gray-600">Ahorros:</span>
                      <span className="font-semibold text-green-600">{industry.savings}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-blue-600 to-purple-600">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center text-white max-w-4xl mx-auto">
            <h2 className="text-3xl lg:text-4xl font-bold mb-4">
              ¿Su empresa podría ser nuestro próximo caso de éxito?
            </h2>
            <p className="text-xl mb-8 opacity-90">
              Descubra cómo podemos ayudarle a alcanzar resultados similares 
              con una consulta gratuita personalizada.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link to="/contacto">
                <Button size="lg" className="bg-white text-blue-600 hover:bg-gray-100">
                  Agendar Consulta Gratuita
                  <ArrowRight className="ml-2 h-5 w-5" />
                </Button>
              </Link>
              <Button variant="outline" size="lg" className="border-white text-white hover:bg-white hover:text-blue-600">
                Descargar Casos Completos
              </Button>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}

export default CasesPage

