import { BrowserRouter as Router, Routes, Route } from 'react-router-dom'
import { useState, createContext, useContext } from 'react'
import './App.css'
import './styles/neomorphism.css'

// Components
import Header from './components/Header'
import Footer from './components/Footer'
import FloatingElements from './components/FloatingElements'
import HomePage from './components/pages/HomePage'
import ServicesPage from './components/pages/ServicesPage'
import AboutPage from './components/pages/AboutPage'
import CasesPage from './components/pages/CasesPage'
import ContactPage from './components/pages/ContactPage'
import LoginPage from './components/pages/LoginPage'
import Dashboard from './components/dashboard/Dashboard'

// Context for user authentication
const AuthContext = createContext()

export const useAuth = () => {
  const context = useContext(AuthContext)
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider')
  }
  return context
}

function App() {
  const [user, setUser] = useState(null)
  const [isAuthenticated, setIsAuthenticated] = useState(false)

  const login = (userData) => {
    setUser(userData)
    setIsAuthenticated(true)
  }

  const logout = () => {
    setUser(null)
    setIsAuthenticated(false)
  }

  const authValue = {
    user,
    isAuthenticated,
    login,
    logout
  }

  return (
    <AuthContext.Provider value={authValue}>
      <Router>
        <div className="min-h-screen particle-bg" style={{background: 'var(--bg-primary)'}}>
          <FloatingElements />
          <Header />
          <main className="relative z-10">
            <Routes>
              <Route path="/" element={<HomePage />} />
              <Route path="/servicios" element={<ServicesPage />} />
              <Route path="/nosotros" element={<AboutPage />} />
              <Route path="/casos-exito" element={<CasesPage />} />
              <Route path="/contacto" element={<ContactPage />} />
              <Route path="/login" element={<LoginPage />} />
              <Route path="/dashboard/*" element={<Dashboard />} />
            </Routes>
          </main>
          <Footer />
        </div>
      </Router>
    </AuthContext.Provider>
  )
}

export default App

