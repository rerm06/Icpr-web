import { useState } from 'react'
import { Link } from 'react-router-dom'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { 
  ArrowRight, 
  Bot, 
  Zap, 
  Users, 
  TrendingUp, 
  CheckCircle, 
  Star,
  Play,
  ChevronRight
} from 'lucide-react'

const HomePage = () => {
  const [email, setEmail] = useState('')
  const [message, setMessage] = useState('')

  const services = [
    {
      icon: <Zap className="h-8 w-8 text-blue-600" />,
      title: "Automatización Inteligente",
      description: "Optimizamos procesos empresariales con RPA y flujos de trabajo automatizados que aumentan la eficiencia hasta un 47%.",
      features: ["RPA Avanzado", "Flujos de Trabajo", "Integración de Sistemas"]
    },
    {
      icon: <Bot className="h-8 w-8 text-purple-600" />,
      title: "Chatbots Personalizados",
      description: "Asistentes virtuales 24/7 que mejoran la atención al cliente y generan leads de manera automatizada.",
      features: ["Servicio 24/7", "Generación de Leads", "Marketing Automatizado"]
    },
    {
      icon: <Users className="h-8 w-8 text-orange-600" />,
      title: "Consultoría Digital",
      description: "Transformación digital completa con análisis detallado y soluciones personalizadas para su negocio.",
      features: ["Análisis de Procesos", "Estrategia Digital", "Implementación"]
    },
    {
      icon: <TrendingUp className="h-8 w-8 text-green-600" />,
      title: "Diseño Instruccional",
      description: "Programas educativos empresariales que integran IA para maximizar el aprendizaje y desarrollo.",
      features: ["Programas Personalizados", "Integración IA", "Desarrollo Profesional"]
    }
  ]

  const stats = [
    { number: "150%", label: "ROI Promedio" },
    { number: "47%", label: "Aumento Productividad" },
    { number: "29%", label: "Reducción Costos" },
    { number: "24/7", label: "Soporte Disponible" }
  ]

  const testimonials = [
    {
      name: "María González",
      company: "TechCorp",
      text: "InnovAi Solutions transformó completamente nuestros procesos. Hemos visto una reducción del 40% en tiempo de procesamiento.",
      rating: 5
    },
    {
      name: "Carlos Rodríguez",
      company: "HealthPlus",
      text: "La automatización inteligente nos ayudó a reducir costos operativos en un 30% y mejorar la satisfacción del cliente en un 25%.",
      rating: 5
    },
    {
      name: "Ana Martínez",
      company: "EduTech",
      text: "Los programas de diseño instruccional con IA han revolucionado nuestra capacitación empresarial.",
      rating: 5
    }
  ]

  const process = [
    {
      step: "01",
      title: "Análisis",
      description: "Evaluamos sus procesos actuales y identificamos oportunidades de mejora."
    },
    {
      step: "02",
      title: "Diseño",
      description: "Creamos soluciones personalizadas adaptadas a sus necesidades específicas."
    },
    {
      step: "03",
      title: "Implementación",
      description: "Desplegamos las soluciones con mínima interrupción de sus operaciones."
    },
    {
      step: "04",
      title: "Optimización",
      description: "Monitoreamos y mejoramos continuamente el rendimiento de las soluciones."
    }
  ]

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-br from-blue-50 via-white to-purple-50 py-20 lg:py-32">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div className="space-y-8">
              <div className="space-y-4">
                <h1 className="text-4xl lg:text-6xl font-bold text-gray-900 leading-tight">
                  Transformación Digital con{' '}
                  <span className="bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                    Inteligencia Artificial
                  </span>
                </h1>
                <p className="text-xl text-gray-600 leading-relaxed">
                  Automatizamos procesos empresariales y creamos chatbots personalizados que impulsan 
                  la eficiencia, reducen costos y mejoran la experiencia del cliente.
                </p>
              </div>
              
              <div className="flex flex-col sm:flex-row gap-4">
                <Link to="/contacto">
                  <Button size="lg" className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white px-8 py-3">
                    Consulta Gratuita
                    <ArrowRight className="ml-2 h-5 w-5" />
                  </Button>
                </Link>
                <Button variant="outline" size="lg" className="px-8 py-3">
                  <Play className="mr-2 h-5 w-5" />
                  Ver Demo
                </Button>
              </div>

              <div className="flex items-center space-x-8 text-sm text-gray-600">
                <div className="flex items-center space-x-2">
                  <CheckCircle className="h-5 w-5 text-green-500" />
                  <span>Implementación rápida</span>
                </div>
                <div className="flex items-center space-x-2">
                  <CheckCircle className="h-5 w-5 text-green-500" />
                  <span>ROI garantizado</span>
                </div>
                <div className="flex items-center space-x-2">
                  <CheckCircle className="h-5 w-5 text-green-500" />
                  <span>Soporte 24/7</span>
                </div>
              </div>
            </div>

            <div className="relative">
              <img 
                src="/src/assets/images/transformacion_digital_hero.png" 
                alt="Transformación Digital" 
                className="w-full h-auto rounded-lg shadow-2xl"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-blue-600/20 to-transparent rounded-lg"></div>
            </div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-8">
            {stats.map((stat, index) => (
              <div key={index} className="text-center">
                <div className="text-3xl lg:text-4xl font-bold text-blue-600 mb-2">
                  {stat.number}
                </div>
                <div className="text-gray-600 font-medium">
                  {stat.label}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section className="py-20 bg-gray-50">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">
              Nuestros Servicios
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Soluciones integrales de automatización e inteligencia artificial 
              diseñadas para transformar su negocio
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {services.map((service, index) => (
              <Card key={index} className="group hover:shadow-lg transition-shadow duration-300">
                <CardHeader>
                  <div className="flex items-center space-x-4">
                    <div className="p-3 bg-gray-100 rounded-lg group-hover:bg-blue-50 transition-colors">
                      {service.icon}
                    </div>
                    <div>
                      <CardTitle className="text-xl">{service.title}</CardTitle>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <CardDescription className="text-gray-600 mb-4">
                    {service.description}
                  </CardDescription>
                  <ul className="space-y-2">
                    {service.features.map((feature, idx) => (
                      <li key={idx} className="flex items-center space-x-2 text-sm">
                        <CheckCircle className="h-4 w-4 text-green-500" />
                        <span>{feature}</span>
                      </li>
                    ))}
                  </ul>
                  <div className="mt-4">
                    <Link to="/servicios" className="text-blue-600 hover:text-blue-700 font-medium inline-flex items-center">
                      Saber más
                      <ChevronRight className="ml-1 h-4 w-4" />
                    </Link>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Process Section */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">
              Nuestro Proceso
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Un enfoque estructurado que garantiza resultados exitosos en cada proyecto
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {process.map((step, index) => (
              <div key={index} className="text-center group">
                <div className="relative mb-6">
                  <div className="w-16 h-16 bg-gradient-to-r from-blue-600 to-purple-600 rounded-full flex items-center justify-center text-white font-bold text-lg mx-auto group-hover:scale-110 transition-transform duration-300">
                    {step.step}
                  </div>
                  {index < process.length - 1 && (
                    <div className="hidden lg:block absolute top-8 left-full w-full h-0.5 bg-gray-200 -translate-x-8"></div>
                  )}
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-2">
                  {step.title}
                </h3>
                <p className="text-gray-600">
                  {step.description}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="py-20 bg-gray-50">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">
              Lo que dicen nuestros clientes
            </h2>
            <p className="text-xl text-gray-600">
              Testimonios reales de empresas que han transformado sus operaciones
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {testimonials.map((testimonial, index) => (
              <Card key={index} className="bg-white">
                <CardContent className="p-6">
                  <div className="flex items-center mb-4">
                    {[...Array(testimonial.rating)].map((_, i) => (
                      <Star key={i} className="h-5 w-5 text-yellow-400 fill-current" />
                    ))}
                  </div>
                  <p className="text-gray-600 mb-4 italic">
                    "{testimonial.text}"
                  </p>
                  <div>
                    <div className="font-semibold text-gray-900">
                      {testimonial.name}
                    </div>
                    <div className="text-sm text-gray-500">
                      {testimonial.company}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-blue-600 to-purple-600">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-4xl mx-auto text-center text-white">
            <h2 className="text-3xl lg:text-4xl font-bold mb-4">
              ¿Listo para transformar su negocio?
            </h2>
            <p className="text-xl mb-8 opacity-90">
              Obtenga una consulta gratuita y descubra cómo la automatización inteligente 
              puede impulsar su empresa hacia el futuro.
            </p>
            
            <div className="max-w-md mx-auto">
              <div className="flex flex-col sm:flex-row gap-4">
                <Input
                  type="email"
                  placeholder="Su email empresarial"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="bg-white text-gray-900"
                />
                <Button 
                  size="lg" 
                  className="bg-white text-blue-600 hover:bg-gray-100 font-semibold"
                >
                  Comenzar Ahora
                </Button>
              </div>
              <p className="text-sm mt-4 opacity-75">
                Sin compromiso. Consulta gratuita de 30 minutos.
              </p>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}

export default HomePage

