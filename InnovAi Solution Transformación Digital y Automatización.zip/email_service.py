import smtplib
import ssl
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.mime.base import MIMEBase
from email import encoders
from datetime import datetime, timedelta
import os
import logging

class EmailService:
    def __init__(self):
        # Configuración de email (usar variables de entorno en producción)
        self.smtp_server = "smtp.gmail.com"
        self.port = 587
        self.sender_email = "noreply@innovaisolutions.com"
        self.sender_password = "app_password_here"  # En producción usar variables de entorno
        
    def send_email(self, recipient_email, subject, html_content, text_content=None):
        """Enviar email con contenido HTML y texto plano"""
        try:
            message = MIMEMultipart("alternative")
            message["Subject"] = subject
            message["From"] = self.sender_email
            message["To"] = recipient_email
            
            # Crear partes del mensaje
            if text_content:
                part1 = MIMEText(text_content, "plain")
                message.attach(part1)
            
            part2 = MIMEText(html_content, "html")
            message.attach(part2)
            
            # Crear conexión segura y enviar email
            context = ssl.create_default_context()
            with smtplib.SMTP(self.smtp_server, self.port) as server:
                server.starttls(context=context)
                server.login(self.sender_email, self.sender_password)
                server.sendmail(self.sender_email, recipient_email, message.as_string())
            
            logging.info(f"Email enviado exitosamente a {recipient_email}")
            return True
            
        except Exception as e:
            logging.error(f"Error enviando email a {recipient_email}: {str(e)}")
            return False
    
    def send_appointment_confirmation(self, appointment_data, user_email, consultant_email):
        """Enviar confirmación de cita al usuario y consultor"""
        
        # Email para el usuario
        user_subject = f"Confirmación de Cita - {appointment_data['title']}"
        user_html = self._generate_appointment_confirmation_html(appointment_data, is_consultant=False)
        
        # Email para el consultor
        consultant_subject = f"Nueva Cita Agendada - {appointment_data['title']}"
        consultant_html = self._generate_appointment_confirmation_html(appointment_data, is_consultant=True)
        
        # Enviar ambos emails
        user_sent = self.send_email(user_email, user_subject, user_html)
        consultant_sent = self.send_email(consultant_email, consultant_subject, consultant_html)
        
        return user_sent and consultant_sent
    
    def send_appointment_reminder(self, appointment_data, user_email, consultant_email, hours_before=24):
        """Enviar recordatorio de cita"""
        
        subject = f"Recordatorio: Cita en {hours_before} horas - {appointment_data['title']}"
        
        # Email para el usuario
        user_html = self._generate_appointment_reminder_html(appointment_data, hours_before, is_consultant=False)
        
        # Email para el consultor
        consultant_html = self._generate_appointment_reminder_html(appointment_data, hours_before, is_consultant=True)
        
        # Enviar ambos emails
        user_sent = self.send_email(user_email, subject, user_html)
        consultant_sent = self.send_email(consultant_email, subject, consultant_html)
        
        return user_sent and consultant_sent
    
    def send_invoice_notification(self, invoice_data, user_email):
        """Enviar notificación de nueva factura"""
        
        subject = f"Nueva Factura Disponible - {invoice_data['invoice_number']}"
        html_content = self._generate_invoice_notification_html(invoice_data)
        
        return self.send_email(user_email, subject, html_content)
    
    def send_payment_confirmation(self, payment_data, user_email):
        """Enviar confirmación de pago"""
        
        subject = f"Pago Confirmado - {payment_data['invoice_number']}"
        html_content = self._generate_payment_confirmation_html(payment_data)
        
        return self.send_email(user_email, subject, html_content)
    
    def _generate_appointment_confirmation_html(self, appointment_data, is_consultant=False):
        """Generar HTML para confirmación de cita"""
        
        recipient = "Estimado consultor" if is_consultant else "Estimado cliente"
        action = "tiene una nueva cita agendada" if is_consultant else "su cita ha sido confirmada"
        
        html = f"""
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset="utf-8">
            <title>Confirmación de Cita</title>
            <style>
                body {{ font-family: Arial, sans-serif; line-height: 1.6; color: #333; }}
                .container {{ max-width: 600px; margin: 0 auto; padding: 20px; }}
                .header {{ background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 30px; text-align: center; border-radius: 10px 10px 0 0; }}
                .content {{ background: #f8f9fa; padding: 30px; border-radius: 0 0 10px 10px; }}
                .appointment-details {{ background: white; padding: 20px; border-radius: 8px; margin: 20px 0; border-left: 4px solid #667eea; }}
                .detail-row {{ display: flex; justify-content: space-between; margin: 10px 0; padding: 8px 0; border-bottom: 1px solid #eee; }}
                .detail-label {{ font-weight: bold; color: #555; }}
                .detail-value {{ color: #333; }}
                .button {{ display: inline-block; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; margin: 10px 0; }}
                .footer {{ text-align: center; margin-top: 30px; color: #666; font-size: 14px; }}
            </style>
        </head>
        <body>
            <div class="container">
                <div class="header">
                    <h1>InnovAi Solutions</h1>
                    <h2>Confirmación de Cita</h2>
                </div>
                
                <div class="content">
                    <p>{recipient},</p>
                    <p>Le confirmamos que {action} con los siguientes detalles:</p>
                    
                    <div class="appointment-details">
                        <h3>{appointment_data['title']}</h3>
                        
                        <div class="detail-row">
                            <span class="detail-label">Fecha:</span>
                            <span class="detail-value">{appointment_data['scheduled_date']}</span>
                        </div>
                        
                        <div class="detail-row">
                            <span class="detail-label">Hora:</span>
                            <span class="detail-value">{appointment_data['scheduled_time']}</span>
                        </div>
                        
                        <div class="detail-row">
                            <span class="detail-label">Duración:</span>
                            <span class="detail-value">{appointment_data['duration_minutes']} minutos</span>
                        </div>
                        
                        <div class="detail-row">
                            <span class="detail-label">Tipo de reunión:</span>
                            <span class="detail-value">{appointment_data.get('meeting_type', 'Video llamada')}</span>
                        </div>
                        
                        <div class="detail-row">
                            <span class="detail-label">Propósito:</span>
                            <span class="detail-value">{appointment_data.get('purpose', 'Consulta')}</span>
                        </div>
                        
                        {f'<div class="detail-row"><span class="detail-label">Descripción:</span><span class="detail-value">{appointment_data.get("description", "")}</span></div>' if appointment_data.get('description') else ''}
                        
                        {f'<div class="detail-row"><span class="detail-label">Notas:</span><span class="detail-value">{appointment_data.get("notes", "")}</span></div>' if appointment_data.get('notes') else ''}
                    </div>
                    
                    <p>Recibirá un recordatorio 24 horas antes de la cita.</p>
                    
                    <div style="text-align: center;">
                        <a href="https://innovaisolutions.com/dashboard/calendar" class="button">Ver en Calendario</a>
                    </div>
                    
                    <p>Si necesita reprogramar o cancelar esta cita, por favor contáctenos con al menos 24 horas de anticipación.</p>
                </div>
                
                <div class="footer">
                    <p>InnovAi Solutions - Transformación Digital e Inteligencia Artificial</p>
                    <p>Email: info@innovaisolutions.com | Teléfono: +1 (555) 123-4567</p>
                </div>
            </div>
        </body>
        </html>
        """
        
        return html
    
    def _generate_appointment_reminder_html(self, appointment_data, hours_before, is_consultant=False):
        """Generar HTML para recordatorio de cita"""
        
        recipient = "Estimado consultor" if is_consultant else "Estimado cliente"
        
        html = f"""
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset="utf-8">
            <title>Recordatorio de Cita</title>
            <style>
                body {{ font-family: Arial, sans-serif; line-height: 1.6; color: #333; }}
                .container {{ max-width: 600px; margin: 0 auto; padding: 20px; }}
                .header {{ background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%); color: white; padding: 30px; text-align: center; border-radius: 10px 10px 0 0; }}
                .content {{ background: #f8f9fa; padding: 30px; border-radius: 0 0 10px 10px; }}
                .reminder-box {{ background: #fff3cd; border: 1px solid #ffeaa7; padding: 20px; border-radius: 8px; margin: 20px 0; }}
                .appointment-details {{ background: white; padding: 20px; border-radius: 8px; margin: 20px 0; border-left: 4px solid #f5576c; }}
                .detail-row {{ display: flex; justify-content: space-between; margin: 10px 0; padding: 8px 0; border-bottom: 1px solid #eee; }}
                .detail-label {{ font-weight: bold; color: #555; }}
                .detail-value {{ color: #333; }}
                .button {{ display: inline-block; background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%); color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; margin: 10px 0; }}
                .footer {{ text-align: center; margin-top: 30px; color: #666; font-size: 14px; }}
            </style>
        </head>
        <body>
            <div class="container">
                <div class="header">
                    <h1>InnovAi Solutions</h1>
                    <h2>Recordatorio de Cita</h2>
                </div>
                
                <div class="content">
                    <p>{recipient},</p>
                    
                    <div class="reminder-box">
                        <h3>⏰ Recordatorio: Su cita es en {hours_before} horas</h3>
                        <p>No olvide su próxima cita programada.</p>
                    </div>
                    
                    <div class="appointment-details">
                        <h3>{appointment_data['title']}</h3>
                        
                        <div class="detail-row">
                            <span class="detail-label">Fecha:</span>
                            <span class="detail-value">{appointment_data['scheduled_date']}</span>
                        </div>
                        
                        <div class="detail-row">
                            <span class="detail-label">Hora:</span>
                            <span class="detail-value">{appointment_data['scheduled_time']}</span>
                        </div>
                        
                        <div class="detail-row">
                            <span class="detail-label">Duración:</span>
                            <span class="detail-value">{appointment_data['duration_minutes']} minutos</span>
                        </div>
                        
                        <div class="detail-row">
                            <span class="detail-label">Tipo de reunión:</span>
                            <span class="detail-value">{appointment_data.get('meeting_type', 'Video llamada')}</span>
                        </div>
                    </div>
                    
                    <div style="text-align: center;">
                        <a href="https://innovaisolutions.com/dashboard/calendar" class="button">Ver Detalles</a>
                    </div>
                    
                    <p>Si necesita reprogramar o cancelar esta cita, por favor contáctenos lo antes posible.</p>
                </div>
                
                <div class="footer">
                    <p>InnovAi Solutions - Transformación Digital e Inteligencia Artificial</p>
                    <p>Email: info@innovaisolutions.com | Teléfono: +1 (555) 123-4567</p>
                </div>
            </div>
        </body>
        </html>
        """
        
        return html
    
    def _generate_invoice_notification_html(self, invoice_data):
        """Generar HTML para notificación de factura"""
        
        html = f"""
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset="utf-8">
            <title>Nueva Factura</title>
            <style>
                body {{ font-family: Arial, sans-serif; line-height: 1.6; color: #333; }}
                .container {{ max-width: 600px; margin: 0 auto; padding: 20px; }}
                .header {{ background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%); color: white; padding: 30px; text-align: center; border-radius: 10px 10px 0 0; }}
                .content {{ background: #f8f9fa; padding: 30px; border-radius: 0 0 10px 10px; }}
                .invoice-details {{ background: white; padding: 20px; border-radius: 8px; margin: 20px 0; border-left: 4px solid #4facfe; }}
                .amount {{ font-size: 24px; font-weight: bold; color: #4facfe; text-align: center; margin: 20px 0; }}
                .button {{ display: inline-block; background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%); color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; margin: 10px 5px; }}
                .footer {{ text-align: center; margin-top: 30px; color: #666; font-size: 14px; }}
            </style>
        </head>
        <body>
            <div class="container">
                <div class="header">
                    <h1>InnovAi Solutions</h1>
                    <h2>Nueva Factura Disponible</h2>
                </div>
                
                <div class="content">
                    <p>Estimado cliente,</p>
                    <p>Tiene una nueva factura disponible para su revisión y pago.</p>
                    
                    <div class="invoice-details">
                        <h3>Factura: {invoice_data['invoice_number']}</h3>
                        <p><strong>Descripción:</strong> {invoice_data['description']}</p>
                        <p><strong>Fecha de emisión:</strong> {invoice_data['issue_date']}</p>
                        <p><strong>Fecha de vencimiento:</strong> {invoice_data['due_date']}</p>
                        
                        <div class="amount">
                            Total: ${invoice_data['total_amount']} {invoice_data['currency']}
                        </div>
                    </div>
                    
                    <div style="text-align: center;">
                        <a href="https://innovaisolutions.com/dashboard/billing" class="button">Ver Factura</a>
                        <a href="https://innovaisolutions.com/dashboard/billing" class="button">Pagar Ahora</a>
                    </div>
                    
                    <p>Para evitar interrupciones en el servicio, por favor realice el pago antes de la fecha de vencimiento.</p>
                </div>
                
                <div class="footer">
                    <p>InnovAi Solutions - Transformación Digital e Inteligencia Artificial</p>
                    <p>Email: billing@innovaisolutions.com | Teléfono: +1 (555) 123-4567</p>
                </div>
            </div>
        </body>
        </html>
        """
        
        return html
    
    def _generate_payment_confirmation_html(self, payment_data):
        """Generar HTML para confirmación de pago"""
        
        html = f"""
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset="utf-8">
            <title>Pago Confirmado</title>
            <style>
                body {{ font-family: Arial, sans-serif; line-height: 1.6; color: #333; }}
                .container {{ max-width: 600px; margin: 0 auto; padding: 20px; }}
                .header {{ background: linear-gradient(135deg, #56ab2f 0%, #a8e6cf 100%); color: white; padding: 30px; text-align: center; border-radius: 10px 10px 0 0; }}
                .content {{ background: #f8f9fa; padding: 30px; border-radius: 0 0 10px 10px; }}
                .payment-details {{ background: white; padding: 20px; border-radius: 8px; margin: 20px 0; border-left: 4px solid #56ab2f; }}
                .success-icon {{ font-size: 48px; text-align: center; margin: 20px 0; }}
                .amount {{ font-size: 24px; font-weight: bold; color: #56ab2f; text-align: center; margin: 20px 0; }}
                .button {{ display: inline-block; background: linear-gradient(135deg, #56ab2f 0%, #a8e6cf 100%); color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; margin: 10px 0; }}
                .footer {{ text-align: center; margin-top: 30px; color: #666; font-size: 14px; }}
            </style>
        </head>
        <body>
            <div class="container">
                <div class="header">
                    <h1>InnovAi Solutions</h1>
                    <h2>Pago Confirmado</h2>
                </div>
                
                <div class="content">
                    <div class="success-icon">✅</div>
                    
                    <p>Estimado cliente,</p>
                    <p>Su pago ha sido procesado exitosamente. Gracias por su confianza en nuestros servicios.</p>
                    
                    <div class="payment-details">
                        <h3>Detalles del Pago</h3>
                        <p><strong>Factura:</strong> {payment_data['invoice_number']}</p>
                        <p><strong>Fecha de pago:</strong> {payment_data.get('payment_date', datetime.now().strftime('%Y-%m-%d'))}</p>
                        <p><strong>Método de pago:</strong> {payment_data.get('payment_method', 'Tarjeta de crédito')}</p>
                        
                        <div class="amount">
                            Monto pagado: ${payment_data['amount']} {payment_data.get('currency', 'USD')}
                        </div>
                    </div>
                    
                    <div style="text-align: center;">
                        <a href="https://innovaisolutions.com/dashboard/billing" class="button">Ver Recibo</a>
                    </div>
                    
                    <p>Su recibo de pago está disponible en su panel de control. Si tiene alguna pregunta, no dude en contactarnos.</p>
                </div>
                
                <div class="footer">
                    <p>InnovAi Solutions - Transformación Digital e Inteligencia Artificial</p>
                    <p>Email: billing@innovaisolutions.com | Teléfono: +1 (555) 123-4567</p>
                </div>
            </div>
        </body>
        </html>
        """
        
        return html

# Instancia global del servicio de email
email_service = EmailService()

