from flask_sqlalchemy import SQLAlchemy
from datetime import datetime, timedelta
import uuid

db = SQLAlchemy()

class Consultant(db.Model):
    __tablename__ = 'consultants'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(120), nullable=False)
    phone = db.Column(db.String(20))
    specialization = db.Column(db.String(200))
    bio = db.Column(db.Text)
    hourly_rate = db.Column(db.Float, default=0.0)
    timezone = db.Column(db.String(50), default='UTC')
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relaciones
    appointments = db.relationship('Appointment', backref='consultant', lazy=True)
    availability = db.relationship('ConsultantAvailability', backref='consultant', lazy=True)
    
    def to_dict(self):
        return {
            'id': self.id,
            'user_id': self.user_id,
            'name': self.name,
            'email': self.email,
            'phone': self.phone,
            'specialization': self.specialization,
            'bio': self.bio,
            'hourly_rate': self.hourly_rate,
            'timezone': self.timezone,
            'is_active': self.is_active,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }

class ConsultantAvailability(db.Model):
    __tablename__ = 'consultant_availability'
    
    id = db.Column(db.Integer, primary_key=True)
    consultant_id = db.Column(db.Integer, db.ForeignKey('consultants.id'), nullable=False)
    day_of_week = db.Column(db.Integer, nullable=False)  # 0=Monday, 6=Sunday
    start_time = db.Column(db.Time, nullable=False)
    end_time = db.Column(db.Time, nullable=False)
    is_available = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def to_dict(self):
        return {
            'id': self.id,
            'consultant_id': self.consultant_id,
            'day_of_week': self.day_of_week,
            'start_time': self.start_time.strftime('%H:%M') if self.start_time else None,
            'end_time': self.end_time.strftime('%H:%M') if self.end_time else None,
            'is_available': self.is_available,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }

class Appointment(db.Model):
    __tablename__ = 'appointments'
    
    id = db.Column(db.Integer, primary_key=True)
    appointment_key = db.Column(db.String(36), unique=True, nullable=False, default=lambda: str(uuid.uuid4()))
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    consultant_id = db.Column(db.Integer, db.ForeignKey('consultants.id'), nullable=False)
    
    # Detalles de la cita
    title = db.Column(db.String(200), nullable=False)
    description = db.Column(db.Text)
    purpose = db.Column(db.String(100))  # consultation, review, support, etc.
    notes = db.Column(db.Text)
    
    # Fecha y hora
    scheduled_date = db.Column(db.Date, nullable=False)
    scheduled_time = db.Column(db.Time, nullable=False)
    duration_minutes = db.Column(db.Integer, default=60)
    timezone = db.Column(db.String(50), default='UTC')
    
    # Estado
    status = db.Column(db.String(20), default='scheduled')  # scheduled, confirmed, completed, cancelled, rescheduled
    meeting_link = db.Column(db.String(500))
    meeting_type = db.Column(db.String(20), default='video')  # video, phone, in-person
    
    # Confirmaciones y recordatorios
    client_confirmed = db.Column(db.Boolean, default=False)
    consultant_confirmed = db.Column(db.Boolean, default=False)
    reminder_sent = db.Column(db.Boolean, default=False)
    confirmation_sent = db.Column(db.Boolean, default=False)
    
    # Metadatos
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    cancelled_at = db.Column(db.DateTime)
    cancellation_reason = db.Column(db.Text)
    
    def to_dict(self):
        return {
            'id': self.id,
            'appointment_key': self.appointment_key,
            'user_id': self.user_id,
            'consultant_id': self.consultant_id,
            'title': self.title,
            'description': self.description,
            'purpose': self.purpose,
            'notes': self.notes,
            'scheduled_date': self.scheduled_date.isoformat() if self.scheduled_date else None,
            'scheduled_time': self.scheduled_time.strftime('%H:%M') if self.scheduled_time else None,
            'duration_minutes': self.duration_minutes,
            'timezone': self.timezone,
            'status': self.status,
            'meeting_link': self.meeting_link,
            'meeting_type': self.meeting_type,
            'client_confirmed': self.client_confirmed,
            'consultant_confirmed': self.consultant_confirmed,
            'reminder_sent': self.reminder_sent,
            'confirmation_sent': self.confirmation_sent,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None,
            'cancelled_at': self.cancelled_at.isoformat() if self.cancelled_at else None,
            'cancellation_reason': self.cancellation_reason
        }

class AppointmentReminder(db.Model):
    __tablename__ = 'appointment_reminders'
    
    id = db.Column(db.Integer, primary_key=True)
    appointment_id = db.Column(db.Integer, db.ForeignKey('appointments.id'), nullable=False)
    reminder_type = db.Column(db.String(20), nullable=False)  # email, sms, push
    recipient_type = db.Column(db.String(20), nullable=False)  # client, consultant, both
    scheduled_for = db.Column(db.DateTime, nullable=False)
    sent_at = db.Column(db.DateTime)
    status = db.Column(db.String(20), default='pending')  # pending, sent, failed
    error_message = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relación
    appointment = db.relationship('Appointment', backref='reminders')
    
    def to_dict(self):
        return {
            'id': self.id,
            'appointment_id': self.appointment_id,
            'reminder_type': self.reminder_type,
            'recipient_type': self.recipient_type,
            'scheduled_for': self.scheduled_for.isoformat() if self.scheduled_for else None,
            'sent_at': self.sent_at.isoformat() if self.sent_at else None,
            'status': self.status,
            'error_message': self.error_message,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }

