import { Routes, Route, Link, useLocation } from 'react-router-dom'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { useAuth } from '../../App'
import WebhookManager from './WebhookManager'
import CalendarModule from './CalendarModule'
import BillingModule from './BillingModule'
import { 
  LayoutDashboard, 
  FileText, 
  CreditCard, 
  Calendar, 
  Settings, 
  HelpCircle,
  TrendingUp,
  Clock,
  CheckCircle,
  AlertCircle,
  DollarSign,
  Users,
  Webhook,
  Zap
} from 'lucide-react'

const Dashboard = () => {
  const { user } = useAuth()
  const location = useLocation()

  const navigation = [
    { name: 'Dashboard', href: '/dashboard', icon: LayoutDashboard },
    { name: 'Servicios', href: '/dashboard/services', icon: FileText },
    { name: 'Webhooks', href: '/dashboard/webhooks', icon: Webhook },
    { name: 'Facturación', href: '/dashboard/billing', icon: CreditCard },
    { name: 'Citas', href: '/dashboard/appointments', icon: Calendar },
    { name: 'Configuración', href: '/dashboard/settings', icon: Settings },
    { name: 'Soporte', href: '/dashboard/support', icon: HelpCircle },
  ]

  const isActive = (path) => location.pathname === path

  // Componente principal del dashboard
  const DashboardHome = () => {
    const stats = [
      {
        title: "Servicios Activos",
        value: "3",
        change: "+1 este mes",
        icon: <FileText className="h-4 w-4 text-blue-600" />
      },
      {
        title: "Ahorro Mensual",
        value: "$12,500",
        change: "+15% vs mes anterior",
        icon: <DollarSign className="h-4 w-4 text-green-600" />
      },
      {
        title: "Eficiencia",
        value: "87%",
        change: "+12% mejora",
        icon: <TrendingUp className="h-4 w-4 text-purple-600" />
      },
      {
        title: "Próxima Cita",
        value: "En 3 días",
        change: "Revisión mensual",
        icon: <Calendar className="h-4 w-4 text-orange-600" />
      }
    ]

    const recentActivities = [
      {
        title: "Chatbot actualizado",
        description: "Nuevas funcionalidades implementadas",
        time: "Hace 2 horas",
        status: "success"
      },
      {
        title: "Factura generada",
        description: "Factura #INV-2024-001 por $3,500",
        time: "Hace 1 día",
        status: "info"
      },
      {
        title: "Reunión programada",
        description: "Revisión mensual de automatización",
        time: "Hace 2 días",
        status: "warning"
      }
    ]

    return (
      <div className="space-y-8">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">
            Bienvenido, {user?.name}
          </h1>
          <p className="text-gray-600">
            Resumen de sus servicios y actividad reciente
          </p>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {stats.map((stat, index) => (
            <Card key={index}>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">{stat.title}</p>
                    <p className="text-2xl font-bold text-gray-900">{stat.value}</p>
                    <p className="text-xs text-green-600">{stat.change}</p>
                  </div>
                  <div className="p-3 bg-gray-100 rounded-lg">
                    {stat.icon}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Recent Activities */}
          <Card>
            <CardHeader>
              <CardTitle>Actividad Reciente</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {recentActivities.map((activity, index) => (
                  <div key={index} className="flex items-start space-x-3">
                    <div className={`p-1 rounded-full ${
                      activity.status === 'success' ? 'bg-green-100' :
                      activity.status === 'info' ? 'bg-blue-100' : 'bg-yellow-100'
                    }`}>
                      {activity.status === 'success' ? (
                        <CheckCircle className="h-4 w-4 text-green-600" />
                      ) : activity.status === 'info' ? (
                        <FileText className="h-4 w-4 text-blue-600" />
                      ) : (
                        <Clock className="h-4 w-4 text-yellow-600" />
                      )}
                    </div>
                    <div className="flex-1">
                      <p className="font-medium text-gray-900">{activity.title}</p>
                      <p className="text-sm text-gray-600">{activity.description}</p>
                      <p className="text-xs text-gray-500">{activity.time}</p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Quick Actions */}
          <Card>
            <CardHeader>
              <CardTitle>Acciones Rápidas</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <Button className="w-full justify-start" variant="outline">
                  <Calendar className="mr-2 h-4 w-4" />
                  Agendar Nueva Cita
                </Button>
                <Button className="w-full justify-start" variant="outline">
                  <FileText className="mr-2 h-4 w-4" />
                  Ver Facturas Pendientes
                </Button>
                <Button className="w-full justify-start" variant="outline">
                  <HelpCircle className="mr-2 h-4 w-4" />
                  Contactar Soporte
                </Button>
                <Button className="w-full justify-start" variant="outline">
                  <Settings className="mr-2 h-4 w-4" />
                  Configurar Notificaciones
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    )
  }

  // Componentes placeholder para otras secciones
  const ServicesSection = () => (
    <div>
      <h1 className="text-3xl font-bold text-gray-900 mb-6">Mis Servicios</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {[
          { name: "Chatbot Empresarial", status: "Activo", type: "Chatbot" },
          { name: "Automatización RPA", status: "Activo", type: "Automatización" },
          { name: "Consultoría Digital", status: "En Progreso", type: "Consultoría" }
        ].map((service, index) => (
          <Card key={index}>
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-semibold text-gray-900">{service.name}</h3>
                <Badge variant={service.status === 'Activo' ? 'default' : 'secondary'}>
                  {service.status}
                </Badge>
              </div>
              <p className="text-sm text-gray-600 mb-4">Tipo: {service.type}</p>
              <Button size="sm" variant="outline">Ver Detalles</Button>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )

  const BillingSection = () => <BillingModule />

  const AppointmentsSection = () => <CalendarModule />

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="flex">
        {/* Sidebar */}
        <div className="w-64 bg-white shadow-sm border-r min-h-screen">
          <div className="p-6">
            <div className="flex items-center space-x-2">
              <img 
                src="/src/assets/images/innovai_logo.jpeg" 
                alt="InnovAi Solutions" 
                className="h-8 w-auto"
              />
              <span className="font-bold text-gray-900">Portal Cliente</span>
            </div>
          </div>
          
          <nav className="px-4 space-y-2">
            {navigation.map((item) => {
              const Icon = item.icon
              return (
                <Link
                  key={item.name}
                  to={item.href}
                  className={`flex items-center space-x-3 px-3 py-2 rounded-lg text-sm font-medium transition-colors ${
                    isActive(item.href)
                      ? 'bg-blue-50 text-blue-700 border-r-2 border-blue-700'
                      : 'text-gray-600 hover:text-gray-900 hover:bg-gray-50'
                  }`}
                >
                  <Icon className="h-5 w-5" />
                  <span>{item.name}</span>
                </Link>
              )
            })}
          </nav>
        </div>

        {/* Main Content */}
        <div className="flex-1 p-8">
          <Routes>
            <Route path="/" element={<DashboardHome />} />
            <Route path="/services" element={<ServicesSection />} />
            <Route path="/webhooks" element={<WebhookManager />} />
            <Route path="/billing" element={<BillingSection />} />
            <Route path="/appointments" element={<AppointmentsSection />} />
            <Route path="/settings" element={<div>Configuración en desarrollo...</div>} />
            <Route path="/support" element={<div>Soporte en desarrollo...</div>} />
          </Routes>
        </div>
      </div>
    </div>
  )
}

export default Dashboard

