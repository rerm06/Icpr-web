import { Link } from 'react-router-dom'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { 
  Bot, 
  Zap, 
  Users, 
  TrendingUp, 
  CheckCircle, 
  ArrowRight,
  Cog,
  MessageSquare,
  BarChart3,
  GraduationCap,
  Workflow,
  Database,
  Clock,
  Target
} from 'lucide-react'

const ServicesPage = () => {
  const mainServices = [
    {
      icon: <Zap className="h-12 w-12 text-blue-600" />,
      title: "Automatización Inteligente",
      description: "Transformamos procesos manuales en flujos automatizados que aumentan la productividad hasta un 47%.",
      image: "/src/assets/images/automatizacion_inteligente.jpg",
      features: [
        "Automatización de Procesos Robóticos (RPA)",
        "Flujos de trabajo inteligentes",
        "Integración de sistemas empresariales",
        "Análisis y optimización de procesos"
      ],
      benefits: [
        "47% aumento en productividad",
        "29% reducción en costos operativos",
        "40% reducción en tiempo de procesamiento",
        "Eliminación de errores humanos"
      ],
      pricing: "Desde $3,000/mes"
    },
    {
      icon: <Bot className="h-12 w-12 text-purple-600" />,
      title: "Chatbots Personalizados",
      description: "Asistentes virtuales inteligentes que brindan atención 24/7 y generan leads automáticamente.",
      image: "/src/assets/images/chatbot_servicio.png",
      features: [
        "Chatbots de servicio al cliente 24/7",
        "Generación automática de leads",
        "Marketing conversacional",
        "Integración con CRM y sistemas existentes"
      ],
      benefits: [
        "28% aumento en satisfacción del cliente",
        "Disponibilidad 24/7 sin interrupciones",
        "Reducción de costos de atención",
        "Captura automática de leads"
      ],
      pricing: "Desde $1,500/mes"
    },
    {
      icon: <Users className="h-12 w-12 text-orange-600" />,
      title: "Consultoría en Transformación Digital",
      description: "Estrategias integrales para digitalizar y optimizar todos los aspectos de su negocio.",
      image: "/src/assets/images/ia_empresarial.jpg",
      features: [
        "Análisis completo de procesos actuales",
        "Estrategia de transformación digital",
        "Implementación de tecnologías no-code/low-code",
        "Capacitación y gestión del cambio"
      ],
      benefits: [
        "40% mejora en eficiencia operativa",
        "Implementación rápida y rentable",
        "Soluciones personalizadas",
        "Soporte continuo post-implementación"
      ],
      pricing: "Desde $5,000/proyecto"
    },
    {
      icon: <GraduationCap className="h-12 w-12 text-green-600" />,
      title: "Diseño Instruccional con IA",
      description: "Programas educativos empresariales que integran inteligencia artificial para maximizar el aprendizaje.",
      image: "/src/assets/images/equipo_trabajo.jpg",
      features: [
        "Programas educativos personalizados",
        "Integración de IA en procesos de enseñanza",
        "Desarrollo profesional para equipos",
        "Plataformas de aprendizaje adaptativo"
      ],
      benefits: [
        "Mejora en retención de conocimiento",
        "Personalización del aprendizaje",
        "Desarrollo de competencias digitales",
        "ROI medible en capacitación"
      ],
      pricing: "Desde $2,500/programa"
    }
  ]

  const additionalServices = [
    {
      icon: <Workflow className="h-8 w-8 text-blue-500" />,
      title: "Integración de Sistemas",
      description: "Conectamos sus aplicaciones existentes para crear un ecosistema tecnológico unificado."
    },
    {
      icon: <Database className="h-8 w-8 text-purple-500" />,
      title: "Gestión de Datos",
      description: "Organizamos y optimizamos sus datos para tomar decisiones más inteligentes."
    },
    {
      icon: <BarChart3 className="h-8 w-8 text-orange-500" />,
      title: "Analytics e Inteligencia de Negocios",
      description: "Dashboards y reportes automatizados que revelan insights valiosos de su negocio."
    },
    {
      icon: <MessageSquare className="h-8 w-8 text-green-500" />,
      title: "Comunicación Automatizada",
      description: "Sistemas de notificaciones y comunicación que mantienen a todos informados."
    }
  ]

  const industries = [
    { name: "Sector Legal", description: "Automatización de documentos y procesos legales" },
    { name: "Salud", description: "Gestión de pacientes y automatización administrativa" },
    { name: "Manufactura", description: "Optimización de cadena de suministro y producción" },
    { name: "Servicios Financieros", description: "Procesamiento de transacciones y compliance" },
    { name: "Educación", description: "Plataformas de aprendizaje y gestión académica" },
    { name: "Retail", description: "Gestión de inventario y experiencia del cliente" }
  ]

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-blue-50 via-white to-purple-50 py-20">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-4xl mx-auto">
            <h1 className="text-4xl lg:text-5xl font-bold text-gray-900 mb-6">
              Servicios de{' '}
              <span className="bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                Automatización e IA
              </span>
            </h1>
            <p className="text-xl text-gray-600 mb-8">
              Soluciones integrales que transforman procesos empresariales, 
              mejoran la eficiencia y impulsan el crecimiento sostenible.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link to="/contacto">
                <Button size="lg" className="bg-gradient-to-r from-blue-600 to-purple-600">
                  Consulta Gratuita
                  <ArrowRight className="ml-2 h-5 w-5" />
                </Button>
              </Link>
              <Button variant="outline" size="lg">
                Ver Casos de Éxito
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Main Services */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="space-y-20">
            {mainServices.map((service, index) => (
              <div key={index} className={`grid grid-cols-1 lg:grid-cols-2 gap-12 items-center ${
                index % 2 === 1 ? 'lg:grid-flow-col-dense' : ''
              }`}>
                <div className={`space-y-6 ${index % 2 === 1 ? 'lg:col-start-2' : ''}`}>
                  <div className="flex items-center space-x-4">
                    <div className="p-3 bg-gray-100 rounded-lg">
                      {service.icon}
                    </div>
                    <div>
                      <h2 className="text-3xl font-bold text-gray-900">{service.title}</h2>
                      <Badge variant="secondary" className="mt-2">{service.pricing}</Badge>
                    </div>
                  </div>
                  
                  <p className="text-lg text-gray-600">{service.description}</p>
                  
                  <div className="space-y-4">
                    <h3 className="text-xl font-semibold text-gray-900">Características:</h3>
                    <ul className="space-y-2">
                      {service.features.map((feature, idx) => (
                        <li key={idx} className="flex items-center space-x-2">
                          <CheckCircle className="h-5 w-5 text-green-500" />
                          <span className="text-gray-700">{feature}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  <div className="space-y-4">
                    <h3 className="text-xl font-semibold text-gray-900">Beneficios:</h3>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      {service.benefits.map((benefit, idx) => (
                        <div key={idx} className="flex items-center space-x-2">
                          <Target className="h-4 w-4 text-blue-600" />
                          <span className="text-sm text-gray-700">{benefit}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  <Link to="/contacto">
                    <Button className="bg-gradient-to-r from-blue-600 to-purple-600">
                      Solicitar Información
                      <ArrowRight className="ml-2 h-4 w-4" />
                    </Button>
                  </Link>
                </div>

                <div className={`${index % 2 === 1 ? 'lg:col-start-1' : ''}`}>
                  <img 
                    src={service.image} 
                    alt={service.title}
                    className="w-full h-auto rounded-lg shadow-lg"
                  />
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Additional Services */}
      <section className="py-20 bg-gray-50">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">
              Servicios Complementarios
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Soluciones adicionales que complementan nuestros servicios principales 
              para una transformación digital completa.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {additionalServices.map((service, index) => (
              <Card key={index} className="group hover:shadow-lg transition-shadow duration-300">
                <CardHeader>
                  <div className="flex items-center space-x-4">
                    <div className="p-3 bg-gray-100 rounded-lg group-hover:bg-blue-50 transition-colors">
                      {service.icon}
                    </div>
                    <CardTitle className="text-xl">{service.title}</CardTitle>
                  </div>
                </CardHeader>
                <CardContent>
                  <CardDescription className="text-gray-600">
                    {service.description}
                  </CardDescription>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Industries */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">
              Industrias que Atendemos
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Experiencia comprobada en múltiples sectores con soluciones 
              adaptadas a las necesidades específicas de cada industria.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {industries.map((industry, index) => (
              <Card key={index} className="text-center group hover:shadow-lg transition-shadow duration-300">
                <CardContent className="p-6">
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">
                    {industry.name}
                  </h3>
                  <p className="text-gray-600 text-sm">
                    {industry.description}
                  </p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Process Timeline */}
      <section className="py-20 bg-gray-50">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">
              Proceso de Implementación
            </h2>
            <p className="text-xl text-gray-600">
              Un enfoque estructurado que garantiza el éxito de cada proyecto
            </p>
          </div>

          <div className="max-w-4xl mx-auto">
            <div className="space-y-8">
              {[
                {
                  phase: "Fase 1",
                  title: "Análisis y Diagnóstico",
                  duration: "1-2 semanas",
                  description: "Evaluación completa de procesos actuales, identificación de oportunidades y definición de objetivos."
                },
                {
                  phase: "Fase 2",
                  title: "Diseño de Solución",
                  duration: "2-3 semanas",
                  description: "Creación de arquitectura técnica, wireframes y especificaciones detalladas de la solución."
                },
                {
                  phase: "Fase 3",
                  title: "Desarrollo e Implementación",
                  duration: "4-8 semanas",
                  description: "Construcción, configuración y despliegue de la solución con pruebas exhaustivas."
                },
                {
                  phase: "Fase 4",
                  title: "Capacitación y Optimización",
                  duration: "2-4 semanas",
                  description: "Entrenamiento del equipo, ajustes finales y optimización basada en feedback inicial."
                }
              ].map((step, index) => (
                <div key={index} className="flex items-start space-x-6">
                  <div className="flex-shrink-0">
                    <div className="w-12 h-12 bg-gradient-to-r from-blue-600 to-purple-600 rounded-full flex items-center justify-center text-white font-bold">
                      {index + 1}
                    </div>
                  </div>
                  <div className="flex-grow">
                    <div className="flex items-center space-x-4 mb-2">
                      <h3 className="text-xl font-semibold text-gray-900">{step.title}</h3>
                      <Badge variant="outline">{step.phase}</Badge>
                      <div className="flex items-center space-x-1 text-sm text-gray-500">
                        <Clock className="h-4 w-4" />
                        <span>{step.duration}</span>
                      </div>
                    </div>
                    <p className="text-gray-600">{step.description}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-blue-600 to-purple-600">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center text-white max-w-4xl mx-auto">
            <h2 className="text-3xl lg:text-4xl font-bold mb-4">
              ¿Listo para comenzar su transformación digital?
            </h2>
            <p className="text-xl mb-8 opacity-90">
              Nuestro equipo de expertos está listo para analizar sus necesidades 
              y diseñar la solución perfecta para su empresa.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link to="/contacto">
                <Button size="lg" className="bg-white text-blue-600 hover:bg-gray-100">
                  Agendar Consulta Gratuita
                  <ArrowRight className="ml-2 h-5 w-5" />
                </Button>
              </Link>
              <Button variant="outline" size="lg" className="border-white text-white hover:bg-white hover:text-blue-600">
                Descargar Brochure
              </Button>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}

export default ServicesPage

