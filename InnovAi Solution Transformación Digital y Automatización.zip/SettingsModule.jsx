import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../ui/card'
import { Button } from '../ui/button'
import { Input } from '../ui/input'
import { Label } from '../ui/label'
import { Switch } from '../ui/switch'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs'
import { Separator } from '../ui/separator'
import { Badge } from '../ui/badge'
import { 
  User, Bell, CreditCard, Calendar, Plug, Shield, Palette, 
  Save, RotateCcw, Download, Upload, History, Settings,
  Mail, Phone, Globe, Building, MapPin, Clock, Languages,
  Smartphone, MessageSquare, Volume2, Eye, Moon, Sun,
  Lock, Key, Database, Activity, Zap, Camera
} from 'lucide-react'

const SettingsModule = () => {
  const [activeTab, setActiveTab] = useState('general')
  const [settings, setSettings] = useState({
    profile: {},
    notifications: {},
    calendar: {},
    billing: {},
    interface: {},
    security: {},
    integrations: {}
  })
  const [loading, setLoading] = useState(false)
  const [saveStatus, setSaveStatus] = useState('')

  // Cargar configuraciones al montar el componente
  useEffect(() => {
    loadAllSettings()
  }, [])

  const loadAllSettings = async () => {
    try {
      setLoading(true)
      const response = await fetch('/api/settings/all?user_id=1')
      const data = await response.json()
      
      if (data.success) {
        setSettings(data.settings)
      }
    } catch (error) {
      console.error('Error loading settings:', error)
    } finally {
      setLoading(false)
    }
  }

  const updateSettings = async (category, newSettings) => {
    try {
      setSaveStatus('Guardando...')
      const response = await fetch(`/api/settings/${category}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ user_id: 1, ...newSettings })
      })
      
      const data = await response.json()
      
      if (data.success) {
        setSaveStatus('✓ Guardado')
        setSettings(prev => ({
          ...prev,
          [category]: { ...prev[category], ...newSettings }
        }))
        setTimeout(() => setSaveStatus(''), 2000)
      } else {
        setSaveStatus('Error al guardar')
      }
    } catch (error) {
      console.error('Error updating settings:', error)
      setSaveStatus('Error al guardar')
    }
  }

  const resetSettings = async (category = 'all') => {
    if (confirm('¿Estás seguro de que quieres restaurar las configuraciones por defecto?')) {
      try {
        const response = await fetch('/api/settings/reset', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({ user_id: 1, setting_type: category })
        })
        
        const data = await response.json()
        
        if (data.success) {
          loadAllSettings()
          setSaveStatus('✓ Configuraciones restauradas')
          setTimeout(() => setSaveStatus(''), 2000)
        }
      } catch (error) {
        console.error('Error resetting settings:', error)
      }
    }
  }

  const exportSettings = async () => {
    try {
      const response = await fetch('/api/settings/export?user_id=1')
      const data = await response.json()
      
      if (data.success) {
        const blob = new Blob([JSON.stringify(data.export_data, null, 2)], {
          type: 'application/json'
        })
        const url = URL.createObjectURL(blob)
        const a = document.createElement('a')
        a.href = url
        a.download = `innovai-settings-${new Date().toISOString().split('T')[0]}.json`
        a.click()
        URL.revokeObjectURL(url)
      }
    } catch (error) {
      console.error('Error exporting settings:', error)
    }
  }

  // Componente para el perfil general
  const GeneralSettings = () => (
    <div className="space-y-6">
      <Card className="glass-card">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <User className="h-5 w-5" />
            Información Personal
          </CardTitle>
          <CardDescription>
            Gestiona tu información personal y de contacto
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="firstName">Nombre</Label>
              <Input
                id="firstName"
                value={settings.profile?.first_name || ''}
                onChange={(e) => updateSettings('profile', { first_name: e.target.value })}
                placeholder="Tu nombre"
              />
            </div>
            <div>
              <Label htmlFor="lastName">Apellido</Label>
              <Input
                id="lastName"
                value={settings.profile?.last_name || ''}
                onChange={(e) => updateSettings('profile', { last_name: e.target.value })}
                placeholder="Tu apellido"
              />
            </div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="phone">Teléfono</Label>
              <Input
                id="phone"
                value={settings.profile?.phone || ''}
                onChange={(e) => updateSettings('profile', { phone: e.target.value })}
                placeholder="+1 (555) 123-4567"
              />
            </div>
            <div>
              <Label htmlFor="timezone">Zona Horaria</Label>
              <Select
                value={settings.profile?.timezone || 'America/New_York'}
                onValueChange={(value) => updateSettings('profile', { timezone: value })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="America/New_York">Este (Nueva York)</SelectItem>
                  <SelectItem value="America/Chicago">Central (Chicago)</SelectItem>
                  <SelectItem value="America/Denver">Montaña (Denver)</SelectItem>
                  <SelectItem value="America/Los_Angeles">Pacífico (Los Ángeles)</SelectItem>
                  <SelectItem value="Europe/Madrid">Madrid</SelectItem>
                  <SelectItem value="America/Mexico_City">Ciudad de México</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div>
            <Label htmlFor="language">Idioma</Label>
            <Select
              value={settings.profile?.language || 'es'}
              onValueChange={(value) => updateSettings('profile', { language: value })}
            >
              <SelectTrigger className="w-full md:w-48">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="es">Español</SelectItem>
                <SelectItem value="en">English</SelectItem>
                <SelectItem value="fr">Français</SelectItem>
                <SelectItem value="pt">Português</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      <Card className="glass-card">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Building className="h-5 w-5" />
            Información Empresarial
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="companyName">Empresa</Label>
              <Input
                id="companyName"
                value={settings.profile?.company_name || ''}
                onChange={(e) => updateSettings('profile', { company_name: e.target.value })}
                placeholder="Nombre de tu empresa"
              />
            </div>
            <div>
              <Label htmlFor="jobTitle">Cargo</Label>
              <Input
                id="jobTitle"
                value={settings.profile?.job_title || ''}
                onChange={(e) => updateSettings('profile', { job_title: e.target.value })}
                placeholder="Tu cargo o posición"
              />
            </div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="industry">Industria</Label>
              <Select
                value={settings.profile?.industry || ''}
                onValueChange={(value) => updateSettings('profile', { industry: value })}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Selecciona tu industria" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="technology">Tecnología</SelectItem>
                  <SelectItem value="healthcare">Salud</SelectItem>
                  <SelectItem value="finance">Finanzas</SelectItem>
                  <SelectItem value="education">Educación</SelectItem>
                  <SelectItem value="retail">Retail</SelectItem>
                  <SelectItem value="manufacturing">Manufactura</SelectItem>
                  <SelectItem value="consulting">Consultoría</SelectItem>
                  <SelectItem value="other">Otro</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="companySize">Tamaño de Empresa</Label>
              <Select
                value={settings.profile?.company_size || ''}
                onValueChange={(value) => updateSettings('profile', { company_size: value })}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Selecciona el tamaño" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="1-10">1-10 empleados</SelectItem>
                  <SelectItem value="11-50">11-50 empleados</SelectItem>
                  <SelectItem value="51-200">51-200 empleados</SelectItem>
                  <SelectItem value="201-1000">201-1000 empleados</SelectItem>
                  <SelectItem value="1000+">1000+ empleados</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )

  // Componente para configuraciones de notificaciones
  const NotificationSettings = () => (
    <div className="space-y-6">
      <Card className="glass-card">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Mail className="h-5 w-5" />
            Notificaciones por Email
          </CardTitle>
          <CardDescription>
            Controla qué notificaciones quieres recibir por email
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label>Confirmaciones de Citas</Label>
              <p className="text-sm text-muted-foreground">
                Recibe confirmaciones cuando se agende una cita
              </p>
            </div>
            <Switch
              checked={settings.notifications?.email_appointments || false}
              onCheckedChange={(checked) => updateSettings('notifications', { email_appointments: checked })}
            />
          </div>
          
          <Separator />
          
          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label>Recordatorios de Citas</Label>
              <p className="text-sm text-muted-foreground">
                Recordatorios antes de tus citas programadas
              </p>
            </div>
            <Switch
              checked={settings.notifications?.email_reminders || false}
              onCheckedChange={(checked) => updateSettings('notifications', { email_reminders: checked })}
            />
          </div>
          
          <Separator />
          
          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label>Notificaciones de Facturación</Label>
              <p className="text-sm text-muted-foreground">
                Facturas, pagos y actualizaciones de suscripción
              </p>
            </div>
            <Switch
              checked={settings.notifications?.email_billing || false}
              onCheckedChange={(checked) => updateSettings('notifications', { email_billing: checked })}
            />
          </div>
          
          <Separator />
          
          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label>Actualizaciones del Servicio</Label>
              <p className="text-sm text-muted-foreground">
                Nuevas funciones y actualizaciones importantes
              </p>
            </div>
            <Switch
              checked={settings.notifications?.email_updates || false}
              onCheckedChange={(checked) => updateSettings('notifications', { email_updates: checked })}
            />
          </div>
        </CardContent>
      </Card>

      <Card className="glass-card">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Bell className="h-5 w-5" />
            Recordatorios de Citas
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label>24 horas antes</Label>
              <p className="text-sm text-muted-foreground">
                Recordatorio un día antes de la cita
              </p>
            </div>
            <Switch
              checked={settings.notifications?.reminder_24h || false}
              onCheckedChange={(checked) => updateSettings('notifications', { reminder_24h: checked })}
            />
          </div>
          
          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label>1 hora antes</Label>
              <p className="text-sm text-muted-foreground">
                Recordatorio una hora antes de la cita
              </p>
            </div>
            <Switch
              checked={settings.notifications?.reminder_1h || false}
              onCheckedChange={(checked) => updateSettings('notifications', { reminder_1h: checked })}
            />
          </div>
          
          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label>15 minutos antes</Label>
              <p className="text-sm text-muted-foreground">
                Recordatorio final antes de la cita
              </p>
            </div>
            <Switch
              checked={settings.notifications?.reminder_15m || false}
              onCheckedChange={(checked) => updateSettings('notifications', { reminder_15m: checked })}
            />
          </div>
        </CardContent>
      </Card>

      <Card className="glass-card">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Volume2 className="h-5 w-5" />
            Frecuencia de Comunicación
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div>
            <Label>Frecuencia preferida</Label>
            <Select
              value={settings.notifications?.communication_frequency || 'normal'}
              onValueChange={(value) => updateSettings('notifications', { communication_frequency: value })}
            >
              <SelectTrigger className="w-full mt-2">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="low">Baja - Solo lo esencial</SelectItem>
                <SelectItem value="normal">Normal - Comunicación estándar</SelectItem>
                <SelectItem value="high">Alta - Todas las actualizaciones</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>
    </div>
  )

  // Componente para configuraciones de calendario
  const CalendarSettings = () => (
    <div className="space-y-6">
      <Card className="glass-card">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Clock className="h-5 w-5" />
            Horarios de Trabajo
          </CardTitle>
          <CardDescription>
            Define tu disponibilidad para citas
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="workStart">Hora de Inicio</Label>
              <Input
                id="workStart"
                type="time"
                value={settings.calendar?.work_start_time || '09:00'}
                onChange={(e) => updateSettings('calendar', { work_start_time: e.target.value })}
              />
            </div>
            <div>
              <Label htmlFor="workEnd">Hora de Fin</Label>
              <Input
                id="workEnd"
                type="time"
                value={settings.calendar?.work_end_time || '17:00'}
                onChange={(e) => updateSettings('calendar', { work_end_time: e.target.value })}
              />
            </div>
          </div>
          
          <div>
            <Label>Zona Horaria</Label>
            <Select
              value={settings.calendar?.timezone || 'America/New_York'}
              onValueChange={(value) => updateSettings('calendar', { timezone: value })}
            >
              <SelectTrigger className="w-full mt-2">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="America/New_York">Este (Nueva York)</SelectItem>
                <SelectItem value="America/Chicago">Central (Chicago)</SelectItem>
                <SelectItem value="America/Denver">Montaña (Denver)</SelectItem>
                <SelectItem value="America/Los_Angeles">Pacífico (Los Ángeles)</SelectItem>
                <SelectItem value="Europe/Madrid">Madrid</SelectItem>
                <SelectItem value="America/Mexico_City">Ciudad de México</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      <Card className="glass-card">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Calendar className="h-5 w-5" />
            Configuraciones de Citas
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="defaultDuration">Duración Predeterminada (minutos)</Label>
              <Input
                id="defaultDuration"
                type="number"
                value={settings.calendar?.default_duration || 60}
                onChange={(e) => updateSettings('calendar', { default_duration: parseInt(e.target.value) })}
                min="15"
                max="480"
                step="15"
              />
            </div>
            <div>
              <Label htmlFor="bufferTime">Tiempo de Buffer (minutos)</Label>
              <Input
                id="bufferTime"
                type="number"
                value={settings.calendar?.buffer_time || 15}
                onChange={(e) => updateSettings('calendar', { buffer_time: parseInt(e.target.value) })}
                min="0"
                max="60"
                step="5"
              />
            </div>
          </div>
          
          <div>
            <Label>Tipo de Reunión Predeterminado</Label>
            <Select
              value={settings.calendar?.default_meeting_type || 'virtual'}
              onValueChange={(value) => updateSettings('calendar', { default_meeting_type: value })}
            >
              <SelectTrigger className="w-full mt-2">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="virtual">Virtual (Video llamada)</SelectItem>
                <SelectItem value="presencial">Presencial</SelectItem>
                <SelectItem value="telefonica">Telefónica</SelectItem>
              </SelectContent>
            </Select>
          </div>
          
          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label>Confirmación Automática</Label>
              <p className="text-sm text-muted-foreground">
                Confirmar citas automáticamente sin revisión manual
              </p>
            </div>
            <Switch
              checked={settings.calendar?.auto_confirm || false}
              onCheckedChange={(checked) => updateSettings('calendar', { auto_confirm: checked })}
            />
          </div>
        </CardContent>
      </Card>
    </div>
  )

  // Componente para configuraciones de interfaz
  const InterfaceSettings = () => (
    <div className="space-y-6">
      <Card className="glass-card">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Palette className="h-5 w-5" />
            Tema y Apariencia
          </CardTitle>
          <CardDescription>
            Personaliza la apariencia de tu portal
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label>Tema</Label>
            <Select
              value={settings.interface?.theme || 'light'}
              onValueChange={(value) => updateSettings('interface', { theme: value })}
            >
              <SelectTrigger className="w-full mt-2">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="light">
                  <div className="flex items-center gap-2">
                    <Sun className="h-4 w-4" />
                    Claro
                  </div>
                </SelectItem>
                <SelectItem value="dark">
                  <div className="flex items-center gap-2">
                    <Moon className="h-4 w-4" />
                    Oscuro
                  </div>
                </SelectItem>
                <SelectItem value="auto">
                  <div className="flex items-center gap-2">
                    <Eye className="h-4 w-4" />
                    Automático
                  </div>
                </SelectItem>
              </SelectContent>
            </Select>
          </div>
          
          <div>
            <Label>Esquema de Colores</Label>
            <Select
              value={settings.interface?.color_scheme || 'blue'}
              onValueChange={(value) => updateSettings('interface', { color_scheme: value })}
            >
              <SelectTrigger className="w-full mt-2">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="blue">Azul</SelectItem>
                <SelectItem value="purple">Púrpura</SelectItem>
                <SelectItem value="green">Verde</SelectItem>
                <SelectItem value="orange">Naranja</SelectItem>
                <SelectItem value="red">Rojo</SelectItem>
              </SelectContent>
            </Select>
          </div>
          
          <div>
            <Label>Tamaño de Fuente</Label>
            <Select
              value={settings.interface?.font_size || 'medium'}
              onValueChange={(value) => updateSettings('interface', { font_size: value })}
            >
              <SelectTrigger className="w-full mt-2">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="small">Pequeño</SelectItem>
                <SelectItem value="medium">Mediano</SelectItem>
                <SelectItem value="large">Grande</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      <Card className="glass-card">
        <CardHeader>
          <CardTitle>Dashboard</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label>Página de Inicio</Label>
            <Select
              value={settings.interface?.default_page || 'dashboard'}
              onValueChange={(value) => updateSettings('interface', { default_page: value })}
            >
              <SelectTrigger className="w-full mt-2">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="dashboard">Dashboard</SelectItem>
                <SelectItem value="calendar">Calendario</SelectItem>
                <SelectItem value="billing">Facturación</SelectItem>
                <SelectItem value="services">Servicios</SelectItem>
              </SelectContent>
            </Select>
          </div>
          
          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label>Mostrar Mensaje de Bienvenida</Label>
              <p className="text-sm text-muted-foreground">
                Mostrar mensaje de bienvenida en el dashboard
              </p>
            </div>
            <Switch
              checked={settings.interface?.show_welcome_message || false}
              onCheckedChange={(checked) => updateSettings('interface', { show_welcome_message: checked })}
            />
          </div>
        </CardContent>
      </Card>
    </div>
  )

  // Componente para configuraciones de seguridad
  const SecuritySettings = () => (
    <div className="space-y-6">
      <Card className="glass-card">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Shield className="h-5 w-5" />
            Autenticación
          </CardTitle>
          <CardDescription>
            Configura la seguridad de tu cuenta
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label>Autenticación de Dos Factores</Label>
              <p className="text-sm text-muted-foreground">
                Agrega una capa extra de seguridad a tu cuenta
              </p>
            </div>
            <Switch
              checked={settings.security?.two_factor_enabled || false}
              onCheckedChange={(checked) => updateSettings('security', { two_factor_enabled: checked })}
            />
          </div>
          
          {settings.security?.two_factor_enabled && (
            <div>
              <Label>Método de Verificación</Label>
              <Select
                value={settings.security?.two_factor_method || 'email'}
                onValueChange={(value) => updateSettings('security', { two_factor_method: value })}
              >
                <SelectTrigger className="w-full mt-2">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="email">Email</SelectItem>
                  <SelectItem value="sms">SMS</SelectItem>
                  <SelectItem value="app">App Autenticadora</SelectItem>
                </SelectContent>
              </Select>
            </div>
          )}
          
          <div>
            <Label>Tiempo de Sesión (minutos)</Label>
            <Input
              type="number"
              value={settings.security?.session_timeout || 30}
              onChange={(e) => updateSettings('security', { session_timeout: parseInt(e.target.value) })}
              min="5"
              max="480"
              className="mt-2"
            />
          </div>
        </CardContent>
      </Card>

      <Card className="glass-card">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Database className="h-5 w-5" />
            Privacidad
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label>Compartir Datos para Mejoras</Label>
              <p className="text-sm text-muted-foreground">
                Ayúdanos a mejorar el servicio compartiendo datos anónimos
              </p>
            </div>
            <Switch
              checked={settings.security?.data_sharing_consent || false}
              onCheckedChange={(checked) => updateSettings('security', { data_sharing_consent: checked })}
            />
          </div>
          
          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label>Analytics</Label>
              <p className="text-sm text-muted-foreground">
                Permitir recopilación de datos de uso para analytics
              </p>
            </div>
            <Switch
              checked={settings.security?.analytics_consent || false}
              onCheckedChange={(checked) => updateSettings('security', { analytics_consent: checked })}
            />
          </div>
          
          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label>Notificaciones de Inicio de Sesión</Label>
              <p className="text-sm text-muted-foreground">
                Recibir alertas cuando alguien acceda a tu cuenta
              </p>
            </div>
            <Switch
              checked={settings.security?.login_notifications || false}
              onCheckedChange={(checked) => updateSettings('security', { login_notifications: checked })}
            />
          </div>
        </CardContent>
      </Card>
    </div>
  )

  // Componente para configuraciones de integraciones
  const IntegrationsSettings = () => (
    <div className="space-y-6">
      <Card className="glass-card">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Calendar className="h-5 w-5" />
            Calendarios
          </CardTitle>
          <CardDescription>
            Sincroniza con tus calendarios externos
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label>Google Calendar</Label>
              <p className="text-sm text-muted-foreground">
                Sincronizar citas con Google Calendar
              </p>
            </div>
            <div className="flex items-center gap-2">
              {settings.integrations?.google_calendar_enabled && (
                <Badge variant="secondary">Conectado</Badge>
              )}
              <Switch
                checked={settings.integrations?.google_calendar_enabled || false}
                onCheckedChange={(checked) => updateSettings('integrations', { google_calendar_enabled: checked })}
              />
            </div>
          </div>
          
          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label>Outlook Calendar</Label>
              <p className="text-sm text-muted-foreground">
                Sincronizar citas con Outlook Calendar
              </p>
            </div>
            <div className="flex items-center gap-2">
              {settings.integrations?.outlook_calendar_enabled && (
                <Badge variant="secondary">Conectado</Badge>
              )}
              <Switch
                checked={settings.integrations?.outlook_calendar_enabled || false}
                onCheckedChange={(checked) => updateSettings('integrations', { outlook_calendar_enabled: checked })}
              />
            </div>
          </div>
        </CardContent>
      </Card>

      <Card className="glass-card">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <MessageSquare className="h-5 w-5" />
            Comunicación
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label>Slack</Label>
              <p className="text-sm text-muted-foreground">
                Recibir notificaciones en Slack
              </p>
            </div>
            <div className="flex items-center gap-2">
              {settings.integrations?.slack_enabled && (
                <Badge variant="secondary">Conectado</Badge>
              )}
              <Switch
                checked={settings.integrations?.slack_enabled || false}
                onCheckedChange={(checked) => updateSettings('integrations', { slack_enabled: checked })}
              />
            </div>
          </div>
          
          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label>Microsoft Teams</Label>
              <p className="text-sm text-muted-foreground">
                Recibir notificaciones en Teams
              </p>
            </div>
            <div className="flex items-center gap-2">
              {settings.integrations?.teams_enabled && (
                <Badge variant="secondary">Conectado</Badge>
              )}
              <Switch
                checked={settings.integrations?.teams_enabled || false}
                onCheckedChange={(checked) => updateSettings('integrations', { teams_enabled: checked })}
              />
            </div>
          </div>
        </CardContent>
      </Card>

      <Card className="glass-card">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Zap className="h-5 w-5" />
            Sincronización
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label>Frecuencia de Sincronización</Label>
            <Select
              value={settings.integrations?.sync_frequency || 'daily'}
              onValueChange={(value) => updateSettings('integrations', { sync_frequency: value })}
            >
              <SelectTrigger className="w-full mt-2">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="realtime">Tiempo Real</SelectItem>
                <SelectItem value="hourly">Cada Hora</SelectItem>
                <SelectItem value="daily">Diario</SelectItem>
                <SelectItem value="weekly">Semanal</SelectItem>
              </SelectContent>
            </Select>
          </div>
          
          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label>Sincronizar Contactos</Label>
              <p className="text-sm text-muted-foreground">
                Mantener contactos sincronizados con servicios externos
              </p>
            </div>
            <Switch
              checked={settings.integrations?.sync_contacts || false}
              onCheckedChange={(checked) => updateSettings('integrations', { sync_contacts: checked })}
            />
          </div>
        </CardContent>
      </Card>
    </div>
  )

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold gradient-text">Configuraciones</h1>
          <p className="text-muted-foreground">
            Personaliza tu experiencia en InnovAi Solutions
          </p>
        </div>
        
        <div className="flex items-center gap-2">
          {saveStatus && (
            <span className="text-sm text-muted-foreground">{saveStatus}</span>
          )}
          <Button
            variant="outline"
            size="sm"
            onClick={exportSettings}
            className="hover-lift"
          >
            <Download className="h-4 w-4 mr-2" />
            Exportar
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={() => resetSettings()}
            className="hover-lift"
          >
            <RotateCcw className="h-4 w-4 mr-2" />
            Restaurar
          </Button>
        </div>
      </div>

      {/* Tabs de Configuraciones */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-6 glass-card">
          <TabsTrigger value="general" className="flex items-center gap-2">
            <User className="h-4 w-4" />
            General
          </TabsTrigger>
          <TabsTrigger value="notifications" className="flex items-center gap-2">
            <Bell className="h-4 w-4" />
            Notificaciones
          </TabsTrigger>
          <TabsTrigger value="calendar" className="flex items-center gap-2">
            <Calendar className="h-4 w-4" />
            Calendario
          </TabsTrigger>
          <TabsTrigger value="interface" className="flex items-center gap-2">
            <Palette className="h-4 w-4" />
            Interfaz
          </TabsTrigger>
          <TabsTrigger value="security" className="flex items-center gap-2">
            <Shield className="h-4 w-4" />
            Seguridad
          </TabsTrigger>
          <TabsTrigger value="integrations" className="flex items-center gap-2">
            <Plug className="h-4 w-4" />
            Integraciones
          </TabsTrigger>
        </TabsList>

        <TabsContent value="general" className="mt-6">
          <GeneralSettings />
        </TabsContent>

        <TabsContent value="notifications" className="mt-6">
          <NotificationSettings />
        </TabsContent>

        <TabsContent value="calendar" className="mt-6">
          <CalendarSettings />
        </TabsContent>

        <TabsContent value="interface" className="mt-6">
          <InterfaceSettings />
        </TabsContent>

        <TabsContent value="security" className="mt-6">
          <SecuritySettings />
        </TabsContent>

        <TabsContent value="integrations" className="mt-6">
          <IntegrationsSettings />
        </TabsContent>
      </Tabs>
    </div>
  )
}

export default SettingsModule

