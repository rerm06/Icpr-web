from flask import Blueprint, jsonify, request
from src.models.user import Lead, db

leads_bp = Blueprint('leads', __name__)

@leads_bp.route('/leads', methods=['GET'])
def get_leads():
    status = request.args.get('status')
    service_interest = request.args.get('service_interest')
    
    query = Lead.query
    if status:
        query = query.filter_by(status=status)
    if service_interest:
        query = query.filter_by(service_interest=service_interest)
    
    leads = query.order_by(Lead.created_at.desc()).all()
    return jsonify([lead.to_dict() for lead in leads])

@leads_bp.route('/leads', methods=['POST'])
def create_lead():
    data = request.json
    
    lead = Lead(
        name=data['name'],
        email=data['email'],
        company=data.get('company'),
        phone=data.get('phone'),
        service_interest=data.get('service_interest'),
        message=data.get('message'),
        contact_preference=data.get('contact_preference'),
        budget_range=data.get('budget_range'),
        timeline=data.get('timeline'),
        status=data.get('status', 'new')
    )
    db.session.add(lead)
    db.session.commit()
    
    # En una implementación real, aquí se enviaría un email de notificación
    
    return jsonify({
        'success': True,
        'message': 'Solicitud enviada exitosamente. Nos pondremos en contacto pronto.',
        'lead': lead.to_dict()
    }), 201

@leads_bp.route('/leads/<int:lead_id>', methods=['GET'])
def get_lead(lead_id):
    lead = Lead.query.get_or_404(lead_id)
    return jsonify(lead.to_dict())

@leads_bp.route('/leads/<int:lead_id>', methods=['PUT'])
def update_lead(lead_id):
    lead = Lead.query.get_or_404(lead_id)
    data = request.json
    
    lead.name = data.get('name', lead.name)
    lead.email = data.get('email', lead.email)
    lead.company = data.get('company', lead.company)
    lead.phone = data.get('phone', lead.phone)
    lead.service_interest = data.get('service_interest', lead.service_interest)
    lead.message = data.get('message', lead.message)
    lead.contact_preference = data.get('contact_preference', lead.contact_preference)
    lead.budget_range = data.get('budget_range', lead.budget_range)
    lead.timeline = data.get('timeline', lead.timeline)
    lead.status = data.get('status', lead.status)
    
    db.session.commit()
    return jsonify(lead.to_dict())

@leads_bp.route('/leads/<int:lead_id>', methods=['DELETE'])
def delete_lead(lead_id):
    lead = Lead.query.get_or_404(lead_id)
    db.session.delete(lead)
    db.session.commit()
    return '', 204

@leads_bp.route('/leads/stats', methods=['GET'])
def get_lead_stats():
    """Obtener estadísticas de leads"""
    total_leads = Lead.query.count()
    new_leads = Lead.query.filter_by(status='new').count()
    contacted_leads = Lead.query.filter_by(status='contacted').count()
    qualified_leads = Lead.query.filter_by(status='qualified').count()
    converted_leads = Lead.query.filter_by(status='converted').count()
    
    # Leads por servicio de interés
    services_interest = db.session.query(
        Lead.service_interest, 
        db.func.count(Lead.id)
    ).group_by(Lead.service_interest).all()
    
    return jsonify({
        'total_leads': total_leads,
        'by_status': {
            'new': new_leads,
            'contacted': contacted_leads,
            'qualified': qualified_leads,
            'converted': converted_leads
        },
        'by_service_interest': [
            {'service': service, 'count': count} 
            for service, count in services_interest
        ]
    })

